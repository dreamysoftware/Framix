#!/bin/bash
set -e

cd "$(dirname "$0")"

echo "=== Framix macOS Catalina Desktop-Builder (Node 18 / Intel x64) ==="

if ! command -v node >/dev/null 2>&1; then
  echo "Fehler: Node.js wurde nicht gefunden."
  exit 1
fi

echo "1/3 Installiere Electron 32 & Packager (ohne Vite/esbuild)..."
npm install --no-save --legacy-peer-deps electron@32.3.3 @electron/packager@18.3.6

echo "2/4 Erzeuge macOS App-Icon (.icns)..."
ICON_ARG=""
if [ -f "icon.png" ] && command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
  rm -rf Framix.iconset
  mkdir -p Framix.iconset
  sips -z 16 16     icon.png --out Framix.iconset/icon_16x16.png >/dev/null
  sips -z 32 32     icon.png --out Framix.iconset/icon_16x16@2x.png >/dev/null
  sips -z 32 32     icon.png --out Framix.iconset/icon_32x32.png >/dev/null
  sips -z 64 64     icon.png --out Framix.iconset/icon_32x32@2x.png >/dev/null
  sips -z 128 128   icon.png --out Framix.iconset/icon_128x128.png >/dev/null
  sips -z 256 256   icon.png --out Framix.iconset/icon_128x128@2x.png >/dev/null
  sips -z 256 256   icon.png --out Framix.iconset/icon_256x256.png >/dev/null
  sips -z 512 512   icon.png --out Framix.iconset/icon_256x256@2x.png >/dev/null
  sips -z 512 512   icon.png --out Framix.iconset/icon_512x512.png >/dev/null
  sips -z 1024 1024 icon.png --out Framix.iconset/icon_512x512@2x.png >/dev/null
  iconutil -c icns Framix.iconset -o icon.icns
  rm -rf Framix.iconset
  ICON_ARG="--icon=icon.icns"
fi

echo "3/4 Erzeuge Framix.app für macOS Catalina..."
npx @electron/packager . Framix \
  --platform=darwin \
  --arch=x64 \
  --electron-version=32.3.3 \
  --out=release \
  --overwrite \
  --app-bundle-id=com.framix.studio \
  --extend-info=macos-permissions.plist \
  $ICON_ARG \
  --ignore="^/release"

echo "4/4 Fertig!"
echo "Deine App liegt in: $(pwd)/release/Framix-darwin-x64/Framix.app"
open release/Framix-darwin-x64 || true
