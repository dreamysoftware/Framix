cmake_minimum_required(VERSION 3.18)
project(framix_core LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(pybind11 REQUIRED)

pybind11_add_module(framix_core framix_core.cpp)
target_compile_definitions(framix_core PRIVATE FRAMIX_WITH_PYBIND11)
