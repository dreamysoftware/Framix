#include "framix_core.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <sstream>
#include <stdexcept>

#ifdef FRAMIX_WITH_PYBIND11
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
namespace py = pybind11;
#endif

namespace framix {

namespace {
inline uint8_t clamp_u8(float v) {
    return static_cast<uint8_t>(std::clamp(v, 0.0f, 255.0f));
}
} // namespace

FrameCompositor::FrameCompositor(int width, int height)
    : width_(width), height_(height) {
    if (width <= 0 || height <= 0) {
        throw std::invalid_argument("Invalid frame dimensions");
    }
}

std::vector<uint8_t> FrameCompositor::blend_onion_skin(
    const std::vector<uint8_t>& live_rgb,
    const std::vector<std::vector<uint8_t>>& prev_frames,
    float opacity
) const {
    const size_t expected = static_cast<size_t>(width_) * height_ * 3;
    if (live_rgb.size() != expected || prev_frames.empty() || opacity <= 0.0f) {
        return live_rgb;
    }

    std::vector<uint8_t> out = live_rgb;
    const float clamped_alpha = std::clamp(opacity, 0.0f, 0.9f);
    const size_t count = prev_frames.size();

    for (size_t f = 0; f < count; ++f) {
        const auto& prev = prev_frames[f];
        if (prev.size() != expected) continue;
        const float weight = clamped_alpha / static_cast<float>(f + 1);
        const float inv = 1.0f - weight;
        for (size_t i = 0; i < expected; ++i) {
            out[i] = clamp_u8(out[i] * inv + prev[i] * weight);
        }
    }
    return out;
}

std::vector<uint8_t> FrameCompositor::compute_difference_matte(
    const std::vector<uint8_t>& live_rgb,
    const std::vector<uint8_t>& ref_rgb
) const {
    const size_t expected = static_cast<size_t>(width_) * height_ * 3;
    if (live_rgb.size() != expected || ref_rgb.size() != expected) {
        return live_rgb;
    }
    std::vector<uint8_t> out(expected);
    for (size_t i = 0; i < expected; ++i) {
        const int diff = std::abs(static_cast<int>(live_rgb[i]) - static_cast<int>(ref_rgb[i]));
        out[i] = static_cast<uint8_t>(std::min(255, diff * 2));
    }
    return out;
}

std::vector<uint8_t> FrameCompositor::apply_color_grading(
    const std::vector<uint8_t>& rgb,
    const ColorGrading& grading
) const {
    const size_t expected = static_cast<size_t>(width_) * height_ * 3;
    if (rgb.size() != expected) return rgb;

    std::vector<uint8_t> out(expected);
    const float b_offset = grading.brightness * 2.55f;
    const float c_factor = (100.0f + grading.contrast) / 100.0f;
    const float s_factor = std::max(0.0f, (100.0f + grading.saturation) / 100.0f);
    const float temp_shift = grading.temperature * 0.8f;

    const float cx = width_ * 0.5f;
    const float cy = height_ * 0.5f;
    const float max_dist = std::sqrt(cx * cx + cy * cy);
    const float vig_strength = std::clamp(grading.vignette / 100.0f, 0.0f, 0.9f);

    for (int y = 0; y < height_; ++y) {
        for (int x = 0; x < width_; ++x) {
            const size_t idx = (static_cast<size_t>(y) * width_ + x) * 3;
            float r = static_cast<float>(rgb[idx]);
            float g = static_cast<float>(rgb[idx + 1]);
            float b = static_cast<float>(rgb[idx + 2]);

            // Brightness & Contrast
            r = (r - 128.0f) * c_factor + 128.0f + b_offset;
            g = (g - 128.0f) * c_factor + 128.0f + b_offset;
            b = (b - 128.0f) * c_factor + 128.0f + b_offset;

            // Saturation
            const float luma = 0.299f * r + 0.587f * g + 0.114f * b;
            r = luma + (r - luma) * s_factor;
            g = luma + (g - luma) * s_factor;
            b = luma + (b - luma) * s_factor;

            // Color Temperature
            r += temp_shift;
            b -= temp_shift;

            // Vignette
            if (vig_strength > 0.001f) {
                const float dx = x - cx;
                const float dy = y - cy;
                const float dist = std::sqrt(dx * dx + dy * dy) / max_dist;
                const float falloff = 1.0f - vig_strength * std::pow(dist, 2.2f);
                r *= falloff;
                g *= falloff;
                b *= falloff;
            }

            out[idx] = clamp_u8(r);
            out[idx + 1] = clamp_u8(g);
            out[idx + 2] = clamp_u8(b);
        }
    }
    return out;
}

std::vector<uint8_t> FrameCompositor::apply_masks(
    const std::vector<uint8_t>& rgb,
    const std::vector<MaskRect>& masks
) const {
    const size_t expected = static_cast<size_t>(width_) * height_ * 3;
    if (rgb.size() != expected || masks.empty()) return rgb;

    std::vector<uint8_t> out = rgb;
    for (const auto& mask : masks) {
        if (!mask.enabled) continue;
        const int min_x = static_cast<int>(std::min(mask.x0, mask.x1) * width_);
        const int max_x = static_cast<int>(std::max(mask.x0, mask.x1) * width_);
        const int min_y = static_cast<int>(std::min(mask.y0, mask.y1) * height_);
        const int max_y = static_cast<int>(std::max(mask.y0, mask.y1) * height_);

        for (int y = 0; y < height_; ++y) {
            for (int x = 0; x < width_; ++x) {
                const bool inside = (x >= min_x && x <= max_x && y >= min_y && y <= max_y);
                const bool should_mask = mask.inverted ? !inside : inside;
                if (should_mask) {
                    const size_t idx = (static_cast<size_t>(y) * width_ + x) * 3;
                    out[idx] = mask.fill_r;
                    out[idx + 1] = mask.fill_g;
                    out[idx + 2] = mask.fill_b;
                }
            }
        }
    }
    return out;
}

bool write_frmp_manifest(const std::string& path, const std::string& json_payload) {
    std::ofstream file(path, std::ios::binary | std::ios::trunc);
    if (!file.is_open()) return false;
    file.write(json_payload.data(), static_cast<std::streamsize>(json_payload.size()));
    return file.good();
}

std::string read_frmp_manifest(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Konnte .frmp Datei nicht oeffnen: " + path);
    }
    std::ostringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

} // namespace framix

#ifdef FRAMIX_WITH_PYBIND11
PYBIND11_MODULE(framix_core, m) {
    m.doc() = "Framix C++20 Stop-Motion Real-Time Frame Engine";

    py::class_<framix::ColorGrading>(m, "ColorGrading")
        .def(py::init<>())
        .def_readwrite("brightness", &framix::ColorGrading::brightness)
        .def_readwrite("contrast", &framix::ColorGrading::contrast)
        .def_readwrite("saturation", &framix::ColorGrading::saturation)
        .def_readwrite("temperature", &framix::ColorGrading::temperature)
        .def_readwrite("vignette", &framix::ColorGrading::vignette)
        .def_readwrite("preset", &framix::ColorGrading::preset);

    py::class_<framix::MaskRect>(m, "MaskRect")
        .def(py::init<>())
        .def_readwrite("x0", &framix::MaskRect::x0)
        .def_readwrite("y0", &framix::MaskRect::y0)
        .def_readwrite("x1", &framix::MaskRect::x1)
        .def_readwrite("y1", &framix::MaskRect::y1)
        .def_readwrite("inverted", &framix::MaskRect::inverted)
        .def_readwrite("enabled", &framix::MaskRect::enabled);

    py::class_<framix::FrameCompositor>(m, "FrameCompositor")
        .def(py::init<int, int>())
        .def("blend_onion_skin", &framix::FrameCompositor::blend_onion_skin)
        .def("compute_difference_matte", &framix::FrameCompositor::compute_difference_matte)
        .def("apply_color_grading", &framix::FrameCompositor::apply_color_grading)
        .def("apply_masks", &framix::FrameCompositor::apply_masks);

    m.def("write_frmp_manifest", &framix::write_frmp_manifest);
    m.def("read_frmp_manifest", &framix::read_frmp_manifest);
}
#endif
