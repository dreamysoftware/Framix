#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace framix {

struct ColorGrading {
    float brightness = 0.0f;   // -50 .. +50
    float contrast = 0.0f;     // -50 .. +50
    float saturation = 0.0f;   // -100 .. +100
    float temperature = 0.0f;  // -50 .. +50
    float vignette = 0.0f;     // 0 .. 100
    std::string preset = "none";
};

struct MaskRect {
    float x0 = 0.0f;
    float y0 = 0.0f;
    float x1 = 1.0f;
    float y1 = 1.0f;
    bool inverted = false;
    bool enabled = true;
    uint8_t fill_r = 8;
    uint8_t fill_g = 9;
    uint8_t fill_b = 11;
};

class FrameCompositor {
public:
    FrameCompositor(int width, int height);

    // Alpha-blend live RGB24 buffer with up to N previous onion-skin frames
    std::vector<uint8_t> blend_onion_skin(
        const std::vector<uint8_t>& live_rgb,
        const std::vector<std::vector<uint8_t>>& prev_frames,
        float opacity
    ) const;

    // Difference matte for sub-pixel puppet alignment
    std::vector<uint8_t> compute_difference_matte(
        const std::vector<uint8_t>& live_rgb,
        const std::vector<uint8_t>& ref_rgb
    ) const;

    // Apply non-destructive color grading, temperature, and vignette
    std::vector<uint8_t> apply_color_grading(
        const std::vector<uint8_t>& rgb,
        const ColorGrading& grading
    ) const;

    // Apply rectangular garbage masks to RGB24 frame buffer
    std::vector<uint8_t> apply_masks(
        const std::vector<uint8_t>& rgb,
        const std::vector<MaskRect>& masks
    ) const;

    int width() const { return width_; }
    int height() const { return height_; }

private:
    int width_;
    int height_;
};

// Serialize / deserialize .frmp project header & frame manifest
bool write_frmp_manifest(const std::string& path, const std::string& json_payload);
std::string read_frmp_manifest(const std::string& path);

} // namespace framix
