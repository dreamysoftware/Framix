"""
Framix — Native Desktop Stop-Motion Studio (Python + PySide6 + OpenCV + C++ Core)
Start with:
  pip install -r requirements.txt
  python framix_gui.py
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QSlider,
    QSplashScreen,
    QVBoxLayout,
    QWidget,
)

try:
    import framix_core  # Compiled C++20 pybind11 extension
    HAS_CPP_CORE = True
except ImportError:
    HAS_CPP_CORE = False


class FramixSplashWindow(QSplashScreen):
    def __init__(self, splash_image_path: Optional[str] = None):
        pixmap = QPixmap(720, 405)
        pixmap.fill(Qt.GlobalColor.black)
        if splash_image_path and os.path.exists(splash_image_path):
            loaded = QPixmap(splash_image_path)
            if not loaded.isNull():
                pixmap = loaded.scaled(720, 405, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        super().__init__(pixmap)
        self.progress = QProgressBar(self)
        self.progress.setGeometry(40, 350, 640, 14)
        self.progress.setValue(0)


class FramixStudioWindow(QMainWindow):
    frame_captured = Signal(int)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Framix — Stop-Motion Studio (.frmp)")
        self.resize(1360, 840)
        self.setStyleSheet("background-color: #0e1013; color: #f1f3f5;")

        self.cap: Optional[cv2.VideoCapture] = None
        self.frames: list[np.ndarray] = []
        self.onion_opacity = 0.35
        self.fps = 12
        self.compositor = framix_core.FrameCompositor(1280, 720) if HAS_CPP_CORE else None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        # Header
        header = QHBoxLayout()
        title = QLabel("Framix Stop-Motion Studio")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.cam_select = QComboBox()
        self.detect_cameras()
        btn_open_frmp = QPushButton(".frmp Laden")
        btn_open_frmp.clicked.connect(self.load_frmp)
        btn_save_frmp = QPushButton(".frmp Speichern")
        btn_save_frmp.clicked.connect(self.save_frmp)
        btn_export = QPushButton("Video Exportieren (MP4/WebM)")
        btn_export.clicked.connect(self.export_video)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.cam_select)
        header.addWidget(btn_open_frmp)
        header.addWidget(btn_save_frmp)
        header.addWidget(btn_export)
        layout.addLayout(header)

        # Viewport + Inspector
        mid = QHBoxLayout()
        self.preview_label = QLabel("Live-Kamera Vorschau")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setMinimumSize(880, 520)
        self.preview_label.setStyleSheet("background-color: #08090b; border: 1px solid #272c37;")
        mid.addWidget(self.preview_label, stretch=3)

        inspector = QVBoxLayout()
        btn_capture = QPushButton("Einzelbild Auslösen (Space)")
        btn_capture.setStyleSheet("background-color: #e0533c; padding: 12px; font-weight: bold;")
        btn_capture.clicked.connect(self.capture_frame)
        inspector.addWidget(btn_capture)

        inspector.addWidget(QLabel("Zwiebelschalen-Deckkraft"))
        onion_slider = QSlider(Qt.Orientation.Horizontal)
        onion_slider.setRange(0, 85)
        onion_slider.setValue(35)
        onion_slider.valueChanged.connect(lambda v: setattr(self, "onion_opacity", v / 100.0))
        inspector.addWidget(onion_slider)
        inspector.addStretch()
        mid.addLayout(inspector, stretch=1)
        layout.addLayout(mid)

        # Timeline
        self.timeline_list = QListWidget()
        self.timeline_list.setFlow(QListWidget.Flow.LeftToRight)
        self.timeline_list.setMaximumHeight(120)
        layout.addWidget(self.timeline_list)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_live_frame)
        self.open_camera(0)
        self.timer.start(33)

    def detect_cameras(self):
        self.cam_select.clear()
        for idx in range(4):
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                self.cam_select.addItem(f"Kamera {idx}", idx)
                cap.release()
        if self.cam_select.count() == 0:
            self.cam_select.addItem("Virtuelle Test-Kamera", -1)

    def open_camera(self, index: int):
        if self.cap:
            self.cap.release()
        self.cap = cv2.VideoCapture(index) if index >= 0 else None

    def update_live_frame(self):
        if self.cap and self.cap.isOpened():
            ok, bgr = self.cap.read()
            if ok:
                rgb = cv2.cvtColor(cv2.resize(bgr, (1280, 720)), cv2.COLOR_BGR2RGB)
            else:
                rgb = np.zeros((720, 1280, 3), dtype=np.uint8)
        else:
            rgb = np.full((720, 1280, 3), 24, dtype=np.uint8)

        if self.frames and self.onion_opacity > 0:
            prev = self.frames[-1]
            if self.compositor:
                blended = self.compositor.blend_onion_skin(
                    rgb.flatten().tolist(),
                    [prev.flatten().tolist()],
                    float(self.onion_opacity),
                )
                rgb = np.array(blended, dtype=np.uint8).reshape((720, 1280, 3))
            else:
                rgb = cv2.addWeighted(rgb, 1.0 - self.onion_opacity, prev, self.onion_opacity, 0)

        qimg = QImage(rgb.data, 1280, 720, 1280 * 3, QImage.Format.Format_RGB888)
        self.preview_label.setPixmap(
            QPixmap.fromImage(qimg).scaled(
                self.preview_label.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def capture_frame(self):
        if self.cap and self.cap.isOpened():
            ok, bgr = self.cap.read()
            if ok:
                rgb = cv2.cvtColor(cv2.resize(bgr, (1280, 720)), cv2.COLOR_BGR2RGB)
                self.frames.append(rgb)
                self.timeline_list.addItem(f"Frame {len(self.frames):04d}")

    def save_frmp(self):
        path, _ = QFileDialog.getSaveFileName(self, "Projekt speichern", "projekt.frmp", "Framix (*.frmp)")
        if not path:
            return
        manifest = {"version": "1.0", "fps": self.fps, "frame_count": len(self.frames)}
        payload = json.dumps(manifest, indent=2)
        if HAS_CPP_CORE:
            framix_core.write_frmp_manifest(path, payload)
        else:
            Path(path).write_text(payload, encoding="utf-8")

    def load_frmp(self):
        path, _ = QFileDialog.getOpenFileName(self, "Projekt öffnen", "", "Framix (*.frmp)")
        if path:
            data = framix_core.read_frmp_manifest(path) if HAS_CPP_CORE else Path(path).read_text()
            self.setWindowTitle(f"Framix — {os.path.basename(path)}")

    def export_video(self):
        if not self.frames:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Video exportieren", "film.mp4", "MP4 (*.mp4)")
        if not path:
            return
        writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), self.fps, (1280, 720))
        for f in self.frames:
            writer.write(cv2.cvtColor(f, cv2.COLOR_RGB2BGR))
        writer.release()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    splash = FramixSplashWindow()
    splash.show()
    for step in range(0, 101, 20):
        splash.progress.setValue(step)
        app.processEvents()
        time.sleep(0.15)
    win = FramixStudioWindow()
    win.show()
    splash.finish(win)
    sys.exit(app.exec())
