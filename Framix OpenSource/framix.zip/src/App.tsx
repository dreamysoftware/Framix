import { useCallback, useState } from 'react';
import NativeCodeModal from './components/NativeCodeModal';
import SplashScreen from './components/SplashScreen';
import StartScreen from './components/StartScreen';
import StudioWorkspace from './components/StudioWorkspace';
import { DEFAULT_GREENSCREEN, FramixFolder, FramixProject, ResolutionPreset } from './types/framix';
import {
  deleteFolder,
  deleteProject,
  getAllFolders,
  getAllProjects,
  saveFolder,
  saveProject,
} from './utils/frmpStorage';
import { createInitialSeedData } from './utils/sampleProjects';

type AppView = 'splash' | 'hub' | 'studio';

export default function App() {
  const [view, setView] = useState<AppView>('splash');
  const [projects, setProjects] = useState<FramixProject[]>([]);
  const [folders, setFolders] = useState<FramixFolder[]>([]);
  const [activeProject, setActiveProject] = useState<FramixProject | null>(null);
  const [showNativeCode, setShowNativeCode] = useState(false);

  const initializeVault = useCallback(async () => {
    let loadedFolders = await getAllFolders();
    let loadedProjects = await getAllProjects();

    if (loadedProjects.length === 0 && loadedFolders.length === 0) {
      const seed = createInitialSeedData();
      for (const f of seed.folders) await saveFolder(f);
      for (const p of seed.projects) await saveProject(p);
      loadedFolders = await getAllFolders();
      loadedProjects = await getAllProjects();
    }

    setFolders(loadedFolders);
    setProjects(loadedProjects);
  }, []);

  const refreshLibrary = async () => {
    const [fList, pList] = await Promise.all([getAllFolders(), getAllProjects()]);
    setFolders(fList);
    setProjects(pList);
  };

  const handleCreateProject = async (params: {
    name: string;
    fps: number;
    resolution: ResolutionPreset;
    folderId: string | null;
  }) => {
    const now = Date.now();
    const newProj: FramixProject = {
      version: '1.0',
      fileExtension: '.frmp',
      id: `proj_${now}_${Math.random().toString(36).slice(2, 6)}`,
      name: params.name,
      folderId: params.folderId,
      createdAt: now,
      updatedAt: now,
      fps: params.fps,
      resolution: params.resolution,
      frames: [],
      guides: [],
      greenscreen: { ...DEFAULT_GREENSCREEN },
      motionAlertsEnabled: true,
      audioClips: [],
      cameraSettings: {
        mirrorX: false,
        mirrorY: false,
        brightness: 0,
        contrast: 0,
        saturation: 0,
        guide: 'thirds',
      },
    };
    const saved = await saveProject(newProj);
    await refreshLibrary();
    setActiveProject(saved);
    setView('studio');
  };

  const handleSaveProject = useCallback(async (updated: FramixProject) => {
    const saved = await saveProject(updated);
    setProjects((prev) => {
      const exists = prev.some((p) => p.id === saved.id);
      const next = exists
        ? prev.map((p) => (p.id === saved.id ? saved : p))
        : [saved, ...prev];
      return [...next].sort((a, b) => b.updatedAt - a.updatedAt);
    });
  }, []);

  const handleDeleteProject = async (id: string) => {
    await deleteProject(id);
    await refreshLibrary();
  };

  const handleDuplicateProject = async (proj: FramixProject) => {
    const now = Date.now();
    const dup: FramixProject = {
      ...proj,
      id: `proj_${now}_${Math.random().toString(36).slice(2, 6)}`,
      name: `${proj.name} (Kopie)`,
      createdAt: now,
      updatedAt: now,
    };
    await saveProject(dup);
    await refreshLibrary();
  };

  const handleMoveProjectToFolder = async (projectId: string, folderId: string | null) => {
    const target = projects.find((p) => p.id === projectId);
    if (!target) return;
    await saveProject({ ...target, folderId });
    await refreshLibrary();
  };

  const handleImportProject = async (imported: FramixProject) => {
    const saved = await saveProject(imported);
    await refreshLibrary();
    setActiveProject(saved);
    setView('studio');
  };

  const handleCreateFolder = async (name: string) => {
    const folder: FramixFolder = {
      id: `folder_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      name,
      createdAt: Date.now(),
    };
    await saveFolder(folder);
    await refreshLibrary();
  };

  const handleRenameFolder = async (id: string, name: string) => {
    const existing = folders.find((f) => f.id === id);
    if (!existing) return;
    await saveFolder({ ...existing, name });
    await refreshLibrary();
  };

  const handleDeleteFolder = async (id: string) => {
    await deleteFolder(id);
    await refreshLibrary();
  };

  const handleSplashReady = useCallback(() => {
    setView('hub');
  }, []);

  return (
    <>
      {view === 'splash' && (
        <SplashScreen
          initTask={initializeVault}
          onReady={handleSplashReady}
        />
      )}

      {view === 'hub' && (
        <StartScreen
          projects={projects}
          folders={folders}
          onOpenProject={(proj) => {
            setActiveProject(proj);
            setView('studio');
          }}
          onCreateProject={handleCreateProject}
          onDeleteProject={handleDeleteProject}
          onDuplicateProject={handleDuplicateProject}
          onMoveProjectToFolder={handleMoveProjectToFolder}
          onImportProject={handleImportProject}
          onCreateFolder={handleCreateFolder}
          onRenameFolder={handleRenameFolder}
          onDeleteFolder={handleDeleteFolder}
          onShowNativeCode={() => setShowNativeCode(true)}
        />
      )}

      {view === 'studio' && activeProject && (
        <StudioWorkspace
          project={activeProject}
          onSaveProject={handleSaveProject}
          onBackToHub={async () => {
            await refreshLibrary();
            setView('hub');
          }}
        />
      )}

      {showNativeCode && (
        <NativeCodeModal onClose={() => setShowNativeCode(false)} />
      )}
    </>
  );
}
