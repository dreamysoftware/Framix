import { useState } from 'react';
import { CheckCircle2, Download, Film, X } from 'lucide-react';
import { FramixProject } from '../types/framix';
import { ExportFormat, exportFramixProject } from '../utils/exporters';

interface ExportModalProps {
  project: FramixProject;
  onClose: () => void;
}

const FORMAT_OPTIONS: { id: ExportFormat; title: string; desc: string }[] = [
  { id: 'webm', title: 'WebM Video (VP9/VP8)', desc: 'Hochauflösendes Video inkl. Dialog-Tonspur' },
  { id: 'mp4', title: 'MP4 Video (H.264)', desc: 'Kompatibles Filmformat (mit Browser-Codec-Fallback)' },
  { id: 'gif', title: 'Animiertes GIF', desc: 'Endlosschleife für Web & Vorschau' },
  { id: 'png_zip', title: 'PNG Einzelbild-Sequenz (.zip)', desc: 'Verlustfreie Einzelbilder im Archiv' },
  { id: 'frmp', title: 'Framix Projektdatei (.frmp)', desc: 'Komplettes Projekt inkl. Rotoskopie, Masken & Audio' },
];

export default function ExportModal({ project, onClose }: ExportModalProps) {
  const [format, setFormat] = useState<ExportFormat>('webm');
  const [fps, setFps] = useState(project.fps);
  const [scale, setScale] = useState(1);
  const [includeAudio, setIncludeAudio] = useState(true);
  const [includeEffects, setIncludeEffects] = useState(true);
  const [includeGreenscreen, setIncludeGreenscreen] = useState(true);
  const [includeRoto, setIncludeRoto] = useState(true);

  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');
  const [doneFile, setDoneFile] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const totalExposures = project.frames.reduce((s, f) => s + (f.hold || 1), 0);
  const outWidth = Math.round(project.resolution.width * scale);
  const outHeight = Math.round(project.resolution.height * scale);

  const handleExport = async () => {
    setExporting(true);
    setProgress(0);
    setError(null);
    setWarning(null);
    setDoneFile(null);

    try {
      const res = await exportFramixProject(project, {
        format,
        fps,
        width: outWidth,
        height: outHeight,
        includeAudio,
        includeEffects,
        includeGreenscreen,
        includeRoto,
        onProgress: (pct, txt) => {
          setProgress(pct);
          setStatusText(txt);
        },
      });
      setDoneFile(res.filename);
      if (res.warning) setWarning(res.warning);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export fehlgeschlagen.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6">
      <div className="w-full max-w-2xl overflow-hidden rounded-xl border border-[#272c37] bg-[#15181e] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#242934] px-6 py-4">
          <div className="flex items-center gap-2.5">
            <Film className="h-5 w-5 text-[#e0533c]" />
            <h2 className="font-display text-lg font-bold text-white">
              Film &amp; Projekt exportieren
            </h2>
          </div>
          <button
            onClick={onClose}
            disabled={exporting}
            className="rounded-lg p-1.5 text-[#8b94a5] hover:bg-[#222732] hover:text-white disabled:opacity-40"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-5 p-6">
          {/* Format Picker */}
          <div>
            <label className="mb-2 block text-xs font-semibold text-[#9aa3b2]">
              Zielformat wählen
            </label>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {FORMAT_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  disabled={exporting}
                  onClick={() => setFormat(opt.id)}
                  className={`rounded-lg border px-3.5 py-2.5 text-left transition-colors ${
                    format === opt.id
                      ? 'border-[#e0533c] bg-[#e0533c]/12 text-white'
                      : 'border-[#262c38] bg-[#11141a] text-[#b4bccb] hover:border-[#374051]'
                  }`}
                >
                  <div className="text-sm font-semibold">{opt.title}</div>
                  <div className="mt-0.5 text-xs text-[#8b94a5]">{opt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Technical Settings */}
          {format !== 'frmp' && (
            <div className="grid grid-cols-1 gap-4 rounded-lg border border-[#242934] bg-[#101318] p-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-medium text-[#9aa3b2]">
                  Export-Bildrate (FPS)
                </label>
                <select
                  value={fps}
                  disabled={exporting}
                  onChange={(e) => setFps(Number(e.target.value))}
                  className="w-full rounded-md border border-[#2a303c] bg-[#15181e] px-2.5 py-1.5 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                >
                  <option value={12}>12 fps</option>
                  <option value={15}>15 fps</option>
                  <option value={24}>24 fps</option>
                  <option value={25}>25 fps</option>
                  <option value={30}>30 fps</option>
                </select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-[#9aa3b2]">
                  Auflösung ({outWidth}×{outHeight})
                </label>
                <select
                  value={scale}
                  disabled={exporting}
                  onChange={(e) => setScale(Number(e.target.value))}
                  className="w-full rounded-md border border-[#2a303c] bg-[#15181e] px-2.5 py-1.5 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                >
                  <option value={1}>100% ({project.resolution.width}×{project.resolution.height})</option>
                  <option value={0.5}>50% (Schneller Export)</option>
                </select>
              </div>

              <div className="col-span-full flex flex-wrap gap-x-5 gap-y-2 pt-1 text-xs text-[#c7cdd8]">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeEffects}
                    onChange={(e) => setIncludeEffects(e.target.checked)}
                    disabled={exporting}
                  />
                  Effekte &amp; Farbkorrektur
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeGreenscreen}
                    onChange={(e) => setIncludeGreenscreen(e.target.checked)}
                    disabled={exporting}
                  />
                  Greenscreen-Keying
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeRoto}
                    onChange={(e) => setIncludeRoto(e.target.checked)}
                    disabled={exporting}
                  />
                  Rotoskopie &amp; Rig-Entfernung
                </label>
                {(format === 'webm' || format === 'mp4') && (
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={includeAudio}
                      onChange={(e) => setIncludeAudio(e.target.checked)}
                      disabled={exporting}
                    />
                    Dialog-Tonspur mischen ({project.audioClips.length} Clips)
                  </label>
                )}
              </div>
              <p className="col-span-full text-[11px] text-[#8b94a5]">
                Hinweis: Eigene Animations-Hilfslinien werden automatisch ausgeblendet und sind im exportierten Video nicht sichtbar.
              </p>
            </div>
          )}

          {/* Progress / Feedback */}
          {(exporting || doneFile) && (
            <div className="rounded-lg border border-[#262c38] bg-[#101318] p-4">
              <div className="mb-2 flex items-center justify-between text-xs">
                <span className="text-[#c7cdd8]">{statusText}</span>
                <span className="font-mono text-white tabular-nums">{progress}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#222732]">
                <div
                  className="h-full rounded-full bg-[#e0533c] transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>
              {doneFile && (
                <div className="mt-3 flex items-center gap-2 text-xs text-[#4ade80]">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>Heruntergeladen: {doneFile}</span>
                </div>
              )}
              {warning && (
                <p className="mt-2 text-xs text-[#fbbf24]">{warning}</p>
              )}
            </div>
          )}

          {error && (
            <div className="rounded-lg border border-[#7f1d1d] bg-[#2a1215] px-4 py-3 text-xs text-[#fca5a5]">
              {error}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-[#242934] bg-[#111419] px-6 py-4">
          <span className="font-mono text-xs text-[#8b94a5] tabular-nums">
            {project.frames.length} Bilder · {totalExposures} Belichtungen ·{' '}
            {(totalExposures / Math.max(1, fps)).toFixed(1)}s
          </span>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={exporting}
              className="rounded-lg border border-[#2a303c] px-4 py-2 text-sm font-medium text-[#c7cdd8] hover:bg-[#1e232d] disabled:opacity-40"
            >
              Schließen
            </button>
            <button
              type="button"
              onClick={handleExport}
              disabled={exporting || (format !== 'frmp' && project.frames.length === 0)}
              className="flex items-center gap-2 rounded-lg bg-[#e0533c] px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#c94530] disabled:opacity-50"
            >
              <Download className="h-4 w-4" />
              {exporting ? 'Exportiere...' : 'Export starten'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
