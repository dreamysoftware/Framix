import { useEffect, useRef, useState } from 'react';
import {
  Bell,
  Circle,
  Copy,
  Eraser,
  Eye,
  EyeOff,
  FlipHorizontal,
  FlipVertical,
  Mic,
  Minus,
  Move,
  PenTool,
  Pipette,
  RefreshCw,
  RotateCcw,
  ScanSearch,
  Sparkles,
  Spline,
  Square,
  Timer,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  AudioTrackClip,
  CameraSettings,
  CustomGuide,
  DEFAULT_EFFECTS,
  EffectPreset,
  FrameEffects,
  FramixFrame,
  GreenscreenSettings,
  SafeGuideType,
  StudioMode,
  VirtualPuppetPose,
} from '../types/framix';
import { GreenscreenScanResult } from '../utils/compositor';
import { ViewportTool } from './ViewportStage';

interface InspectorPanelProps {
  mode: StudioMode;
  cameras: MediaDeviceInfo[];
  selectedCameraId: string;
  onSelectCamera: (id: string) => void;
  onRefreshCameras: () => void;
  cameraSettings: CameraSettings;
  onUpdateCameraSettings: (patch: Partial<CameraSettings>) => void;
  onionCount: number;
  onChangeOnionCount: (n: number) => void;
  onionOpacity: number;
  onChangeOnionOpacity: (v: number) => void;
  differenceMatte: boolean;
  onToggleDifferenceMatte: () => void;
  timelapseIntervalSec: number;
  onChangeTimelapseSec: (sec: number) => void;
  motionAlertsEnabled: boolean;
  onToggleMotionAlerts: (enabled: boolean) => void;
  puppetPose: VirtualPuppetPose;
  onChangePuppetPose: (updater: (p: VirtualPuppetPose) => VirtualPuppetPose) => void;

  // Custom Guides & Roto
  activeTool: ViewportTool;
  onChangeActiveTool: (t: ViewportTool) => void;
  guides: CustomGuide[];
  selectedGuideId: string | null;
  onSelectGuideId: (id: string | null) => void;
  guideColor: string;
  onChangeGuideColor: (c: string) => void;
  guideDashed: boolean;
  onToggleGuideDashed: () => void;
  showGuides: boolean;
  onToggleShowGuides: () => void;
  onAddQuickGuide: (kind: 'horizontal' | 'vertical') => void;
  onUpdateGuide: (id: string, patch: Partial<CustomGuide>) => void;
  onDeleteGuide: (id: string) => void;

  // Greenscreen
  greenscreen: GreenscreenSettings;
  onUpdateGreenscreen: (patch: Partial<GreenscreenSettings>) => void;
  onScanGreenscreen: () => void;
  greenscreenScanResult: GreenscreenScanResult | null;

  selectedFrame: FramixFrame | null;
  selectedIndex: number;
  isLiveMode: boolean;
  onSelectFrameForEdit: (idx: number) => void;
  rotoColor: string;
  onChangeRotoColor: (c: string) => void;
  rotoSize: number;
  onChangeRotoSize: (s: number) => void;
  rotoOpacity: number;
  onChangeRotoOpacity: (o: number) => void;
  rotoOnionSkin: boolean;
  onToggleRotoOnionSkin: () => void;
  onClearFrameRoto: () => void;
  onCopyPrevRoto: () => void;

  cleanPlateDataUrl?: string | null;
  onSetCleanPlateFromCurrent: () => void;
  onClearCleanPlate: () => void;

  // Effects
  onUpdateFrameEffects: (patch: Partial<FrameEffects>) => void;
  onApplyEffectsToAll: (effects: FrameEffects) => void;

  // Audio & Dialogue
  audioClips: AudioTrackClip[];
  onAddAudioClip: (clip: AudioTrackClip) => void;
  onUpdateAudioClip: (id: string, patch: Partial<AudioTrackClip>) => void;
  onDeleteAudioClip: (id: string) => void;
  currentFrameCursor: number;
}

const ROTO_COLORS = ['#e0533c', '#f59e0b', '#38bdf8', '#4ade80', '#ffffff', '#000000'];
const GUIDE_COLORS = ['#38bdf8', '#f59e0b', '#e0533c', '#4ade80', '#ffffff'];

const PRESETS: { id: EffectPreset; label: string }[] = [
  { id: 'none', label: 'Original' },
  { id: 'cinematic', label: 'Kino Warm' },
  { id: 'noir', label: 'Film Noir' },
  { id: 'warm_clay', label: 'Ton-Studio' },
  { id: 'kodachrome', label: 'Kodachrome' },
];

export default function InspectorPanel({
  mode,
  cameras,
  selectedCameraId,
  onSelectCamera,
  onRefreshCameras,
  cameraSettings,
  onUpdateCameraSettings,
  onionCount,
  onChangeOnionCount,
  onionOpacity,
  onChangeOnionOpacity,
  differenceMatte,
  onToggleDifferenceMatte,
  timelapseIntervalSec,
  onChangeTimelapseSec,
  motionAlertsEnabled,
  onToggleMotionAlerts,
  puppetPose,
  onChangePuppetPose,
  activeTool,
  onChangeActiveTool,
  guides,
  selectedGuideId,
  onSelectGuideId,
  guideColor,
  onChangeGuideColor,
  guideDashed,
  onToggleGuideDashed,
  showGuides,
  onToggleShowGuides,
  onAddQuickGuide,
  onUpdateGuide,
  onDeleteGuide,
  greenscreen,
  onUpdateGreenscreen,
  onScanGreenscreen,
  greenscreenScanResult,
  selectedFrame,
  selectedIndex,
  isLiveMode,
  onSelectFrameForEdit,
  rotoColor,
  onChangeRotoColor,
  rotoSize,
  onChangeRotoSize,
  rotoOpacity,
  onChangeRotoOpacity,
  rotoOnionSkin,
  onToggleRotoOnionSkin,
  onClearFrameRoto,
  onCopyPrevRoto,
  cleanPlateDataUrl,
  onSetCleanPlateFromCurrent,
  onClearCleanPlate,
  onUpdateFrameEffects,
  onApplyEffectsToAll,
  audioClips,
  onAddAudioClip,
  onUpdateAudioClip,
  onDeleteAudioClip,
  currentFrameCursor,
}: InspectorPanelProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);
  const [clipName, setClipName] = useState('Dialog-Take 1');
  const recorderRef = useRef<MediaRecorder | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const meterRafRef = useRef<number>(0);
  const recordedChunksRef = useRef<BlobPart[]>([]);
  const audioFileRef = useRef<HTMLInputElement | null>(null);
  const gsBgInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    return () => {
      cancelAnimationFrame(meterRafRef.current);
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => undefined);
      }
    };
  }, []);

  const extractPeaksFromBlob = async (blob: Blob): Promise<{ durationSec: number; peaks: number[] }> => {
    try {
      const ctx = new AudioContext();
      const buf = await blob.arrayBuffer();
      const decoded = await ctx.decodeAudioData(buf);
      const data = decoded.getChannelData(0);
      const buckets = 24;
      const step = Math.max(1, Math.floor(data.length / buckets));
      const peaks: number[] = [];
      for (let i = 0; i < buckets; i++) {
        let max = 0;
        for (let j = 0; j < step; j++) {
          const v = Math.abs(data[i * step + j] || 0);
          if (v > max) max = v;
        }
        peaks.push(Math.min(1, max * 1.4));
      }
      const durationSec = decoded.duration;
      await ctx.close();
      return { durationSec, peaks };
    } catch {
      return { durationSec: 2.0, peaks: [0.3, 0.6, 0.8, 0.5, 0.7, 0.4, 0.6, 0.3] };
    }
  };

  const startMicRecording = async () => {
    setMicError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const dataArr = new Uint8Array(analyser.frequencyBinCount);

      const updateMeter = () => {
        analyser.getByteFrequencyData(dataArr);
        const avg = dataArr.reduce((a, b) => a + b, 0) / dataArr.length;
        setMicLevel(Math.min(100, Math.round((avg / 128) * 100)));
        meterRafRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();

      recordedChunksRef.current = [];
      const rec = new MediaRecorder(stream);
      recorderRef.current = rec;
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };
      rec.onstop = async () => {
        cancelAnimationFrame(meterRafRef.current);
        setMicLevel(0);
        stream.getTracks().forEach((t) => t.stop());
        ctx.close().catch(() => undefined);

        const blob = new Blob(recordedChunksRef.current, { type: rec.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const dataUrl = String(reader.result || '');
          const { durationSec, peaks } = await extractPeaksFromBlob(blob);
          onAddAudioClip({
            id: `aud_${Date.now()}`,
            name: clipName.trim() || `Dialog ${audioClips.length + 1}`,
            dataUrl,
            startFrame: currentFrameCursor,
            durationSec,
            volume: 1,
            muted: false,
            waveformPeaks: peaks,
            createdAt: Date.now(),
          });
          setClipName(`Dialog-Take ${audioClips.length + 2}`);
        };
        reader.readAsDataURL(blob);
      };

      rec.start();
      setIsRecording(true);
    } catch {
      setMicError('Mikrofon-Zugriff verweigert oder kein Mikrofon angeschlossen.');
    }
  };

  const stopMicRecording = () => {
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const handleImportAudio = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = async () => {
      const dataUrl = String(reader.result || '');
      const { durationSec, peaks } = await extractPeaksFromBlob(file);
      onAddAudioClip({
        id: `aud_${Date.now()}`,
        name: file.name.replace(/\.[^.]+$/, ''),
        dataUrl,
        startFrame: currentFrameCursor,
        durationSec,
        volume: 1,
        muted: false,
        waveformPeaks: peaks,
        createdAt: Date.now(),
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleUploadGsBg = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      onUpdateGreenscreen({
        backgroundMode: 'image',
        backgroundImageDataUrl: String(reader.result || ''),
        enabled: true,
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const currentEffects = selectedFrame?.effects || DEFAULT_EFFECTS;

  return (
    <aside className="flex w-full shrink-0 flex-col overflow-y-auto border-t border-[#242934] bg-[#12151a] p-4 lg:w-[335px] lg:border-l lg:border-t-0">
      {/* 1. CAPTURE & CAMERA INSPECTOR */}
      {(mode === 'capture' || mode === 'timeline') && (
        <div className="space-y-5">
          <div>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
                Kameraquelle
              </h3>
              <button
                onClick={onRefreshCameras}
                className="flex items-center gap-1 text-xs text-[#9aa3b2] hover:text-white"
                title="Kameras neu suchen"
              >
                <RefreshCw className="h-3 w-3" />
                Suchen
              </button>
            </div>

            <select
              value={selectedCameraId}
              onChange={(e) => onSelectCamera(e.target.value)}
              className="w-full rounded-lg border border-[#272c37] bg-[#0e1013] px-3 py-2 text-xs text-white focus:border-[#e0533c] focus:outline-none"
            >
              {cameras.map((cam, idx) => (
                <option key={cam.deviceId} value={cam.deviceId}>
                  {cam.label || `Kamera ${idx + 1}`}
                </option>
              ))}
              <option value="virtual">Virtuelle Studio-Bühne (Test-Armatur)</option>
            </select>

            <div className="mt-2.5 grid grid-cols-2 gap-2">
              <button
                onClick={() => onUpdateCameraSettings({ mirrorX: !cameraSettings.mirrorX })}
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 text-xs transition-colors ${
                  cameraSettings.mirrorX
                    ? 'border-[#e0533c] bg-[#e0533c]/15 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#a5aebb]'
                }`}
              >
                <FlipHorizontal className="h-3.5 w-3.5" />
                Spiegeln H
              </button>
              <button
                onClick={() => onUpdateCameraSettings({ mirrorY: !cameraSettings.mirrorY })}
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 text-xs transition-colors ${
                  cameraSettings.mirrorY
                    ? 'border-[#e0533c] bg-[#e0533c]/15 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#a5aebb]'
                }`}
              >
                <FlipVertical className="h-3.5 w-3.5" />
                Spiegeln V
              </button>
            </div>
          </div>

          <div className="border-t border-[#222732] pt-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
                Zwiebelschalen-Technik
              </h3>
              <span className="font-mono text-xs text-white tabular-nums">
                {Math.round(onionOpacity * 100)}%
              </span>
            </div>

            <input
              type="range"
              min={0}
              max={85}
              value={Math.round(onionOpacity * 100)}
              onChange={(e) => onChangeOnionOpacity(Number(e.target.value) / 100)}
              className="w-full"
            />

            <div className="mt-2.5 flex items-center justify-between text-xs">
              <span className="text-[#8b94a5]">Vorherige Bilder:</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4].map((n) => (
                  <button
                    key={n}
                    onClick={() => onChangeOnionCount(n)}
                    className={`rounded px-2 py-0.5 font-mono tabular-nums ${
                      onionCount === n
                        ? 'bg-[#e0533c] text-white'
                        : 'bg-[#1a1f27] text-[#9aa3b2] hover:text-white'
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={onToggleDifferenceMatte}
              className={`mt-2.5 w-full rounded-md border py-1.5 text-xs font-medium transition-colors ${
                differenceMatte
                  ? 'border-[#f59e0b] bg-[#f59e0b]/15 text-[#fde68a]'
                  : 'border-[#272c37] bg-[#171b22] text-[#a5aebb] hover:text-white'
              }`}
            >
              Unterschieds-Matte (Alignment)
            </button>
          </div>

          {/* Motion Jump Alerts Toggle */}
          <div className="border-t border-[#222732] pt-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#c7cdd8]">
                <Bell className="h-3.5 w-3.5 text-[#f59e0b]" />
                <span>Flüssigkeits-Warnung</span>
              </div>
              <button
                onClick={() => onToggleMotionAlerts(!motionAlertsEnabled)}
                className={`rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ${
                  motionAlertsEnabled
                    ? 'border-[#f59e0b]/60 bg-[#f59e0b]/15 text-[#fde68a]'
                    : 'border-[#272c37] bg-[#171b22] text-[#8b94a5]'
                }`}
              >
                {motionAlertsEnabled ? 'Aktiv' : 'Aus'}
              </button>
            </div>
            <p className="mt-1 text-[11px] text-[#8b94a5]">
              Warnt bei großen Bewegungssprüngen zwischen zwei Bildern.
            </p>
          </div>

          <div className="border-t border-[#222732] pt-4">
            <h3 className="mb-2 text-xs font-semibold tracking-wide text-[#9aa3b2]">
              Raster &amp; Belichtung
            </h3>
            <select
              value={cameraSettings.guide}
              onChange={(e) =>
                onUpdateCameraSettings({ guide: e.target.value as SafeGuideType })
              }
              className="mb-3 w-full rounded-lg border border-[#272c37] bg-[#0e1013] px-3 py-1.5 text-xs text-white focus:border-[#e0533c] focus:outline-none"
            >
              <option value="none">Kein Standard-Raster</option>
              <option value="thirds">Drittel-Regel (3×3)</option>
              <option value="crosshair">Zentrum &amp; Fadenkreuz</option>
              <option value="safe169">TV / Titel Safe-Area</option>
              <option value="cinema239">Kino-Cinemascope (2.39:1)</option>
            </select>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-[#8b94a5]">
                <span>Live-Helligkeit</span>
                <span className="font-mono tabular-nums">{cameraSettings.brightness}</span>
              </div>
              <input
                type="range"
                min={-40}
                max={40}
                value={cameraSettings.brightness}
                onChange={(e) =>
                  onUpdateCameraSettings({ brightness: Number(e.target.value) })
                }
                className="w-full"
              />
              <div className="flex justify-between text-[#8b94a5]">
                <span>Live-Kontrast</span>
                <span className="font-mono tabular-nums">{cameraSettings.contrast}</span>
              </div>
              <input
                type="range"
                min={-40}
                max={40}
                value={cameraSettings.contrast}
                onChange={(e) =>
                  onUpdateCameraSettings({ contrast: Number(e.target.value) })
                }
                className="w-full"
              />
            </div>
          </div>

          <div className="border-t border-[#222732] pt-4">
            <div className="mb-2 flex items-center justify-between text-xs font-semibold text-[#9aa3b2]">
              <span className="flex items-center gap-1.5">
                <Timer className="h-3.5 w-3.5" />
                Zeitraffer-Automatik
              </span>
              <span className="font-mono text-white tabular-nums">
                {timelapseIntervalSec === 0 ? 'Aus' : `${timelapseIntervalSec}s`}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1.5 text-xs">
              {[0, 2, 5, 10].map((sec) => (
                <button
                  key={sec}
                  onClick={() => onChangeTimelapseSec(sec)}
                  className={`rounded-md border py-1 font-mono tabular-nums ${
                    timelapseIntervalSec === sec
                      ? 'border-[#e0533c] bg-[#e0533c]/20 text-white'
                      : 'border-[#272c37] bg-[#171b22] text-[#9aa3b2]'
                  }`}
                >
                  {sec === 0 ? 'Aus' : `${sec}s`}
                </button>
              ))}
            </div>
          </div>

          {selectedCameraId === 'virtual' && (
            <div className="border-t border-[#222732] pt-4">
              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
                  Bühnen-Puppe &amp; Kulisse
                </h3>
                <label className="flex items-center gap-1.5 text-[11px] text-[#86efac]">
                  <input
                    type="checkbox"
                    checked={Boolean(puppetPose.greenScreenBackdrop)}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({
                        ...p,
                        greenScreenBackdrop: e.target.checked,
                      }))
                    }
                  />
                  Greenscreen-Wand
                </label>
              </div>
              <div className="space-y-2 text-xs text-[#8b94a5]">
                <label className="block">
                  Kopfneigung ({puppetPose.headTilt}°)
                  <input
                    type="range"
                    min={-35}
                    max={35}
                    value={puppetPose.headTilt}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({ ...p, headTilt: Number(e.target.value) }))
                    }
                    className="w-full"
                  />
                </label>
                <label className="block">
                  Linker Arm ({puppetPose.leftArmAngle}°)
                  <input
                    type="range"
                    min={-140}
                    max={140}
                    value={puppetPose.leftArmAngle}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({ ...p, leftArmAngle: Number(e.target.value) }))
                    }
                    className="w-full"
                  />
                </label>
                <label className="block">
                  Rechter Arm ({puppetPose.rightArmAngle}°)
                  <input
                    type="range"
                    min={-140}
                    max={140}
                    value={puppetPose.rightArmAngle}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({ ...p, rightArmAngle: Number(e.target.value) }))
                    }
                    className="w-full"
                  />
                </label>
                <label className="block">
                  Linkes Bein ({puppetPose.leftLegAngle}°)
                  <input
                    type="range"
                    min={-60}
                    max={60}
                    value={puppetPose.leftLegAngle}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({ ...p, leftLegAngle: Number(e.target.value) }))
                    }
                    className="w-full"
                  />
                </label>
                <label className="block">
                  Rechtes Bein ({puppetPose.rightLegAngle}°)
                  <input
                    type="range"
                    min={-60}
                    max={60}
                    value={puppetPose.rightLegAngle}
                    onChange={(e) =>
                      onChangePuppetPose((p) => ({ ...p, rightLegAngle: Number(e.target.value) }))
                    }
                    className="w-full"
                  />
                </label>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. CUSTOM GUIDES, GREENSCREEN DETECTOR & ROTOSCOPING */}
      {mode === 'guides_roto' && (
        <div className="space-y-5">
          {/* Custom Hilfslinien Section */}
          <div>
            <div className="mb-1.5 flex items-center justify-between">
              <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
                Eigene Hilfslinien (nur Vorschau)
              </h3>
              <button
                onClick={onToggleShowGuides}
                className="text-xs text-[#9aa3b2] hover:text-white"
                title="Hilfslinien ein/ausblenden"
              >
                {showGuides ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
              </button>
            </div>
            <p className="mb-2.5 text-[11px] text-[#8b94a5]">
              Zum Ausrichten von Bewegungen &amp; Bögen. Im exportierten Video unsichtbar.
            </p>

            <div className="grid grid-cols-2 gap-1.5 text-xs">
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'select_move' ? 'none' : 'select_move')
                }
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'select_move'
                    ? 'border-[#38bdf8] bg-[#38bdf8]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Move className="h-3.5 w-3.5" />
                Verschieben
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'guide_line' ? 'none' : 'guide_line')
                }
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'guide_line'
                    ? 'border-[#38bdf8] bg-[#38bdf8]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Minus className="h-3.5 w-3.5" />
                Linie ziehen
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'guide_path' ? 'none' : 'guide_path')
                }
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'guide_path'
                    ? 'border-[#38bdf8] bg-[#38bdf8]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Spline className="h-3.5 w-3.5" />
                Bewegungspfad
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'guide_circle' ? 'none' : 'guide_circle')
                }
                className={`flex items-center justify-center gap-1.5 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'guide_circle'
                    ? 'border-[#38bdf8] bg-[#38bdf8]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Circle className="h-3.5 w-3.5" />
                Kreis / Bogen
              </button>
            </div>

            <div className="mt-2 grid grid-cols-2 gap-1.5 text-xs">
              <button
                onClick={() => onAddQuickGuide('horizontal')}
                className="rounded-md border border-[#272c37] bg-[#171b22] py-1 text-[#c7cdd8] hover:text-white"
              >
                + Waagerecht
              </button>
              <button
                onClick={() => onAddQuickGuide('vertical')}
                className="rounded-md border border-[#272c37] bg-[#171b22] py-1 text-[#c7cdd8] hover:text-white"
              >
                + Senkrecht
              </button>
            </div>

            <div className="mt-2.5 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                {GUIDE_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => onChangeGuideColor(c)}
                    className={`h-5 w-5 rounded-full border ${
                      guideColor === c ? 'border-white ring-2 ring-[#38bdf8]' : 'border-[#394152]'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
              <label className="flex items-center gap-1.5 text-[11px] text-[#c7cdd8]">
                <input
                  type="checkbox"
                  checked={guideDashed}
                  onChange={onToggleGuideDashed}
                />
                Gestrichelt
              </label>
            </div>

            {guides.length > 0 && (
              <div className="mt-2.5 space-y-1.5">
                {guides.map((g) => (
                  <div
                    key={g.id}
                    onClick={() => onSelectGuideId(g.id)}
                    className={`flex cursor-pointer items-center justify-between rounded-md border px-2.5 py-1.5 text-xs ${
                      selectedGuideId === g.id
                        ? 'border-[#38bdf8] bg-[#17212c] text-white'
                        : 'border-[#242934] bg-[#161a21] text-[#c7cdd8]'
                    }`}
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span
                        className="h-2.5 w-2.5 shrink-0 rounded-full"
                        style={{ backgroundColor: g.color }}
                      />
                      <span className="truncate">{g.name}</span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onUpdateGuide(g.id, { visible: !g.visible });
                        }}
                        className="text-[#9aa3b2] hover:text-white"
                      >
                        {g.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteGuide(g.id);
                        }}
                        className="text-[#9aa3b2] hover:text-[#f87171]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Greenscreen Detector & Chroma Keyer */}
          <div className="border-t border-[#222732] pt-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
                Greenscreen-Erkenner
              </h3>
              <label className="flex items-center gap-1.5 text-xs text-[#c7cdd8]">
                <input
                  type="checkbox"
                  checked={greenscreen.enabled}
                  onChange={(e) => onUpdateGreenscreen({ enabled: e.target.checked })}
                />
                Aktiv
              </label>
            </div>

            <div className="flex gap-2">
              <button
                onClick={onScanGreenscreen}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-md bg-[#16a34a] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#15803d]"
              >
                <ScanSearch className="h-3.5 w-3.5" />
                Greenscreen erkennen
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(
                    activeTool === 'greenscreen_pick' ? 'select_move' : 'greenscreen_pick'
                  )
                }
                className={`flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs ${
                  activeTool === 'greenscreen_pick'
                    ? 'border-[#4ade80] bg-[#16a34a]/25 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
                title="Farbe aus Bild aufnehmen"
              >
                <Pipette className="h-3.5 w-3.5" />
                Pipette
              </button>
            </div>

            {greenscreenScanResult && (
              <div
                className={`mt-2 rounded-md border px-2.5 py-2 text-[11px] ${
                  greenscreenScanResult.detected
                    ? 'border-[#16a34a]/50 bg-[#102016] text-[#86efac]'
                    : 'border-[#333a48] bg-[#171b22] text-[#b4bccb]'
                }`}
              >
                {greenscreenScanResult.message}
              </div>
            )}

            <div className="mt-3 space-y-2 text-xs text-[#8b94a5]">
              <div className="flex items-center justify-between">
                <span>Key-Farbe</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] text-white">
                    {greenscreen.keyColor}
                  </span>
                  <input
                    type="color"
                    value={greenscreen.keyColor}
                    onChange={(e) => onUpdateGreenscreen({ keyColor: e.target.value })}
                    className="h-6 w-8 cursor-pointer rounded border border-[#2a303c] bg-transparent"
                  />
                </div>
              </div>

              <div className="flex justify-between">
                <span>Toleranz</span>
                <span className="font-mono tabular-nums">{greenscreen.tolerance}</span>
              </div>
              <input
                type="range"
                min={15}
                max={120}
                value={greenscreen.tolerance}
                onChange={(e) =>
                  onUpdateGreenscreen({ tolerance: Number(e.target.value) })
                }
                className="w-full"
              />

              <div className="flex justify-between">
                <span>Kanten-Spill entfernen</span>
                <span className="font-mono tabular-nums">{greenscreen.spillSuppression}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={greenscreen.spillSuppression}
                onChange={(e) =>
                  onUpdateGreenscreen({ spillSuppression: Number(e.target.value) })
                }
                className="w-full"
              />

              <div className="pt-1">
                <label className="mb-1 block text-[11px] text-[#8b94a5]">
                  Ersatz-Hintergrund
                </label>
                <div className="flex gap-1.5">
                  <select
                    value={greenscreen.backgroundMode}
                    onChange={(e) =>
                      onUpdateGreenscreen({
                        backgroundMode: e.target.value as GreenscreenSettings['backgroundMode'],
                      })
                    }
                    className="flex-1 rounded border border-[#272c37] bg-[#0e1013] px-2 py-1 text-xs text-white"
                  >
                    <option value="dark">Dunkles Studio</option>
                    <option value="checker">Transparenz-Raster</option>
                    <option value="color">Eigene Farbe</option>
                    <option value="image">Eigenes Hintergrundbild</option>
                  </select>

                  {greenscreen.backgroundMode === 'color' && (
                    <input
                      type="color"
                      value={greenscreen.backgroundColor}
                      onChange={(e) =>
                        onUpdateGreenscreen({ backgroundColor: e.target.value })
                      }
                      className="h-7 w-8 cursor-pointer rounded border border-[#2a303c] bg-transparent"
                    />
                  )}
                  <button
                    onClick={() => gsBgInputRef.current?.click()}
                    className="rounded border border-[#272c37] bg-[#171b22] px-2 py-1 text-xs text-[#c7cdd8] hover:text-white"
                    title="Hintergrundbild hochladen"
                  >
                    <Upload className="h-3.5 w-3.5" />
                  </button>
                  <input
                    ref={gsBgInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleUploadGsBg}
                    className="hidden"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Rotoscoping & Rig-Remover Section */}
          <div className="border-t border-[#222732] pt-4">
            <h3 className="mb-2 text-xs font-semibold tracking-wide text-[#9aa3b2]">
              Rotoskopie &amp; Rig-Entfernung
            </h3>

            {isLiveMode && (
              <div className="mb-3 rounded-lg border border-[#2a303c] bg-[#161a22] p-2.5 text-xs text-[#b4bccb]">
                <p>Zum Zeichnen oder Rig-Entfernen ein aufgenommenes Foto wählen.</p>
                {selectedIndex >= 0 ? (
                  <button
                    onClick={() => onSelectFrameForEdit(selectedIndex)}
                    className="mt-1.5 rounded bg-[#e0533c] px-2.5 py-1 font-medium text-white"
                  >
                    Zum ausgewählten Bild wechseln
                  </button>
                ) : null}
              </div>
            )}

            <div className="grid grid-cols-3 gap-1.5 text-xs">
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'roto_pen' ? 'select_move' : 'roto_pen')
                }
                className={`flex items-center justify-center gap-1 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'roto_pen'
                    ? 'border-[#e0533c] bg-[#e0533c]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <PenTool className="h-3.5 w-3.5" />
                Stift
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'rig_remover' ? 'select_move' : 'rig_remover')
                }
                className={`flex items-center justify-center gap-1 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'rig_remover'
                    ? 'border-[#4ade80] bg-[#16a34a]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                Rig-Ex
              </button>
              <button
                onClick={() =>
                  onChangeActiveTool(activeTool === 'roto_eraser' ? 'select_move' : 'roto_eraser')
                }
                className={`flex items-center justify-center gap-1 rounded-md border py-1.5 font-medium transition-colors ${
                  activeTool === 'roto_eraser'
                    ? 'border-[#e0533c] bg-[#e0533c]/20 text-white'
                    : 'border-[#272c37] bg-[#171b22] text-[#c7cdd8]'
                }`}
              >
                <Eraser className="h-3.5 w-3.5" />
                Radierer
              </button>
            </div>

            {activeTool === 'rig_remover' && (
              <div className="mt-2.5 rounded-lg border border-[#24392c] bg-[#111c15] p-2.5 text-[11px] text-[#a7c4b2]">
                <div>
                  {cleanPlateDataUrl
                    ? 'Clean-Plate aktiv: Rigs einfach übermalen.'
                    : 'Alt+Klick setzt saubere Quellstelle oder direkt über das Rig malen.'}
                </div>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={onSetCleanPlateFromCurrent}
                    disabled={!selectedFrame}
                    className="flex-1 rounded bg-[#16a34a] px-2 py-1 font-medium text-white disabled:opacity-40"
                  >
                    Foto als Clean-Plate
                  </button>
                  {cleanPlateDataUrl && (
                    <button
                      onClick={onClearCleanPlate}
                      className="rounded border border-[#2c4435] px-2 py-1 text-[#bbf7d0]"
                    >
                      Lösen
                    </button>
                  )}
                </div>
              </div>
            )}

            <div className="mt-3 flex items-center gap-1.5">
              {ROTO_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => onChangeRotoColor(c)}
                  className={`h-6 w-6 rounded-full border ${
                    rotoColor === c ? 'border-white ring-2 ring-[#e0533c]' : 'border-[#394152]'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
              <input
                type="color"
                value={rotoColor}
                onChange={(e) => onChangeRotoColor(e.target.value)}
                className="ml-auto h-6 w-8 cursor-pointer rounded border border-[#2a303c] bg-transparent"
              />
            </div>

            <div className="mt-3 space-y-2 text-xs text-[#8b94a5]">
              <div className="flex justify-between">
                <span>Pinselstärke</span>
                <span className="font-mono tabular-nums">{rotoSize} px</span>
              </div>
              <input
                type="range"
                min={2}
                max={48}
                value={rotoSize}
                onChange={(e) => onChangeRotoSize(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between">
                <span>Deckkraft</span>
                <span className="font-mono tabular-nums">{Math.round(rotoOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                value={Math.round(rotoOpacity * 100)}
                onChange={(e) => onChangeRotoOpacity(Number(e.target.value) / 100)}
                className="w-full"
              />
            </div>

            <label className="mt-3 flex items-center gap-2 text-xs text-[#c7cdd8]">
              <input
                type="checkbox"
                checked={rotoOnionSkin}
                onChange={onToggleRotoOnionSkin}
              />
              Vorherige Rotoskopie durchpausen
            </label>

            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={onCopyPrevRoto}
                disabled={!selectedFrame || selectedIndex <= 0}
                className="flex items-center justify-center gap-1 rounded-md border border-[#272c37] bg-[#171b22] py-1.5 text-[#c7cdd8] hover:text-white disabled:opacity-35"
              >
                <Copy className="h-3 w-3" />
                Von Vorbild
              </button>
              <button
                onClick={onClearFrameRoto}
                disabled={!selectedFrame || selectedFrame.rotoStrokes.length === 0}
                className="flex items-center justify-center gap-1 rounded-md border border-[#272c37] bg-[#171b22] py-1.5 text-[#f87171] hover:bg-[#2a1719] disabled:opacity-35"
              >
                <Trash2 className="h-3 w-3" />
                Roto leeren
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. EFFECTS & COLOR GRADING INSPECTOR */}
      {mode === 'effects' && (
        <div className="space-y-4">
          <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
            Farbkorrektur &amp; Effekte
          </h3>

          {!selectedFrame ? (
            <p className="text-xs text-[#8b94a5]">
              Wähle ein Einzelbild in der Timeline aus, um Effekte anzuwenden.
            </p>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-1.5 text-xs">
                {PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => onUpdateFrameEffects({ preset: p.id })}
                    className={`rounded-md border px-2.5 py-1.5 text-left transition-colors ${
                      currentEffects.preset === p.id
                        ? 'border-[#e0533c] bg-[#e0533c]/15 text-white'
                        : 'border-[#272c37] bg-[#171b22] text-[#a5aebb] hover:text-white'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              <div className="space-y-2.5 border-t border-[#222732] pt-3 text-xs text-[#8b94a5]">
                {(
                  [
                    ['Helligkeit', 'brightness', -50, 50],
                    ['Kontrast', 'contrast', -50, 50],
                    ['Sättigung', 'saturation', -100, 100],
                    ['Farbtemperatur', 'temperature', -50, 50],
                    ['Vignette', 'vignette', 0, 100],
                    ['Filmkorn', 'grain', 0, 100],
                  ] as const
                ).map(([label, key, min, max]) => (
                  <div key={key}>
                    <div className="flex justify-between">
                      <span>{label}</span>
                      <span className="font-mono text-white tabular-nums">
                        {currentEffects[key]}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={min}
                      max={max}
                      value={currentEffects[key]}
                      onChange={(e) =>
                        onUpdateFrameEffects({ [key]: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                ))}
              </div>

              <div className="space-y-2 border-t border-[#222732] pt-3">
                <button
                  onClick={() => onApplyEffectsToAll(currentEffects)}
                  className="w-full rounded-lg bg-[#e0533c] py-2 text-xs font-semibold text-white hover:bg-[#c94530]"
                >
                  Auf alle Frames anwenden
                </button>
                <button
                  onClick={() => onUpdateFrameEffects(DEFAULT_EFFECTS)}
                  className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#272c37] bg-[#171b22] py-1.5 text-xs text-[#c7cdd8] hover:text-white"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Effekte zurücksetzen
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* 4. AUDIO & DIALOGUE RECORDING INSPECTOR */}
      {mode === 'audio' && (
        <div className="space-y-4">
          <h3 className="text-xs font-semibold tracking-wide text-[#9aa3b2]">
            Dialoge aufnehmen &amp; Lip-Sync
          </h3>

          <div className="rounded-lg border border-[#252a36] bg-[#161a21] p-3">
            <label className="mb-1 block text-[11px] text-[#8b94a5]">Clip-Name</label>
            <input
              type="text"
              value={clipName}
              onChange={(e) => setClipName(e.target.value)}
              className="mb-3 w-full rounded border border-[#2c3340] bg-[#0e1013] px-2.5 py-1.5 text-xs text-white focus:border-[#e0533c] focus:outline-none"
            />

            <div className="mb-3">
              <div className="mb-1 flex justify-between text-[11px] text-[#8b94a5]">
                <span>Mikrofon-Pegel</span>
                <span className="font-mono tabular-nums">{micLevel}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#0e1013]">
                <div
                  className="h-full bg-[#4ade80] transition-all duration-75"
                  style={{ width: `${micLevel}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {!isRecording ? (
                <button
                  onClick={startMicRecording}
                  className="flex items-center justify-center gap-1.5 rounded-lg bg-[#e0533c] py-2 text-xs font-semibold text-white hover:bg-[#c94530]"
                >
                  <Mic className="h-3.5 w-3.5" />
                  Aufnehmen
                </button>
              ) : (
                <button
                  onClick={stopMicRecording}
                  className="flex items-center justify-center gap-1.5 rounded-lg bg-[#dc2626] py-2 text-xs font-semibold text-white"
                >
                  <Square className="h-3.5 w-3.5 fill-current" />
                  Stoppen
                </button>
              )}

              <button
                onClick={() => audioFileRef.current?.click()}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-[#2a303c] bg-[#1c212b] py-2 text-xs font-medium text-[#d1d7e3] hover:text-white"
              >
                <Upload className="h-3.5 w-3.5" />
                Audio laden
              </button>
            </div>
            <input
              ref={audioFileRef}
              type="file"
              accept="audio/*"
              onChange={handleImportAudio}
              className="hidden"
            />

            {micError && <p className="mt-2 text-xs text-[#fca5a5]">{micError}</p>}
          </div>

          <div className="space-y-2">
            <div className="text-xs font-medium text-[#8b94a5]">
              Aufgenommene Dialoge ({audioClips.length})
            </div>
            {audioClips.map((clip) => (
              <div
                key={clip.id}
                className="rounded-lg border border-[#252a36] bg-[#161a21] p-2.5 text-xs"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate font-semibold text-white">{clip.name}</span>
                  <button
                    onClick={() => onDeleteAudioClip(clip.id)}
                    className="text-[#8b94a5] hover:text-[#f87171]"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[11px] text-[#8b94a5]">
                  <span>Start ab Bild:</span>
                  <div className="flex items-center gap-1 font-mono">
                    <button
                      onClick={() =>
                        onUpdateAudioClip(clip.id, {
                          startFrame: Math.max(0, clip.startFrame - 1),
                        })
                      }
                      className="rounded bg-[#222732] px-1.5 py-0.5 text-white"
                    >
                      -
                    </button>
                    <span className="w-8 text-center text-white tabular-nums">
                      #{clip.startFrame + 1}
                    </span>
                    <button
                      onClick={() =>
                        onUpdateAudioClip(clip.id, { startFrame: clip.startFrame + 1 })
                      }
                      className="rounded bg-[#222732] px-1.5 py-0.5 text-white"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-2 text-[11px] text-[#8b94a5]">
                  <span>Pegel</span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round(clip.volume * 100)}
                    onChange={(e) =>
                      onUpdateAudioClip(clip.id, { volume: Number(e.target.value) / 100 })
                    }
                    className="flex-1"
                  />
                </div>
                <audio controls src={clip.dataUrl} className="mt-2 h-7 w-full" />
              </div>
            ))}
          </div>
        </div>
      )}
    </aside>
  );
}
