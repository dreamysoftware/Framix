import { useState } from 'react';
import { Check, Copy, Download, X } from 'lucide-react';
import cppHeader from '../../native/cpp/framix_core.hpp?raw';
import cppSource from '../../native/cpp/framix_core.cpp?raw';
import cmakeFile from '../../native/cpp/CMakeLists.txt?raw';
import pythonGui from '../../native/python/framix_gui.py?raw';
import pythonReqs from '../../native/python/requirements.txt?raw';

interface NativeCodeModalProps {
  onClose: () => void;
}

const NATIVE_FILES = [
  { id: 'python_gui', label: 'framix_gui.py (Python PySide6)', filename: 'framix_gui.py', content: pythonGui },
  { id: 'cpp_source', label: 'framix_core.cpp (C++20)', filename: 'framix_core.cpp', content: cppSource },
  { id: 'cpp_header', label: 'framix_core.hpp (C++20)', filename: 'framix_core.hpp', content: cppHeader },
  { id: 'cmake', label: 'CMakeLists.txt', filename: 'CMakeLists.txt', content: cmakeFile },
  { id: 'reqs', label: 'requirements.txt', filename: 'requirements.txt', content: pythonReqs },
];

export default function NativeCodeModal({ onClose }: NativeCodeModalProps) {
  const [activeId, setActiveId] = useState(NATIVE_FILES[0].id);
  const [copied, setCopied] = useState(false);

  const current = NATIVE_FILES.find((f) => f.id === activeId) || NATIVE_FILES[0];

  const handleCopy = async () => {
    await navigator.clipboard.writeText(current.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownload = () => {
    const blob = new Blob([current.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = current.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6">
      <div className="flex max-h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-[#272c37] bg-[#15181e]">
        <div className="flex items-center justify-between border-b border-[#272c37] px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Native C++20 &amp; Python Desktop-Architektur
            </h2>
            <p className="mt-0.5 text-xs text-[#8b94a5]">
              C++ Echtzeit-Frame-Compositor (pybind11) gekoppelt mit PySide6 / OpenCV Desktop-GUI
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-[#8b94a5] transition-colors hover:bg-[#222731] hover:text-white"
            aria-label="Schließen"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#272c37] bg-[#111419] px-6 py-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {NATIVE_FILES.map((file) => (
              <button
                key={file.id}
                onClick={() => setActiveId(file.id)}
                className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  file.id === activeId
                    ? 'bg-[#e0533c] text-white'
                    : 'bg-[#1b1f27] text-[#a5aebb] hover:bg-[#242934] hover:text-white'
                }`}
              >
                {file.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 whitespace-nowrap rounded-md border border-[#2d3340] bg-[#1b1f27] px-3 py-1.5 text-xs font-medium text-[#e2e6ee] transition-colors hover:bg-[#242934]"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-[#16a34a]" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Kopiert' : 'Kopieren'}
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 whitespace-nowrap rounded-md bg-[#262c38] px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-[#313949]"
            >
              <Download className="h-3.5 w-3.5" />
              Datei laden
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto bg-[#0c0e12] p-5">
          <pre className="font-mono text-xs leading-relaxed text-[#d1d7e3]">
            <code>{current.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
