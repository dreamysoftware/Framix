import { useEffect, useRef, useState } from 'react';
import splashStudioImg from '../assets/images/framix_splash_studio_1794586142192.jpg';
import framixAppIcon from '../assets/images/framix_app_icon.png';

interface SplashScreenProps {
  onReady: () => void;
  initTask: () => Promise<void>;
}

const BOOT_STEPS = [
  { pct: 18, label: 'Kamera- & Videoeingänge werden erkannt...' },
  { pct: 42, label: 'Echtzeit-Compositor & Zwiebelschalen-Engine laden...' },
  { pct: 68, label: 'Projekt-Tresor (.frmp) wird initialisiert...' },
  { pct: 88, label: 'Audio- & Dialogspur wird kalibriert...' },
  { pct: 100, label: 'Framix Studio bereit.' },
];

export default function SplashScreen({ onReady, initTask }: SplashScreenProps) {
  const [stepIdx, setStepIdx] = useState(0);
  const [progress, setProgress] = useState(8);
  const [imgError, setImgError] = useState(false);

  const initTaskRef = useRef(initTask);
  const onReadyRef = useRef(onReady);
  initTaskRef.current = initTask;
  onReadyRef.current = onReady;

  useEffect(() => {
    let cancelled = false;

    const runBoot = async () => {
      const dbPromise = Promise.race([
        initTaskRef.current().catch(() => undefined),
        new Promise<void>((resolve) => window.setTimeout(resolve, 1500)),
      ]);

      for (let i = 0; i < BOOT_STEPS.length; i++) {
        if (cancelled) return;
        setStepIdx(i);
        setProgress(BOOT_STEPS[i].pct);
        if (i === 2) {
          await dbPromise;
        }
        await new Promise((r) => setTimeout(r, i === BOOT_STEPS.length - 1 ? 450 : 750));
      }

      if (!cancelled) {
        onReadyRef.current();
      }
    };

    runBoot();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#090b0e] p-6">
      <div className="w-full max-w-[760px] overflow-hidden rounded-xl border border-[#272c37] bg-[#14171d] shadow-2xl">
        {/* Studio Artwork Image */}
        <div className="relative aspect-video w-full overflow-hidden bg-[#0e1013]">
          {!imgError ? (
            <img
              src={splashStudioImg}
              alt="Framix Stop-Motion Animationsstudio"
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#191d26] via-[#12151b] to-[#0b0d10]">
              <img
                src={framixAppIcon}
                alt="Framix Icon"
                className="mb-3 h-16 w-16 rounded-2xl object-cover shadow-lg ring-1 ring-white/10"
              />
              <span className="font-display text-xl font-semibold text-[#f1f3f5]">
                Framix Studio
              </span>
            </div>
          )}

          {/* Measured bottom scrim for crisp 4.5:1 legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#14171d] via-[#14171d]/35 to-transparent" />

          <div className="absolute bottom-5 left-7 right-7 flex items-end justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={framixAppIcon}
                alt="Framix Icon"
                className="h-14 w-14 shrink-0 rounded-2xl object-cover shadow-xl ring-1 ring-white/15"
              />
              <div>
                <h1 className="font-display text-4xl font-bold tracking-tight text-white">
                  Framix
                </h1>
                <p className="mt-1 text-sm text-[#c7cdd8]">
                  Stop-Motion Studio für Einzelbildaufnahme, Rotoskopie &amp; Schnitt
                </p>
              </div>
            </div>
            <span className="font-mono text-xs text-[#a5aebb] tabular-nums">
              .frmp · C++ / Python Core
            </span>
          </div>
        </div>

        {/* Real Progress Bar */}
        <div className="px-7 py-5">
          <div className="mb-2.5 flex items-center justify-between text-xs">
            <span className="text-[#c7cdd8]">{BOOT_STEPS[stepIdx].label}</span>
            <span className="font-mono font-medium text-[#f1f3f5] tabular-nums">
              {progress}%
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-[#222731]">
            <div
              className="h-full rounded-full bg-[#e0533c] transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
