import { useRef, useState } from 'react';
import {
  Code2,
  Copy,
  Download,
  Film,
  Folder,
  FolderPlus,
  Pencil,
  Plus,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  FramixFolder,
  FramixProject,
  RESOLUTION_PRESETS,
  ResolutionPreset,
} from '../types/framix';
import { downloadFrmpFile, parseFrmpFile } from '../utils/frmpStorage';
import framixAppIcon from '../assets/images/framix_app_icon.png';

interface StartScreenProps {
  projects: FramixProject[];
  folders: FramixFolder[];
  onOpenProject: (project: FramixProject) => void;
  onCreateProject: (params: {
    name: string;
    fps: number;
    resolution: ResolutionPreset;
    folderId: string | null;
  }) => void;
  onDeleteProject: (id: string) => void;
  onDuplicateProject: (project: FramixProject) => void;
  onMoveProjectToFolder: (projectId: string, folderId: string | null) => void;
  onImportProject: (project: FramixProject) => void;
  onCreateFolder: (name: string) => void;
  onRenameFolder: (id: string, name: string) => void;
  onDeleteFolder: (id: string) => void;
  onShowNativeCode: () => void;
}

function formatDuration(project: FramixProject): string {
  const totalExposures = project.frames.reduce((sum, f) => sum + (f.hold || 1), 0);
  const secs = totalExposures / Math.max(1, project.fps);
  const mins = Math.floor(secs / 60);
  const rem = (secs % 60).toFixed(1).padStart(4, '0');
  return `${String(mins).padStart(2, '0')}:${rem}`;
}

function formatDate(ts: number): string {
  return new Intl.DateTimeFormat('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ts));
}

export default function StartScreen({
  projects,
  folders,
  onOpenProject,
  onCreateProject,
  onDeleteProject,
  onDuplicateProject,
  onMoveProjectToFolder,
  onImportProject,
  onCreateFolder,
  onRenameFolder,
  onDeleteFolder,
  onShowNativeCode,
}: StartScreenProps) {
  const [selectedFolderId, setSelectedFolderId] = useState<'all' | 'unsorted' | string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewModal, setShowNewModal] = useState(false);
  const [newName, setNewName] = useState('Neuer Stop-Motion Film');
  const [newFps, setNewFps] = useState(12);
  const [newResIdx, setNewResIdx] = useState(1); // Full HD default
  const [newTargetFolder, setNewTargetFolder] = useState<string>('');

  const [creatingFolder, setCreatingFolder] = useState(false);
  const [folderNameInput, setFolderNameInput] = useState('');
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [editingFolderName, setEditingFolderName] = useState('');
  const [importError, setImportError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const filteredProjects = projects.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.trim().toLowerCase());
    if (!matchesSearch) return false;
    if (selectedFolderId === 'all') return true;
    if (selectedFolderId === 'unsorted') return !p.folderId;
    return p.folderId === selectedFolderId;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newName.trim() || 'Unbenanntes Projekt';
    onCreateProject({
      name: trimmed,
      fps: newFps,
      resolution: RESOLUTION_PRESETS[newResIdx] || RESOLUTION_PRESETS[1],
      folderId: newTargetFolder || (selectedFolderId !== 'all' && selectedFolderId !== 'unsorted' ? selectedFolderId : null),
    });
    setShowNewModal(false);
  };

  const handleFolderCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = folderNameInput.trim();
    if (trimmed) {
      onCreateFolder(trimmed);
      setFolderNameInput('');
      setCreatingFolder(false);
    }
  };

  const handleImportChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    try {
      const imported = await parseFrmpFile(file);
      onImportProject(imported);
    } catch (err) {
      setImportError(err instanceof Error ? err.message : 'Fehler beim Laden der .frmp Datei.');
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#0e1013] text-[#f1f3f5]">
      {/* Top Bar: Clean 3-zone contract */}
      <header className="flex h-16 shrink-0 items-center justify-between gap-8 border-b border-[#222732] bg-[#12151a] px-7">
        <div className="flex items-center gap-2.5 shrink-0">
          <img
            src={framixAppIcon}
            alt="Framix Icon"
            className="h-8 w-8 rounded-lg object-cover ring-1 ring-white/10"
          />
          <span className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap">
            Framix
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#9aa3b2]">
          <button
            onClick={() => setSelectedFolderId('all')}
            className="whitespace-nowrap shrink-0 transition-colors hover:text-white"
          >
            Alle Speicherstände
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="whitespace-nowrap shrink-0 transition-colors hover:text-white"
          >
            .frmp Importieren
          </button>
          <button
            onClick={onShowNativeCode}
            className="whitespace-nowrap shrink-0 transition-colors hover:text-white"
          >
            C++ &amp; Python Engine
          </button>
        </nav>

        <button
          onClick={() => {
            setNewName(`Szene ${projects.length + 1}`);
            setNewTargetFolder(
              selectedFolderId !== 'all' && selectedFolderId !== 'unsorted' ? selectedFolderId : ''
            );
            setShowNewModal(true);
          }}
          className="flex items-center gap-2 whitespace-nowrap shrink-0 rounded-lg bg-[#e0533c] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#c94530]"
        >
          <Plus className="h-4 w-4" />
          Neues Projekt
        </button>
      </header>

      <input
        ref={fileInputRef}
        type="file"
        accept=".frmp,application/json"
        onChange={handleImportChange}
        className="hidden"
      />

      {/* Main Layout: Folder Sidebar + Project Library */}
      <div className="flex flex-1 flex-col lg:flex-row">
        {/* Folder Sidebar */}
        <aside className="w-full shrink-0 border-b border-[#222732] bg-[#12151a] p-5 lg:w-[270px] lg:border-b-0 lg:border-r">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-xs font-semibold tracking-wide text-[#8b94a5]">
              Ordnerstruktur
            </h2>
            <button
              onClick={() => setCreatingFolder((v) => !v)}
              className="flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-[#d1d7e3] transition-colors hover:bg-[#1e232d] hover:text-white"
              title="Neuen Ordner anlegen"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Ordner
            </button>
          </div>

          {creatingFolder && (
            <form onSubmit={handleFolderCreateSubmit} className="mb-3 flex gap-1.5">
              <input
                type="text"
                autoFocus
                value={folderNameInput}
                onChange={(e) => setFolderNameInput(e.target.value)}
                placeholder="Ordnername..."
                className="min-w-0 flex-1 rounded-md border border-[#2f3644] bg-[#0e1013] px-2.5 py-1.5 text-xs text-white focus:border-[#e0533c] focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-md bg-[#e0533c] px-2.5 py-1.5 text-xs font-medium text-white hover:bg-[#c94530]"
              >
                OK
              </button>
            </form>
          )}

          <div className="space-y-1">
            <button
              onClick={() => setSelectedFolderId('all')}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors ${
                selectedFolderId === 'all'
                  ? 'bg-[#1f242e] font-medium text-white'
                  : 'text-[#a5aebb] hover:bg-[#191d25] hover:text-white'
              }`}
            >
              <span className="flex items-center gap-2.5 truncate">
                <Film className="h-4 w-4 shrink-0 text-[#e0533c]" />
                <span className="truncate">Alle Projekte</span>
              </span>
              <span className="font-mono text-xs text-[#8b94a5] tabular-nums">
                {projects.length}
              </span>
            </button>

            <button
              onClick={() => setSelectedFolderId('unsorted')}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors ${
                selectedFolderId === 'unsorted'
                  ? 'bg-[#1f242e] font-medium text-white'
                  : 'text-[#a5aebb] hover:bg-[#191d25] hover:text-white'
              }`}
            >
              <span className="flex items-center gap-2.5 truncate">
                <Folder className="h-4 w-4 shrink-0 text-[#8b94a5]" />
                <span className="truncate">Ohne Ordner</span>
              </span>
              <span className="font-mono text-xs text-[#8b94a5] tabular-nums">
                {projects.filter((p) => !p.folderId).length}
              </span>
            </button>

            <div className="my-3 border-t border-[#222732]" />

            {folders.map((folder) => {
              const count = projects.filter((p) => p.folderId === folder.id).length;
              const isEditing = editingFolderId === folder.id;

              return (
                <div
                  key={folder.id}
                  className={`group flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors ${
                    selectedFolderId === folder.id
                      ? 'bg-[#1f242e] font-medium text-white'
                      : 'text-[#a5aebb] hover:bg-[#191d25] hover:text-white'
                  }`}
                >
                  {isEditing ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (editingFolderName.trim()) {
                          onRenameFolder(folder.id, editingFolderName.trim());
                        }
                        setEditingFolderId(null);
                      }}
                      className="flex w-full items-center gap-1"
                    >
                      <input
                        type="text"
                        autoFocus
                        value={editingFolderName}
                        onChange={(e) => setEditingFolderName(e.target.value)}
                        onBlur={() => setEditingFolderId(null)}
                        className="min-w-0 flex-1 rounded border border-[#3a4252] bg-[#0e1013] px-2 py-0.5 text-xs text-white focus:outline-none"
                      />
                    </form>
                  ) : (
                    <>
                      <button
                        onClick={() => setSelectedFolderId(folder.id)}
                        className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                      >
                        <Folder className="h-4 w-4 shrink-0 text-[#f59e0b]" />
                        <span className="truncate">{folder.name}</span>
                      </button>

                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs text-[#8b94a5] tabular-nums group-hover:hidden">
                          {count}
                        </span>
                        <div className="hidden items-center gap-1 group-hover:flex">
                          <button
                            onClick={() => {
                              setEditingFolderId(folder.id);
                              setEditingFolderName(folder.name);
                            }}
                            className="rounded p-1 text-[#8b94a5] hover:bg-[#2a303d] hover:text-white"
                            title="Ordner umbenennen"
                          >
                            <Pencil className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => {
                              if (selectedFolderId === folder.id) setSelectedFolderId('all');
                              onDeleteFolder(folder.id);
                            }}
                            className="rounded p-1 text-[#8b94a5] hover:bg-[#3b2022] hover:text-[#f87171]"
                            title="Ordner löschen"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-8 border-t border-[#222732] pt-5">
            <button
              onClick={onShowNativeCode}
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-[#2a303c] bg-[#171b22] px-3 py-2 text-xs font-medium text-[#c7cdd8] transition-colors hover:bg-[#202631] hover:text-white"
            >
              <Code2 className="h-4 w-4 text-[#e0533c]" />
              Desktop-Code (C++ &amp; Python)
            </button>
          </div>
        </aside>

        {/* Main Workspace */}
        <main className="flex-1 p-7">
          <div className="mx-auto max-w-6xl">
            {/* Workspace Header + Search + Quick Actions */}
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-white">
                  {selectedFolderId === 'all'
                    ? 'Projekt-Bibliothek'
                    : selectedFolderId === 'unsorted'
                    ? 'Nicht einsortierte Projekte'
                    : folders.find((f) => f.id === selectedFolderId)?.name || 'Ordner'}
                </h1>
                <p className="mt-1 text-sm text-[#8b94a5]">
                  Wähle einen gespeicherten .frmp-Stand aus oder starte eine neue Stop-Motion-Produktion.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6e7787]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Projekte durchsuchen..."
                    className="w-56 rounded-lg border border-[#272c37] bg-[#15181e] py-2 pl-9 pr-3 text-sm text-white placeholder-[#6e7787] focus:border-[#e0533c] focus:outline-none"
                  />
                </div>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 whitespace-nowrap rounded-lg border border-[#2a303c] bg-[#171b22] px-3.5 py-2 text-sm font-medium text-[#d1d7e3] transition-colors hover:bg-[#202631] hover:text-white"
                >
                  <Upload className="h-4 w-4" />
                  .frmp öffnen
                </button>
              </div>
            </div>

            {importError && (
              <div className="mb-5 flex items-center justify-between rounded-lg border border-[#7f1d1d] bg-[#2a1215] px-4 py-3 text-sm text-[#fca5a5]">
                <span>{importError}</span>
                <button onClick={() => setImportError(null)} className="p-1 hover:text-white">
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Empty State vs Project Grid */}
            {filteredProjects.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[#2b313e] bg-[#13161c] px-6 py-20 text-center">
                <Film className="mb-3 h-10 w-10 text-[#6e7787]" />
                <h3 className="font-display text-lg font-semibold text-white">
                  Keine Projekte in dieser Ansicht
                </h3>
                <p className="mt-1 max-w-md text-sm text-[#8b94a5]">
                  Erstelle ein neues Stop-Motion-Projekt oder importiere eine vorhandene .frmp-Projektdatei.
                </p>
                <button
                  onClick={() => setShowNewModal(true)}
                  className="mt-5 flex items-center gap-2 rounded-lg bg-[#e0533c] px-4 py-2 text-sm font-semibold text-white hover:bg-[#c94530]"
                >
                  <Plus className="h-4 w-4" />
                  Erstes Projekt erstellen
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {filteredProjects.map((project) => {
                  const previewFrame = project.frames[project.frames.length - 1];
                  const folderName = folders.find((f) => f.id === project.folderId)?.name;

                  return (
                    <article
                      key={project.id}
                      className="group flex flex-col overflow-hidden rounded-xl border border-[#242934] bg-[#15181e] transition-colors hover:border-[#394152]"
                    >
                      {/* Thumbnail */}
                      <button
                        onClick={() => onOpenProject(project)}
                        className="relative aspect-video w-full overflow-hidden bg-[#0c0e12] text-left"
                      >
                        {previewFrame ? (
                          <img
                            src={previewFrame.dataUrl}
                            alt={project.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                          />
                        ) : (
                          <div className="flex h-full w-full flex-col items-center justify-center text-[#6e7787]">
                            <Film className="mb-1.5 h-8 w-8" />
                            <span className="text-xs">Leere Bühne</span>
                          </div>
                        )}
                      </button>

                      {/* Card Body */}
                      <div className="flex flex-1 flex-col justify-between p-4">
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <button
                              onClick={() => onOpenProject(project)}
                              className="truncate text-left font-display text-base font-semibold text-white hover:text-[#e0533c]"
                            >
                              {project.name}
                            </button>
                            <span className="shrink-0 font-mono text-xs text-[#8b94a5]">
                              .frmp
                            </span>
                          </div>

                          {/* Unboxed metadata with typographic separators */}
                          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#8b94a5] tabular-nums">
                            <span>{project.fps} fps</span>
                            <span aria-hidden="true">·</span>
                            <span>{project.frames.length} Bilder</span>
                            <span aria-hidden="true">·</span>
                            <span>{formatDuration(project)}</span>
                            {folderName && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-[#c7cdd8]">{folderName}</span>
                              </>
                            )}
                          </div>
                          <div className="mt-1 text-xs text-[#6e7787]">
                            Geändert: {formatDate(project.updatedAt)}
                          </div>
                        </div>

                        {/* Actions Footer */}
                        <div className="mt-4 flex items-center justify-between gap-2 border-t border-[#222732] pt-3">
                          <select
                            value={project.folderId || ''}
                            onChange={(e) =>
                              onMoveProjectToFolder(project.id, e.target.value || null)
                            }
                            aria-label="Ordner zuweisen"
                            className="max-w-[130px] truncate rounded-md border border-[#272c37] bg-[#101318] px-2 py-1 text-xs text-[#a5aebb] focus:border-[#e0533c] focus:outline-none"
                          >
                            <option value="">Ohne Ordner</option>
                            {folders.map((f) => (
                              <option key={f.id} value={f.id}>
                                {f.name}
                              </option>
                            ))}
                          </select>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => downloadFrmpFile(project)}
                              className="rounded-md p-1.5 text-[#9aa3b2] transition-colors hover:bg-[#222732] hover:text-white"
                              title="Als .frmp speichern"
                            >
                              <Download className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => onDuplicateProject(project)}
                              className="rounded-md p-1.5 text-[#9aa3b2] transition-colors hover:bg-[#222732] hover:text-white"
                              title="Projekt duplizieren"
                            >
                              <Copy className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => onDeleteProject(project.id)}
                              className="rounded-md p-1.5 text-[#9aa3b2] transition-colors hover:bg-[#3a1f22] hover:text-[#f87171]"
                              title="Projekt löschen"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Create New Project Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6">
          <form
            onSubmit={handleCreateSubmit}
            className="w-full max-w-md rounded-xl border border-[#272c37] bg-[#15181e] p-6 shadow-2xl"
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-white">
                Neues Stop-Motion Projekt
              </h2>
              <button
                type="button"
                onClick={() => setShowNewModal(false)}
                className="rounded-lg p-1.5 text-[#8b94a5] hover:bg-[#222732] hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#c7cdd8]">
                  Projektname (Dateiendung .frmp)
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full rounded-lg border border-[#2a303c] bg-[#0e1013] px-3 py-2 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-[#c7cdd8]">
                    Bildrate (FPS)
                  </label>
                  <select
                    value={newFps}
                    onChange={(e) => setNewFps(Number(e.target.value))}
                    className="w-full rounded-lg border border-[#2a303c] bg-[#0e1013] px-3 py-2 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                  >
                    <option value={12}>12 fps (Stop-Motion Klassik)</option>
                    <option value={15}>15 fps</option>
                    <option value={24}>24 fps (Kino)</option>
                    <option value={25}>25 fps (PAL)</option>
                    <option value={30}>30 fps (NTSC/Web)</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-[#c7cdd8]">
                    Ordner
                  </label>
                  <select
                    value={newTargetFolder}
                    onChange={(e) => setNewTargetFolder(e.target.value)}
                    className="w-full rounded-lg border border-[#2a303c] bg-[#0e1013] px-3 py-2 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                  >
                    <option value="">Ohne Ordner</option>
                    {folders.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#c7cdd8]">
                  Auflösung
                </label>
                <select
                  value={newResIdx}
                  onChange={(e) => setNewResIdx(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#2a303c] bg-[#0e1013] px-3 py-2 text-sm text-white focus:border-[#e0533c] focus:outline-none"
                >
                  {RESOLUTION_PRESETS.map((r, idx) => (
                    <option key={r.label} value={idx}>
                      {r.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowNewModal(false)}
                className="rounded-lg border border-[#2a303c] px-4 py-2 text-sm font-medium text-[#c7cdd8] hover:bg-[#1e232d]"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#e0533c] px-5 py-2 text-sm font-semibold text-white hover:bg-[#c94530]"
              >
                Studio starten
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
