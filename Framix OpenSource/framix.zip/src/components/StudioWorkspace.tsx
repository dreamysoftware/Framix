import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Download,
  Save,
} from 'lucide-react';
import {
  AudioTrackClip,
  CameraSettings,
  CustomGuide,
  DEFAULT_EFFECTS,
  DEFAULT_GREENSCREEN,
  FrameEffects,
  FramixFrame,
  FramixProject,
  GreenscreenSettings,
  RotoStroke,
  StudioMode,
  VirtualPuppetPose,
} from '../types/framix';
import {
  GreenscreenScanResult,
  analyzeFrameMotionJump,
} from '../utils/compositor';
import { downloadFrmpFile } from '../utils/frmpStorage';
import { DEFAULT_PUPPET_POSE } from '../utils/virtualStage';
import ExportModal from './ExportModal';
import InspectorPanel from './InspectorPanel';
import TimelineBar from './TimelineBar';
import ViewportStage, { ViewportTool } from './ViewportStage';
import framixAppIcon from '../assets/images/framix_app_icon.png';

interface StudioWorkspaceProps {
  project: FramixProject;
  onSaveProject: (updated: FramixProject) => Promise<void>;
  onBackToHub: () => void;
}

const MODE_TABS: { id: StudioMode; label: string }[] = [
  { id: 'capture', label: 'Aufnahme' },
  { id: 'timeline', label: 'Timeline & X-Sheet' },
  { id: 'guides_roto', label: 'Hilfslinien & Roto' },
  { id: 'effects', label: 'Effekte' },
  { id: 'audio', label: 'Audio & Dialog' },
];

export default function StudioWorkspace({
  project: initialProject,
  onSaveProject,
  onBackToHub,
}: StudioWorkspaceProps) {
  const [project, setProject] = useState<FramixProject>(() => ({
    ...initialProject,
    guides: initialProject.guides || [],
    greenscreen: initialProject.greenscreen || { ...DEFAULT_GREENSCREEN },
    motionAlertsEnabled: initialProject.motionAlertsEnabled ?? true,
  }));
  const [mode, setMode] = useState<StudioMode>('capture');
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const [showExportModal, setShowExportModal] = useState(false);

  // Camera state
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('virtual');
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [puppetPose, setPuppetPose] = useState<VirtualPuppetPose>(DEFAULT_PUPPET_POSE);

  // Playback & Live View
  const [isLiveMode, setIsLiveMode] = useState<boolean>(true);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [selectedIndex, setSelectedIndex] = useState<number>(
    Math.max(0, initialProject.frames.length - 1)
  );

  // Onion skinning & capture
  const [onionCount, setOnionCount] = useState<number>(2);
  const [onionOpacity, setOnionOpacity] = useState<number>(0.35);
  const [differenceMatte, setDifferenceMatte] = useState<boolean>(false);
  const [captureHold, setCaptureHold] = useState<number>(1);
  const [timelapseSec, setTimelapseSec] = useState<number>(0);
  const [shutterTriggerNonce, setShutterTriggerNonce] = useState<number>(0);

  // Motion Jump Alert state
  const [motionWarning, setMotionWarning] = useState<string | null>(null);

  // Custom Hilfslinien, Greenscreen & Roto tools
  const [activeTool, setActiveTool] = useState<ViewportTool>('select_move');
  const [guideColor, setGuideColor] = useState<string>('#38bdf8');
  const [guideDashed, setGuideDashed] = useState<boolean>(true);
  const [showGuides, setShowGuides] = useState<boolean>(true);
  const [selectedGuideId, setSelectedGuideId] = useState<string | null>(null);
  const [selectedStrokeId, setSelectedStrokeId] = useState<string | null>(null);

  const [rotoColor, setRotoColor] = useState<string>('#e0533c');
  const [rotoSize, setRotoSize] = useState<number>(12);
  const [rotoOpacity, setRotoOpacity] = useState<number>(0.9);
  const [rotoOnionSkin, setRotoOnionSkin] = useState<boolean>(true);
  const [rigCloneOffset, setRigCloneOffset] = useState<{ dx: number; dy: number }>({
    dx: 0.045,
    dy: 0,
  });

  // Greenscreen scan state
  const [greenscreenScanNonce, setGreenscreenScanNonce] = useState<number>(0);
  const [greenscreenScanResult, setGreenscreenScanResult] =
    useState<GreenscreenScanResult | null>(null);

  const saveTimerRef = useRef<number | null>(null);
  const playingAudioRef = useRef<HTMLAudioElement[]>([]);

  const updateProject = useCallback(
    (updater: (prev: FramixProject) => FramixProject) => {
      setProject((prev) => {
        const next = { ...updater(prev), updatedAt: Date.now() };
        setSaveStatus('saving');
        if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
        saveTimerRef.current = window.setTimeout(async () => {
          await onSaveProject(next);
          setSaveStatus('saved');
        }, 350);
        return next;
      });
    },
    [onSaveProject]
  );

  const refreshCameras = useCallback(async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      setCameras([]);
      return;
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter((d) => d.kind === 'videoinput');
      setCameras(videoInputs);
    } catch {
      setCameras([]);
    }
  }, []);

  useEffect(() => {
    refreshCameras();
  }, [refreshCameras]);

  useEffect(() => {
    let active = true;
    let currentStream: MediaStream | null = null;

    const startCam = async () => {
      setCameraError(null);
      if (selectedCameraId === 'virtual') {
        setVideoStream((prev) => {
          prev?.getTracks().forEach((t) => t.stop());
          return null;
        });
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            deviceId: selectedCameraId ? { exact: selectedCameraId } : undefined,
            width: { ideal: project.resolution.width },
            height: { ideal: project.resolution.height },
          },
          audio: false,
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        currentStream = stream;
        setVideoStream((prev) => {
          prev?.getTracks().forEach((t) => t.stop());
          return stream;
        });
        refreshCameras();
      } catch {
        setCameraError('Kamera konnte nicht geöffnet werden — Virtuelle Bühne aktiv.');
        setSelectedCameraId('virtual');
      }
    };

    startCam();
    return () => {
      active = false;
      currentStream?.getTracks().forEach((t) => t.stop());
    };
  }, [selectedCameraId, project.resolution.width, project.resolution.height, refreshCameras]);

  useEffect(() => {
    if (timelapseSec <= 0 || !isLiveMode || isPlaying) return;
    const id = window.setInterval(() => {
      setShutterTriggerNonce((n) => n + 1);
    }, timelapseSec * 1000);
    return () => window.clearInterval(id);
  }, [timelapseSec, isLiveMode, isPlaying]);

  useEffect(() => {
    if (!isPlaying || project.frames.length === 0) {
      playingAudioRef.current.forEach((a) => a.pause());
      playingAudioRef.current = [];
      return;
    }

    const map: number[] = [];
    project.frames.forEach((f, idx) => {
      const h = Math.max(1, f.hold || 1);
      for (let k = 0; k < h; k++) map.push(idx);
    });

    let cursor = Math.max(0, map.indexOf(selectedIndex));
    if (cursor < 0) cursor = 0;

    const triggerAudioFrom = (expCursor: number) => {
      playingAudioRef.current.forEach((a) => a.pause());
      playingAudioRef.current = [];
      for (const clip of project.audioClips) {
        if (clip.muted) continue;
        const deltaFrames = clip.startFrame - expCursor;
        const delayMs = (deltaFrames / Math.max(1, project.fps)) * 1000;
        if (delayMs >= -clip.durationSec * 1000) {
          const audio = new Audio(clip.dataUrl);
          audio.volume = clip.volume;
          if (delayMs <= 0) {
            audio.currentTime = Math.abs(delayMs) / 1000;
            audio.play().catch(() => undefined);
          } else {
            window.setTimeout(() => {
              audio.play().catch(() => undefined);
            }, delayMs);
          }
          playingAudioRef.current.push(audio);
        }
      }
    };

    triggerAudioFrom(cursor);

    const intervalMs = 1000 / Math.max(1, project.fps);
    const timer = window.setInterval(() => {
      cursor += 1;
      if (cursor >= map.length) {
        if (isLooping) {
          cursor = 0;
          triggerAudioFrom(0);
        } else {
          setIsPlaying(false);
          return;
        }
      }
      setSelectedIndex(map[cursor]);
    }, intervalMs);

    return () => {
      window.clearInterval(timer);
      playingAudioRef.current.forEach((a) => a.pause());
      playingAudioRef.current = [];
    };
  }, [isPlaying, isLooping, project.fps, project.frames, project.audioClips]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying(false);
        setIsLiveMode(true);
        setShutterTriggerNonce((n) => n + 1);
      } else if (e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        if (project.frames.length > 0) {
          setIsLiveMode(false);
          setIsPlaying((v) => !v);
        }
      } else if (e.key === 'l' || e.key === 'L') {
        e.preventDefault();
        setIsPlaying(false);
        setIsLiveMode((v) => !v);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setIsPlaying(false);
        setIsLiveMode(false);
        setSelectedIndex((i) => Math.max(0, i - 1));
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        setIsPlaying(false);
        if (!isLiveMode && selectedIndex >= project.frames.length - 1) {
          setIsLiveMode(true);
        } else {
          setIsLiveMode(false);
          setSelectedIndex((i) => Math.min(project.frames.length - 1, i + 1));
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [project.frames.length, isLiveMode, selectedIndex]);

  const handleCaptureCanvas = async (captureCanvas: HTMLCanvasElement) => {
    const prevFrame = project.frames[project.frames.length - 1];

    const dataUrl = captureCanvas.toDataURL('image/jpeg', 0.9);
    const thumb = document.createElement('canvas');
    thumb.width = 240;
    thumb.height = Math.round((240 / captureCanvas.width) * captureCanvas.height);
    thumb.getContext('2d')?.drawImage(captureCanvas, 0, 0, thumb.width, thumb.height);
    const thumbnailUrl = thumb.toDataURL('image/jpeg', 0.72);

    const newFrame: FramixFrame = {
      id: `frame_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      dataUrl,
      thumbnailUrl,
      hold: captureHold,
      label: '',
      rotoStrokes: [],
      effects: { ...DEFAULT_EFFECTS },
      capturedAt: Date.now(),
    };

    updateProject((prev) => ({
      ...prev,
      frames: [...prev.frames, newFrame],
    }));
    setSelectedIndex(project.frames.length);
    setIsLiveMode(true);

    // Check smoothness / abrupt jump vs previous frame
    if (project.motionAlertsEnabled && prevFrame) {
      const report = await analyzeFrameMotionJump(
        prevFrame.dataUrl,
        captureCanvas,
        project.fps
      );
      if (report.isAbruptJump && report.message) {
        setMotionWarning(report.message);
      } else {
        setMotionWarning(null);
      }
    }
  };

  const handleManualSave = async () => {
    setSaveStatus('saving');
    await onSaveProject(project);
    setSaveStatus('saved');
  };

  const selectedFrame =
    !isLiveMode && selectedIndex >= 0 && selectedIndex < project.frames.length
      ? project.frames[selectedIndex]
      : project.frames[selectedIndex] || null;

  const handleDuplicateFrame = (idx: number) => {
    const src = project.frames[idx];
    if (!src) return;
    const dup: FramixFrame = {
      ...src,
      id: `frame_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      capturedAt: Date.now(),
    };
    updateProject((prev) => {
      const copy = [...prev.frames];
      copy.splice(idx + 1, 0, dup);
      return { ...prev, frames: copy };
    });
    setSelectedIndex(idx + 1);
  };

  const handleDeleteFrame = (idx: number) => {
    updateProject((prev) => ({
      ...prev,
      frames: prev.frames.filter((_, i) => i !== idx),
    }));
    setSelectedIndex((cur) => Math.max(0, Math.min(cur, project.frames.length - 2)));
  };

  const handleSetCleanPlateFromFrame = (idx: number) => {
    const f = project.frames[idx];
    if (!f) return;
    updateProject((prev) => ({ ...prev, cleanPlateDataUrl: f.dataUrl }));
  };

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#0e1013] text-[#f1f3f5]">
      <header className="flex h-14 shrink-0 items-center justify-between gap-6 border-b border-[#222732] bg-[#12151a] px-5">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={async () => {
              await handleManualSave();
              onBackToHub();
            }}
            className="flex items-center gap-1.5 whitespace-nowrap rounded-md border border-[#272c37] bg-[#181c24] px-2.5 py-1.5 text-xs font-medium text-[#c7cdd8] transition-colors hover:bg-[#222732] hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Projekte
          </button>

          <img
            src={framixAppIcon}
            alt="Framix Icon"
            className="hidden sm:block h-7 w-7 shrink-0 rounded-md object-cover ring-1 ring-white/10"
          />

          <span className="truncate font-display text-base font-bold text-white">
            {project.name}
          </span>
          <span className="hidden sm:inline font-mono text-xs text-[#8b94a5]">
            .frmp · {saveStatus === 'saving' ? 'Speichert...' : 'Gespeichert'}
          </span>
        </div>

        <nav className="flex items-center gap-1 rounded-lg bg-[#0d0f13] p-1">
          {MODE_TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setMode(t.id);
                if (t.id === 'effects' && isLiveMode && project.frames.length > 0) {
                  setIsLiveMode(false);
                  setSelectedIndex(project.frames.length - 1);
                }
              }}
              className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                mode === t.id
                  ? 'bg-[#212631] text-white'
                  : 'text-[#8b94a5] hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => downloadFrmpFile(project)}
            className="hidden md:flex items-center gap-1.5 whitespace-nowrap rounded-md border border-[#272c37] bg-[#181c24] px-3 py-1.5 text-xs font-medium text-[#c7cdd8] hover:bg-[#222732] hover:text-white"
            title=".frmp Projektdatei herunterladen"
          >
            <Save className="h-3.5 w-3.5" />
            .frmp sichern
          </button>
          <button
            onClick={() => setShowExportModal(true)}
            className="flex items-center gap-1.5 whitespace-nowrap rounded-lg bg-[#e0533c] px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#c94530]"
          >
            <Download className="h-3.5 w-3.5" />
            Exportieren
          </button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <ViewportStage
          mode={mode}
          width={project.resolution.width}
          height={project.resolution.height}
          frames={project.frames}
          guides={project.guides}
          greenscreen={project.greenscreen}
          cleanPlateDataUrl={project.cleanPlateDataUrl}
          cameraSettings={project.cameraSettings}
          selectedCameraId={selectedCameraId}
          videoStream={videoStream}
          cameraError={cameraError}
          puppetPose={puppetPose}
          onChangePuppetPose={setPuppetPose}
          isLiveMode={isLiveMode}
          isPlaying={isPlaying}
          isLooping={isLooping}
          selectedIndex={selectedIndex}
          onionCount={onionCount}
          onionOpacity={onionOpacity}
          differenceMatte={differenceMatte}
          captureHold={captureHold}
          activeTool={activeTool}
          guideColor={guideColor}
          guideDashed={guideDashed}
          showGuides={showGuides}
          rotoColor={rotoColor}
          rotoSize={rotoSize}
          rotoOpacity={rotoOpacity}
          rotoOnionSkin={rotoOnionSkin}
          rigCloneOffset={rigCloneOffset}
          onChangeRigCloneOffset={setRigCloneOffset}
          selectedGuideId={selectedGuideId}
          onSelectGuideId={setSelectedGuideId}
          selectedStrokeId={selectedStrokeId}
          onSelectStrokeId={setSelectedStrokeId}
          onAddCustomGuide={(guide: CustomGuide) => {
            updateProject((prev) => ({ ...prev, guides: [...prev.guides, guide] }));
          }}
          onUpdateGuide={(id, patch) => {
            updateProject((prev) => ({
              ...prev,
              guides: prev.guides.map((g) => (g.id === id ? { ...g, ...patch } : g)),
            }));
          }}
          onDeleteGuide={(id) => {
            updateProject((prev) => ({
              ...prev,
              guides: prev.guides.filter((g) => g.id !== id),
            }));
            if (selectedGuideId === id) setSelectedGuideId(null);
          }}
          onCommitRotoStroke={(stroke: RotoStroke) => {
            if (isLiveMode || !project.frames[selectedIndex]) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex
                  ? { ...f, rotoStrokes: [...f.rotoStrokes, stroke] }
                  : f
              ),
            }));
          }}
          onUpdateRotoStroke={(strokeId, points) => {
            if (isLiveMode || !project.frames[selectedIndex]) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex
                  ? {
                      ...f,
                      rotoStrokes: f.rotoStrokes.map((s) =>
                        s.id === strokeId ? { ...s, points } : s
                      ),
                    }
                  : f
              ),
            }));
          }}
          onDeleteRotoStroke={(strokeId) => {
            if (isLiveMode || !project.frames[selectedIndex]) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex
                  ? {
                      ...f,
                      rotoStrokes: f.rotoStrokes.filter((s) => s.id !== strokeId),
                    }
                  : f
              ),
            }));
            if (selectedStrokeId === strokeId) setSelectedStrokeId(null);
          }}
          onPickGreenscreenColor={(hexColor) => {
            updateProject((prev) => ({
              ...prev,
              greenscreen: { ...prev.greenscreen, keyColor: hexColor, enabled: true },
            }));
            setActiveTool('select_move');
          }}
          greenscreenScanNonce={greenscreenScanNonce}
          onGreenscreenScanResult={(res) => {
            setGreenscreenScanResult(res);
            if (res.detected) {
              updateProject((prev) => ({
                ...prev,
                greenscreen: {
                  ...prev.greenscreen,
                  keyColor: res.suggestedColor,
                  enabled: true,
                },
              }));
            }
          }}
          motionWarning={motionWarning}
          onDismissMotionWarning={() => setMotionWarning(null)}
          onDisableMotionAlerts={() => {
            setMotionWarning(null);
            updateProject((prev) => ({ ...prev, motionAlertsEnabled: false }));
          }}
          onSetCleanPlateFromFrame={handleSetCleanPlateFromFrame}
          onDuplicateFrame={handleDuplicateFrame}
          onDeleteFrame={handleDeleteFrame}
          onClearFrameRoto={() => {
            if (!selectedFrame) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex ? { ...f, rotoStrokes: [] } : f
              ),
            }));
          }}
          onCaptureCanvas={handleCaptureCanvas}
          onTogglePlay={() => {
            if (project.frames.length === 0) return;
            setIsLiveMode(false);
            setIsPlaying((v) => !v);
          }}
          onToggleLoop={() => setIsLooping((v) => !v)}
          onStepFrame={(delta) => {
            setIsPlaying(false);
            setIsLiveMode(false);
            setSelectedIndex((idx) =>
              Math.max(0, Math.min(project.frames.length - 1, idx + delta))
            );
          }}
          onToggleLive={() => {
            setIsPlaying(false);
            setIsLiveMode((v) => !v);
          }}
          onChangeCaptureHold={setCaptureHold}
          shutterTriggerNonce={shutterTriggerNonce}
        />

        <InspectorPanel
          mode={mode}
          cameras={cameras}
          selectedCameraId={selectedCameraId}
          onSelectCamera={(id) => {
            setSelectedCameraId(id);
            setIsLiveMode(true);
          }}
          onRefreshCameras={refreshCameras}
          cameraSettings={project.cameraSettings}
          onUpdateCameraSettings={(patch: Partial<CameraSettings>) =>
            updateProject((prev) => ({
              ...prev,
              cameraSettings: { ...prev.cameraSettings, ...patch },
            }))
          }
          onionCount={onionCount}
          onChangeOnionCount={setOnionCount}
          onionOpacity={onionOpacity}
          onChangeOnionOpacity={setOnionOpacity}
          differenceMatte={differenceMatte}
          onToggleDifferenceMatte={() => setDifferenceMatte((v) => !v)}
          timelapseIntervalSec={timelapseSec}
          onChangeTimelapseSec={setTimelapseSec}
          motionAlertsEnabled={project.motionAlertsEnabled}
          onToggleMotionAlerts={(enabled) => {
            if (!enabled) setMotionWarning(null);
            updateProject((prev) => ({ ...prev, motionAlertsEnabled: enabled }));
          }}
          puppetPose={puppetPose}
          onChangePuppetPose={setPuppetPose}
          activeTool={activeTool}
          onChangeActiveTool={setActiveTool}
          guides={project.guides}
          selectedGuideId={selectedGuideId}
          onSelectGuideId={setSelectedGuideId}
          guideColor={guideColor}
          onChangeGuideColor={setGuideColor}
          guideDashed={guideDashed}
          onToggleGuideDashed={() => setGuideDashed((v) => !v)}
          showGuides={showGuides}
          onToggleShowGuides={() => setShowGuides((v) => !v)}
          onAddQuickGuide={(kind) => {
            const g: CustomGuide = {
              id: `guide_${Date.now()}`,
              name:
                kind === 'horizontal'
                  ? `Waagerecht ${project.guides.length + 1}`
                  : `Senkrecht ${project.guides.length + 1}`,
              kind,
              points: [{ x: 0.5, y: 0.5 }],
              color: guideColor,
              dashed: guideDashed,
              width: 2,
              visible: true,
            };
            updateProject((prev) => ({ ...prev, guides: [...prev.guides, g] }));
            setSelectedGuideId(g.id);
            setShowGuides(true);
            setActiveTool('select_move');
          }}
          onUpdateGuide={(id, patch) =>
            updateProject((prev) => ({
              ...prev,
              guides: prev.guides.map((g) => (g.id === id ? { ...g, ...patch } : g)),
            }))
          }
          onDeleteGuide={(id) => {
            updateProject((prev) => ({
              ...prev,
              guides: prev.guides.filter((g) => g.id !== id),
            }));
            if (selectedGuideId === id) setSelectedGuideId(null);
          }}
          greenscreen={project.greenscreen}
          onUpdateGreenscreen={(patch: Partial<GreenscreenSettings>) =>
            updateProject((prev) => ({
              ...prev,
              greenscreen: { ...prev.greenscreen, ...patch },
            }))
          }
          onScanGreenscreen={() => setGreenscreenScanNonce((n) => n + 1)}
          greenscreenScanResult={greenscreenScanResult}
          selectedFrame={selectedFrame}
          selectedIndex={selectedIndex}
          isLiveMode={isLiveMode}
          onSelectFrameForEdit={(idx) => {
            setIsPlaying(false);
            setIsLiveMode(false);
            setSelectedIndex(idx);
          }}
          rotoColor={rotoColor}
          onChangeRotoColor={setRotoColor}
          rotoSize={rotoSize}
          onChangeRotoSize={setRotoSize}
          rotoOpacity={rotoOpacity}
          onChangeRotoOpacity={setRotoOpacity}
          rotoOnionSkin={rotoOnionSkin}
          onToggleRotoOnionSkin={() => setRotoOnionSkin((v) => !v)}
          onClearFrameRoto={() => {
            if (!selectedFrame) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex ? { ...f, rotoStrokes: [] } : f
              ),
            }));
          }}
          onCopyPrevRoto={() => {
            if (selectedIndex <= 0 || !project.frames[selectedIndex - 1]) return;
            const prevStrokes = project.frames[selectedIndex - 1].rotoStrokes;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex
                  ? {
                      ...f,
                      rotoStrokes: [
                        ...f.rotoStrokes,
                        ...prevStrokes.map((s) => ({
                          ...s,
                          id: `copy_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
                        })),
                      ],
                    }
                  : f
              ),
            }));
          }}
          cleanPlateDataUrl={project.cleanPlateDataUrl}
          onSetCleanPlateFromCurrent={() => {
            if (selectedFrame) {
              updateProject((prev) => ({ ...prev, cleanPlateDataUrl: selectedFrame.dataUrl }));
            }
          }}
          onClearCleanPlate={() =>
            updateProject((prev) => ({ ...prev, cleanPlateDataUrl: null }))
          }
          onUpdateFrameEffects={(patch: Partial<FrameEffects>) => {
            if (!selectedFrame) return;
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f, idx) =>
                idx === selectedIndex
                  ? { ...f, effects: { ...f.effects, ...patch } }
                  : f
              ),
            }));
          }}
          onApplyEffectsToAll={(effects) =>
            updateProject((prev) => ({
              ...prev,
              frames: prev.frames.map((f) => ({ ...f, effects: { ...effects } })),
            }))
          }
          audioClips={project.audioClips}
          onAddAudioClip={(clip: AudioTrackClip) =>
            updateProject((prev) => ({
              ...prev,
              audioClips: [...prev.audioClips, clip],
            }))
          }
          onUpdateAudioClip={(id, patch) =>
            updateProject((prev) => ({
              ...prev,
              audioClips: prev.audioClips.map((c) => (c.id === id ? { ...c, ...patch } : c)),
            }))
          }
          onDeleteAudioClip={(id) =>
            updateProject((prev) => ({
              ...prev,
              audioClips: prev.audioClips.filter((c) => c.id !== id),
            }))
          }
          currentFrameCursor={Math.max(0, selectedIndex)}
        />
      </div>

      <TimelineBar
        frames={project.frames}
        audioClips={project.audioClips}
        fps={project.fps}
        selectedIndex={selectedIndex}
        isLiveMode={isLiveMode}
        showXSheet={mode === 'timeline'}
        onSelectFrame={(idx) => {
          setIsPlaying(false);
          setIsLiveMode(false);
          setSelectedIndex(idx);
        }}
        onSelectLive={() => {
          setIsPlaying(false);
          setIsLiveMode(true);
        }}
        onChangeHold={(idx, delta) =>
          updateProject((prev) => ({
            ...prev,
            frames: prev.frames.map((f, i) =>
              i === idx ? { ...f, hold: Math.max(1, Math.min(8, (f.hold || 1) + delta)) } : f
            ),
          }))
        }
        onMoveFrame={(idx, dir) => {
          const target = idx + dir;
          if (target < 0 || target >= project.frames.length) return;
          updateProject((prev) => {
            const copy = [...prev.frames];
            const [item] = copy.splice(idx, 1);
            copy.splice(target, 0, item);
            return { ...prev, frames: copy };
          });
          setSelectedIndex(target);
        }}
        onDuplicateFrame={handleDuplicateFrame}
        onDeleteFrame={handleDeleteFrame}
        onSetCleanPlateFromFrame={handleSetCleanPlateFromFrame}
        onUpdateFrameLabel={(idx, label) =>
          updateProject((prev) => ({
            ...prev,
            frames: prev.frames.map((f, i) => (i === idx ? { ...f, label } : f)),
          }))
        }
        onNudgeAudioClip={(clipId, deltaFrames) =>
          updateProject((prev) => ({
            ...prev,
            audioClips: prev.audioClips.map((c) =>
              c.id === clipId
                ? { ...c, startFrame: Math.max(0, c.startFrame + deltaFrames) }
                : c
            ),
          }))
        }
        onToggleAudioMute={(clipId) =>
          updateProject((prev) => ({
            ...prev,
            audioClips: prev.audioClips.map((c) =>
              c.id === clipId ? { ...c, muted: !c.muted } : c
            ),
          }))
        }
      />

      {showExportModal && (
        <ExportModal project={project} onClose={() => setShowExportModal(false)} />
      )}
    </div>
  );
}
