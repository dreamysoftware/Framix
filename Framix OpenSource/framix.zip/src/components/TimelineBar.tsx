import { useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Copy,
  Eraser,
  Mic,
  Minus,
  Plus,
  Trash2,
  Video,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { AudioTrackClip, FramixFrame } from '../types/framix';

interface TimelineBarProps {
  frames: FramixFrame[];
  audioClips: AudioTrackClip[];
  fps: number;
  selectedIndex: number;
  isLiveMode: boolean;
  showXSheet: boolean;
  onSelectFrame: (index: number) => void;
  onSelectLive: () => void;
  onChangeHold: (index: number, delta: number) => void;
  onMoveFrame: (index: number, dir: -1 | 1) => void;
  onDuplicateFrame: (index: number) => void;
  onDeleteFrame: (index: number) => void;
  onSetCleanPlateFromFrame: (index: number) => void;
  onUpdateFrameLabel: (index: number, label: string) => void;
  onNudgeAudioClip: (clipId: string, deltaFrames: number) => void;
  onToggleAudioMute: (clipId: string) => void;
}

interface FrameMenuState {
  x: number;
  y: number;
  frameIndex: number;
}

export default function TimelineBar({
  frames,
  audioClips,
  fps,
  selectedIndex,
  isLiveMode,
  showXSheet,
  onSelectFrame,
  onSelectLive,
  onChangeHold,
  onMoveFrame,
  onDuplicateFrame,
  onDeleteFrame,
  onSetCleanPlateFromFrame,
  onUpdateFrameLabel,
  onNudgeAudioClip,
  onToggleAudioMute,
}: TimelineBarProps) {
  const [frameMenu, setFrameMenu] = useState<FrameMenuState | null>(null);

  useEffect(() => {
    if (!frameMenu) return;
    const close = () => setFrameMenu(null);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setFrameMenu(null);
    };
    window.addEventListener('click', close);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('click', close);
      window.removeEventListener('keydown', onKey);
    };
  }, [frameMenu]);

  const totalExposures = frames.reduce((s, f) => s + (f.hold || 1), 0);

  const startExposureOffsets: number[] = [];
  let running = 0;
  for (const f of frames) {
    startExposureOffsets.push(running);
    running += f.hold || 1;
  }

  return (
    <section className="flex shrink-0 flex-col border-t border-[#242934] bg-[#12151a]">
      {/* Expandable X-Sheet Table in Timeline & X-Sheet Mode */}
      {showXSheet && (
        <div className="max-h-52 overflow-auto border-b border-[#242934] bg-[#0f1217] px-4 py-2">
          <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-[#9aa3b2]">
            <span>Belichtungsbogen (X-Sheet)</span>
            <span className="font-mono tabular-nums">
              {frames.length} Einzelbilder · {totalExposures} Belichtungen ·{' '}
              {(totalExposures / Math.max(1, fps)).toFixed(2)}s @ {fps} fps
            </span>
          </div>
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-[#232833] text-[#8b94a5]">
                <th className="py-1.5 pr-3 font-medium">Bild</th>
                <th className="py-1.5 pr-3 font-medium">Timecode</th>
                <th className="py-1.5 pr-3 font-medium">Halt (Exposures)</th>
                <th className="py-1.5 pr-3 font-medium">Notiz / Lip-Sync Cue</th>
                <th className="py-1.5 pr-3 font-medium">Roto-Striche</th>
                <th className="py-1.5 font-medium">Effekt</th>
              </tr>
            </thead>
            <tbody>
              {frames.map((frame, idx) => {
                const startExp = startExposureOffsets[idx];
                const sec = (startExp / Math.max(1, fps)).toFixed(2);
                const active = !isLiveMode && selectedIndex === idx;
                return (
                  <tr
                    key={frame.id}
                    onClick={() => onSelectFrame(idx)}
                    className={`cursor-pointer border-b border-[#1b2029] transition-colors ${
                      active ? 'bg-[#e0533c]/15 text-white' : 'text-[#c7cdd8] hover:bg-[#181c24]'
                    }`}
                  >
                    <td className="py-1.5 pr-3 font-mono tabular-nums">
                      #{String(idx + 1).padStart(4, '0')}
                    </td>
                    <td className="py-1.5 pr-3 font-mono text-[#8b94a5] tabular-nums">
                      {sec}s (Exp {startExp + 1})
                    </td>
                    <td className="py-1.5 pr-3 font-mono tabular-nums">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onChangeHold(idx, -1);
                          }}
                          className="rounded bg-[#222732] px-1.5 py-0.5 hover:bg-[#2f3644]"
                        >
                          -
                        </button>
                        <span className="w-6 text-center">×{frame.hold}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onChangeHold(idx, 1);
                          }}
                          className="rounded bg-[#222732] px-1.5 py-0.5 hover:bg-[#2f3644]"
                        >
                          +
                        </button>
                      </div>
                    </td>
                    <td className="py-1.5 pr-3">
                      <input
                        type="text"
                        value={frame.label}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) => onUpdateFrameLabel(idx, e.target.value)}
                        placeholder="z.B. A-Laut / Keypose"
                        className="w-44 rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs text-white focus:border-[#343c4d] focus:bg-[#141820] focus:outline-none"
                      />
                    </td>
                    <td className="py-1.5 pr-3 font-mono text-[#8b94a5] tabular-nums">
                      {frame.rotoStrokes.length}
                    </td>
                    <td className="py-1.5 text-[#8b94a5]">
                      {frame.effects.preset === 'none' ? 'Original' : frame.effects.preset}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Horizontal Filmstrip Timeline */}
      <div className="flex items-center gap-2 overflow-x-auto px-4 py-3">
        {frames.length === 0 && (
          <div className="mr-2 flex h-[76px] items-center rounded-lg border border-dashed border-[#2a303c] px-4 text-xs text-[#8b94a5]">
            Noch keine Einzelbilder aufgenommen — drücke Leertaste oder Auslösen.
          </div>
        )}

        {frames.map((frame, idx) => {
          const isSelected = !isLiveMode && selectedIndex === idx;
          return (
            <div
              key={frame.id}
              onContextMenu={(e) => {
                e.preventDefault();
                onSelectFrame(idx);
                setFrameMenu({ x: e.clientX, y: e.clientY, frameIndex: idx });
              }}
              className={`group relative flex w-[112px] shrink-0 flex-col overflow-hidden rounded-lg border transition-colors ${
                isSelected
                  ? 'border-[#e0533c] bg-[#1e222b]'
                  : 'border-[#272c37] bg-[#171a21] hover:border-[#3d4557]'
              }`}
            >
              <button
                onClick={() => onSelectFrame(idx)}
                className="relative aspect-video w-full overflow-hidden bg-[#0a0c0f]"
              >
                <img
                  src={frame.thumbnailUrl || frame.dataUrl}
                  alt={`Frame ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                <span className="absolute left-1 top-1 rounded bg-black/75 px-1 py-0.5 font-mono text-[10px] text-white tabular-nums">
                  {String(idx + 1).padStart(4, '0')}
                </span>
                {frame.hold > 1 && (
                  <span className="absolute right-1 top-1 rounded bg-[#f59e0b]/90 px-1 py-0.5 font-mono text-[10px] font-semibold text-black tabular-nums">
                    ×{frame.hold}
                  </span>
                )}
              </button>

              <div className="flex items-center justify-between px-1.5 py-1 text-[10px] text-[#9aa3b2]">
                <div className="flex items-center gap-0.5">
                  <button
                    onClick={() => onMoveFrame(idx, -1)}
                    disabled={idx === 0}
                    className="rounded p-0.5 hover:bg-[#2a303d] hover:text-white disabled:opacity-25"
                    title="Nach links"
                  >
                    <ChevronLeft className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => onMoveFrame(idx, 1)}
                    disabled={idx === frames.length - 1}
                    className="rounded p-0.5 hover:bg-[#2a303d] hover:text-white disabled:opacity-25"
                    title="Nach rechts"
                  >
                    <ChevronRight className="h-3 w-3" />
                  </button>
                </div>

                <div className="flex items-center gap-0.5">
                  <button
                    onClick={() => onChangeHold(idx, 1)}
                    className="rounded px-1 font-mono hover:bg-[#2a303d] hover:text-white"
                    title="Haltedauer +1"
                  >
                    <Plus className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => onDuplicateFrame(idx)}
                    className="rounded p-0.5 hover:bg-[#2a303d] hover:text-white"
                    title="Frame duplizieren"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => onDeleteFrame(idx)}
                    className="rounded p-0.5 hover:bg-[#3b2022] hover:text-[#f87171]"
                    title="Frame löschen"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        <button
          onClick={onSelectLive}
          className={`flex h-[84px] w-[112px] shrink-0 flex-col items-center justify-center gap-1.5 rounded-lg border transition-colors ${
            isLiveMode
              ? 'border-[#e0533c] bg-[#e0533c]/15 text-white'
              : 'border-dashed border-[#343b49] bg-[#15181e] text-[#9aa3b2] hover:border-[#e0533c]/70 hover:text-white'
          }`}
        >
          <Video className="h-5 w-5 text-[#e0533c]" />
          <span className="font-mono text-xs font-semibold tracking-wide">LIVE</span>
        </button>
      </div>

      {/* Right-Click Context Menu for Timeline Frames */}
      {frameMenu && frames[frameMenu.frameIndex] && (
        <div
          onClick={(e) => e.stopPropagation()}
          style={{
            left: Math.min(frameMenu.x, window.innerWidth - 250),
            top: Math.max(16, frameMenu.y - 230),
          }}
          className="fixed z-50 w-60 rounded-xl border border-[#2d3342] bg-[#161a22] p-1.5 text-xs text-[#e2e6ee] shadow-2xl"
        >
          <div className="px-2.5 py-1 text-[11px] font-semibold text-[#8b94a5]">
            Foto #{String(frameMenu.frameIndex + 1).padStart(4, '0')}
          </div>
          <button
            onClick={() => {
              onSetCleanPlateFromFrame(frameMenu.frameIndex);
              setFrameMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <Eraser className="h-3.5 w-3.5 text-[#4ade80]" />
            Als Clean-Plate setzen
          </button>
          <button
            onClick={() => {
              onDuplicateFrame(frameMenu.frameIndex);
              setFrameMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <Copy className="h-3.5 w-3.5 text-[#9aa3b2]" />
            Foto duplizieren
          </button>
          <button
            onClick={() => {
              onChangeHold(frameMenu.frameIndex, 1);
              setFrameMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <Plus className="h-3.5 w-3.5 text-[#f59e0b]" />
            Haltedauer +1
          </button>
          <button
            onClick={() => {
              onChangeHold(frameMenu.frameIndex, -1);
              setFrameMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <Minus className="h-3.5 w-3.5 text-[#9aa3b2]" />
            Haltedauer -1
          </button>
          <div className="my-1 border-t border-[#252b37]" />
          <button
            onClick={() => {
              onDeleteFrame(frameMenu.frameIndex);
              setFrameMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[#f87171] hover:bg-[#2f1a1d]"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Foto löschen
          </button>
        </div>
      )}

      {/* Synchronized Dialogue / Audio Track Strip */}
      <div className="border-t border-[#1e232c] bg-[#0e1014] px-4 py-2">
        <div className="flex items-center gap-3 overflow-x-auto">
          <div className="flex shrink-0 items-center gap-1.5 text-xs font-medium text-[#8b94a5]">
            <Mic className="h-3.5 w-3.5 text-[#f59e0b]" />
            <span>Dialog-Spur</span>
          </div>

          {audioClips.length === 0 ? (
            <span className="text-xs text-[#616978]">
              Keine Audio-Clips vorhanden — im Tab &bdquo;Audio &amp; Dialog&ldquo; aufnehmen oder importieren.
            </span>
          ) : (
            <div className="flex items-center gap-2">
              {audioClips.map((clip) => (
                <div
                  key={clip.id}
                  className={`flex items-center gap-2 rounded-md border px-2.5 py-1 text-xs ${
                    clip.muted
                      ? 'border-[#252a34] bg-[#14171d] text-[#6e7787]'
                      : 'border-[#3b3320] bg-[#1d1912] text-[#fde68a]'
                  }`}
                >
                  <button
                    onClick={() => onToggleAudioMute(clip.id)}
                    className="hover:text-white"
                    title={clip.muted ? 'Stummschaltung aufheben' : 'Stumm'}
                  >
                    {clip.muted ? (
                      <VolumeX className="h-3.5 w-3.5" />
                    ) : (
                      <Volume2 className="h-3.5 w-3.5" />
                    )}
                  </button>
                  <span className="max-w-[120px] truncate font-medium">{clip.name}</span>

                  <div className="flex h-4 items-center gap-[1.5px]">
                    {(clip.waveformPeaks.length > 0
                      ? clip.waveformPeaks.slice(0, 18)
                      : [0.3, 0.7, 0.5, 0.9, 0.4, 0.6, 0.8, 0.3]
                    ).map((pk, i) => (
                      <span
                        key={i}
                        className="w-[2px] rounded-full bg-current opacity-75"
                        style={{ height: `${Math.max(20, Math.round(pk * 100))}%` }}
                      />
                    ))}
                  </div>

                  <span className="font-mono text-[10px] opacity-80 tabular-nums">
                    @{clip.startFrame + 1} · {clip.durationSec.toFixed(1)}s
                  </span>

                  <div className="flex items-center gap-0.5">
                    <button
                      onClick={() => onNudgeAudioClip(clip.id, -1)}
                      className="rounded px-1 hover:bg-black/30"
                      title="1 Frame früher"
                    >
                      −
                    </button>
                    <button
                      onClick={() => onNudgeAudioClip(clip.id, 1)}
                      className="rounded px-1 hover:bg-black/30"
                      title="1 Frame später"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
