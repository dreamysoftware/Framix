import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  ChevronLeft,
  ChevronRight,
  Copy,
  Eraser,
  MoveHorizontal,
  MoveVertical,
  Pause,
  Play,
  Repeat,
  Trash2,
  Video,
  X,
} from 'lucide-react';
import {
  CameraSettings,
  CustomGuide,
  DEFAULT_EFFECTS,
  FramixFrame,
  GreenscreenSettings,
  RotoPoint,
  RotoStroke,
  StudioMode,
  VirtualPuppetPose,
} from '../types/framix';
import {
  GreenscreenScanResult,
  applyChromaKey,
  applyPostEffects,
  buildFilterString,
  detectGreenscreenFromCanvas,
  drawCustomGuides,
  drawRotoStrokes,
  getStrokeBoundingBox,
  hitTestGuide,
  hitTestRotoStroke,
  loadImageElement,
} from '../utils/compositor';
import { drawVirtualStage, getStageBackdrop } from '../utils/virtualStage';

export type ViewportTool =
  | 'none'
  | 'select_move'
  | 'guide_line'
  | 'guide_path'
  | 'guide_circle'
  | 'roto_pen'
  | 'rig_remover'
  | 'roto_eraser'
  | 'greenscreen_pick';

interface ContextMenuState {
  x: number;
  y: number;
  normPt: RotoPoint;
  hitGuideId: string | null;
  hitStrokeId: string | null;
}

interface ViewportStageProps {
  mode: StudioMode;
  width: number;
  height: number;
  frames: FramixFrame[];
  guides: CustomGuide[];
  greenscreen: GreenscreenSettings;
  cleanPlateDataUrl?: string | null;
  cameraSettings: CameraSettings;
  selectedCameraId: string;
  videoStream: MediaStream | null;
  cameraError: string | null;
  puppetPose: VirtualPuppetPose;
  onChangePuppetPose: (updater: (p: VirtualPuppetPose) => VirtualPuppetPose) => void;
  isLiveMode: boolean;
  isPlaying: boolean;
  isLooping: boolean;
  selectedIndex: number;
  onionCount: number;
  onionOpacity: number;
  differenceMatte: boolean;
  captureHold: number;
  activeTool: ViewportTool;
  guideColor: string;
  guideDashed: boolean;
  showGuides: boolean;
  rotoColor: string;
  rotoSize: number;
  rotoOpacity: number;
  rotoOnionSkin: boolean;
  rigCloneOffset: { dx: number; dy: number };
  onChangeRigCloneOffset: (offset: { dx: number; dy: number }) => void;
  selectedGuideId: string | null;
  onSelectGuideId: (id: string | null) => void;
  selectedStrokeId: string | null;
  onSelectStrokeId: (id: string | null) => void;
  onAddCustomGuide: (guide: CustomGuide) => void;
  onUpdateGuide: (id: string, patch: Partial<CustomGuide>) => void;
  onDeleteGuide: (id: string) => void;
  onCommitRotoStroke: (stroke: RotoStroke) => void;
  onUpdateRotoStroke: (strokeId: string, points: RotoPoint[]) => void;
  onDeleteRotoStroke: (strokeId: string) => void;
  onPickGreenscreenColor: (hexColor: string) => void;
  greenscreenScanNonce: number;
  onGreenscreenScanResult: (res: GreenscreenScanResult) => void;
  motionWarning: string | null;
  onDismissMotionWarning: () => void;
  onDisableMotionAlerts: () => void;
  onSetCleanPlateFromFrame: (frameIndex: number) => void;
  onDuplicateFrame: (frameIndex: number) => void;
  onDeleteFrame: (frameIndex: number) => void;
  onClearFrameRoto: () => void;
  onCaptureCanvas: (canvas: HTMLCanvasElement) => void;
  onTogglePlay: () => void;
  onToggleLoop: () => void;
  onStepFrame: (delta: -1 | 1) => void;
  onToggleLive: () => void;
  onChangeCaptureHold: (hold: number) => void;
  shutterTriggerNonce: number;
}

export default function ViewportStage({
  mode,
  width,
  height,
  frames,
  guides,
  greenscreen,
  cleanPlateDataUrl,
  cameraSettings,
  selectedCameraId,
  videoStream,
  cameraError,
  puppetPose,
  onChangePuppetPose,
  isLiveMode,
  isPlaying,
  isLooping,
  selectedIndex,
  onionCount,
  onionOpacity,
  differenceMatte,
  captureHold,
  activeTool,
  guideColor,
  guideDashed,
  showGuides,
  rotoColor,
  rotoSize,
  rotoOpacity,
  rotoOnionSkin,
  rigCloneOffset,
  onChangeRigCloneOffset,
  selectedGuideId,
  onSelectGuideId,
  selectedStrokeId,
  onSelectStrokeId,
  onAddCustomGuide,
  onUpdateGuide,
  onDeleteGuide,
  onCommitRotoStroke,
  onUpdateRotoStroke,
  onDeleteRotoStroke,
  onPickGreenscreenColor,
  greenscreenScanNonce,
  onGreenscreenScanResult,
  motionWarning,
  onDismissMotionWarning,
  onDisableMotionAlerts,
  onSetCleanPlateFromFrame,
  onDuplicateFrame,
  onDeleteFrame,
  onClearFrameRoto,
  onCaptureCanvas,
  onTogglePlay,
  onToggleLoop,
  onStepFrame,
  onToggleLive,
  onChangeCaptureHold,
  shutterTriggerNonce,
}: ViewportStageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const loadedImagesRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const cleanPlateImgRef = useRef<HTMLImageElement | null>(null);
  const gsBgImgRef = useRef<HTMLImageElement | null>(null);
  const draftStrokeRef = useRef<RotoStroke | null>(null);
  const draftGuideRef = useRef<CustomGuide | null>(null);
  const rigSampleAnchorRef = useRef<RotoPoint | null>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);

  const dragStateRef = useRef<
    | { type: 'none' }
    | { type: 'puppet' }
    | { type: 'prop' }
    | { type: 'roto' }
    | { type: 'draw_guide' }
    | { type: 'move_guide'; guideId: string; handleIdx: number; startPt: RotoPoint; origPoints: RotoPoint[] }
    | { type: 'move_stroke'; strokeId: string; startPt: RotoPoint; origPoints: RotoPoint[] }
  >({ type: 'none' });

  const [flashActive, setFlashActive] = useState(false);

  useEffect(() => {
    if (!contextMenu) return;
    const close = () => setContextMenu(null);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setContextMenu(null);
    };
    window.addEventListener('click', close);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('click', close);
      window.removeEventListener('keydown', onKey);
    };
  }, [contextMenu]);

  useEffect(() => {
    if (!cleanPlateDataUrl) {
      cleanPlateImgRef.current = null;
      return;
    }
    loadImageElement(cleanPlateDataUrl)
      .then((img) => {
        cleanPlateImgRef.current = img;
      })
      .catch(() => {
        cleanPlateImgRef.current = null;
      });
  }, [cleanPlateDataUrl]);

  useEffect(() => {
    const bgUrl = greenscreen.backgroundImageDataUrl;
    if (!bgUrl) {
      gsBgImgRef.current = null;
      return;
    }
    loadImageElement(bgUrl)
      .then((img) => {
        gsBgImgRef.current = img;
      })
      .catch(() => {
        gsBgImgRef.current = null;
      });
  }, [greenscreen.backgroundImageDataUrl]);

  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;
    if (videoStream && selectedCameraId !== 'virtual') {
      vid.srcObject = videoStream;
      vid.play().catch(() => undefined);
    } else {
      vid.srcObject = null;
    }
  }, [videoStream, selectedCameraId]);

  useEffect(() => {
    for (const f of frames) {
      if (!loadedImagesRef.current.has(f.id)) {
        loadImageElement(f.dataUrl)
          .then((img) => {
            loadedImagesRef.current.set(f.id, img);
          })
          .catch(() => undefined);
      }
    }
  }, [frames]);

  const renderRawCameraSource = (targetCtx: CanvasRenderingContext2D, w: number, h: number) => {
    targetCtx.save();
    targetCtx.translate(cameraSettings.mirrorX ? w : 0, cameraSettings.mirrorY ? h : 0);
    targetCtx.scale(cameraSettings.mirrorX ? -1 : 1, cameraSettings.mirrorY ? -1 : 1);

    targetCtx.filter = buildFilterString({
      ...DEFAULT_EFFECTS,
      brightness: cameraSettings.brightness,
      contrast: cameraSettings.contrast,
      saturation: cameraSettings.saturation,
    });

    const vid = videoRef.current;
    if (
      selectedCameraId !== 'virtual' &&
      vid &&
      vid.readyState >= 2 &&
      vid.videoWidth > 0
    ) {
      const vRatio = vid.videoWidth / vid.videoHeight;
      const cRatio = w / h;
      let sx = 0;
      let sy = 0;
      let sw = vid.videoWidth;
      let sh = vid.videoHeight;
      if (vRatio > cRatio) {
        sw = vid.videoHeight * cRatio;
        sx = (vid.videoWidth - sw) / 2;
      } else {
        sh = vid.videoWidth / cRatio;
        sy = (vid.videoHeight - sh) / 2;
      }
      targetCtx.drawImage(vid, sx, sy, sw, sh, 0, 0, w, h);
    } else {
      drawVirtualStage(targetCtx, w, h, puppetPose, getStageBackdrop());
    }
    targetCtx.restore();
  };

  // Trigger Greenscreen scan when requested
  const lastScanNonce = useRef(greenscreenScanNonce);
  useEffect(() => {
    if (greenscreenScanNonce === lastScanNonce.current) return;
    lastScanNonce.current = greenscreenScanNonce;

    const scanCanvas = document.createElement('canvas');
    scanCanvas.width = 320;
    scanCanvas.height = 180;
    const sCtx = scanCanvas.getContext('2d');
    if (!sCtx) return;

    if (isLiveMode || frames.length === 0) {
      renderRawCameraSource(sCtx, 320, 180);
    } else {
      const f = frames[Math.max(0, Math.min(frames.length - 1, selectedIndex))];
      const img = f ? loadedImagesRef.current.get(f.id) : null;
      if (img) {
        sCtx.drawImage(img, 0, 0, 320, 180);
      } else {
        renderRawCameraSource(sCtx, 320, 180);
      }
    }
    onGreenscreenScanResult(detectGreenscreenFromCanvas(scanCanvas));
  });

  // Handle external shutter trigger
  const lastShutterNonce = useRef(shutterTriggerNonce);
  useEffect(() => {
    if (shutterTriggerNonce !== lastShutterNonce.current) {
      lastShutterNonce.current = shutterTriggerNonce;
      triggerShutter();
    }
  });

  const triggerShutter = () => {
    const captureCanvas = document.createElement('canvas');
    captureCanvas.width = width;
    captureCanvas.height = height;
    const cCtx = captureCanvas.getContext('2d');
    if (!cCtx) return;

    renderRawCameraSource(cCtx, width, height);
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 140);
    onCaptureCanvas(captureCanvas);
  };

  // Real-time Viewport Compositor (includes Hilfslinien ONLY in viewport!)
  useEffect(() => {
    let rafId = 0;

    const drawLoop = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d', { willReadFrequently: greenscreen.enabled });
        if (ctx) {
          ctx.save();
          ctx.clearRect(0, 0, width, height);
          ctx.fillStyle = '#08090b';
          ctx.fillRect(0, 0, width, height);

          if (isLiveMode && !isPlaying) {
            renderRawCameraSource(ctx, width, height);

            if (greenscreen.enabled) {
              applyChromaKey(ctx, width, height, greenscreen, gsBgImgRef.current);
            }

            if (frames.length > 0 && onionCount > 0 && (onionOpacity > 0 || differenceMatte)) {
              if (differenceMatte) {
                const prevFrame = frames[frames.length - 1];
                const prevImg = loadedImagesRef.current.get(prevFrame.id);
                if (prevImg) {
                  ctx.save();
                  ctx.globalCompositeOperation = 'difference';
                  ctx.drawImage(prevImg, 0, 0, width, height);
                  ctx.restore();
                }
              } else {
                const startIdx = Math.max(0, frames.length - onionCount);
                for (let i = startIdx; i < frames.length; i++) {
                  const dist = frames.length - i;
                  const img = loadedImagesRef.current.get(frames[i].id);
                  if (img) {
                    ctx.save();
                    ctx.globalAlpha = onionOpacity / dist;
                    ctx.drawImage(img, 0, 0, width, height);
                    ctx.restore();
                  }
                }
              }
            }
          } else {
            const idx = Math.max(0, Math.min(frames.length - 1, selectedIndex));
            const frame = frames[idx];
            if (frame) {
              const img = loadedImagesRef.current.get(frame.id);
              if (img) {
                ctx.save();
                ctx.filter = buildFilterString(frame.effects);
                ctx.drawImage(img, 0, 0, width, height);
                ctx.filter = 'none';
                if (greenscreen.enabled) {
                  applyChromaKey(ctx, width, height, greenscreen, gsBgImgRef.current);
                }
                applyPostEffects(ctx, frame.effects, width, height);
                ctx.restore();
              }

              if (!isPlaying && rotoOnionSkin && idx > 0) {
                const prevRoto = frames[idx - 1].rotoStrokes;
                if (prevRoto.length > 0) {
                  drawRotoStrokes(ctx, prevRoto, width, height, 0.32, '#38bdf8');
                }
              }

              const allStrokes = draftStrokeRef.current
                ? [...frame.rotoStrokes, draftStrokeRef.current]
                : frame.rotoStrokes;
              if (allStrokes.length > 0) {
                const rotoLayer = document.createElement('canvas');
                rotoLayer.width = width;
                rotoLayer.height = height;
                const rCtx = rotoLayer.getContext('2d');
                if (rCtx) {
                  drawRotoStrokes(rCtx, allStrokes, width, height, 1, undefined, {
                    cleanPlateImg: cleanPlateImgRef.current,
                    baseImg: img || null,
                  });
                  ctx.drawImage(rotoLayer, 0, 0);
                }
              }

              if (!isPlaying && mode === 'guides_roto' && selectedStrokeId) {
                const sel = frame.rotoStrokes.find((s) => s.id === selectedStrokeId);
                if (sel && sel.points.length > 0) {
                  const box = getStrokeBoundingBox(sel);
                  const pad = 10;
                  ctx.save();
                  ctx.strokeStyle = '#38bdf8';
                  ctx.lineWidth = 1.75;
                  ctx.setLineDash([5, 4]);
                  ctx.strokeRect(
                    box.minX * width - pad,
                    box.minY * height - pad,
                    (box.maxX - box.minX) * width + pad * 2,
                    (box.maxY - box.minY) * height + pad * 2
                  );
                  ctx.restore();
                }
              }
            }
          }

          // Viewport-ONLY Custom Animation Guides (Hilfslinien)
          if (showGuides && !isPlaying) {
            const allGuides = draftGuideRef.current
              ? [...guides, draftGuideRef.current]
              : guides;
            drawCustomGuides(
              ctx,
              allGuides,
              width,
              height,
              selectedGuideId,
              mode === 'guides_roto'
            );
          }

          if (
            mode === 'guides_roto' &&
            activeTool === 'rig_remover' &&
            !cleanPlateDataUrl &&
            rigSampleAnchorRef.current
          ) {
            const ax = rigSampleAnchorRef.current.x * width;
            const ay = rigSampleAnchorRef.current.y * height;
            ctx.save();
            ctx.strokeStyle = '#4ade80';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(ax, ay, 8, 0, Math.PI * 2);
            ctx.moveTo(ax - 12, ay);
            ctx.lineTo(ax + 12, ay);
            ctx.moveTo(ax, ay - 12);
            ctx.lineTo(ax, ay + 12);
            ctx.stroke();
            ctx.restore();
          }

          drawSafeGuides(ctx, width, height, cameraSettings.guide);
          ctx.restore();
        }
      }
      rafId = requestAnimationFrame(drawLoop);
    };

    rafId = requestAnimationFrame(drawLoop);
    return () => cancelAnimationFrame(rafId);
  });

  const getNormalizedPoint = (
    e: React.PointerEvent<HTMLCanvasElement> | React.MouseEvent<HTMLCanvasElement>
  ): RotoPoint => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.button === 2) return;
    setContextMenu(null);
    const pt = getNormalizedPoint(e);
    const activeFrame = !isLiveMode ? frames[selectedIndex] : null;

    // Eyedropper for Greenscreen
    if (mode === 'guides_roto' && activeTool === 'greenscreen_pick') {
      const sampleCanvas = document.createElement('canvas');
      sampleCanvas.width = width;
      sampleCanvas.height = height;
      const sCtx = sampleCanvas.getContext('2d');
      if (sCtx) {
        if (isLiveMode) {
          renderRawCameraSource(sCtx, width, height);
        } else if (activeFrame) {
          const img = loadedImagesRef.current.get(activeFrame.id);
          if (img) sCtx.drawImage(img, 0, 0, width, height);
        }
        const px = Math.min(width - 1, Math.max(0, Math.round(pt.x * width)));
        const py = Math.min(height - 1, Math.max(0, Math.round(pt.y * height)));
        const p = sCtx.getImageData(px, py, 1, 1).data;
        const hex =
          '#' +
          [p[0], p[1], p[2]]
            .map((v) => v.toString(16).padStart(2, '0'))
            .join('');
        onPickGreenscreenColor(hex);
      }
      return;
    }

    // Draw custom Hilfslinien (Line / Path / Circle)
    if (
      mode === 'guides_roto' &&
      (activeTool === 'guide_line' || activeTool === 'guide_path' || activeTool === 'guide_circle')
    ) {
      e.currentTarget.setPointerCapture(e.pointerId);
      dragStateRef.current = { type: 'draw_guide' };
      const kind =
        activeTool === 'guide_line'
          ? 'line'
          : activeTool === 'guide_circle'
          ? 'circle'
          : 'path';
      draftGuideRef.current = {
        id: `guide_${Date.now()}`,
        name:
          kind === 'line'
            ? `Linie ${guides.length + 1}`
            : kind === 'circle'
            ? `Kreis/Bogen ${guides.length + 1}`
            : `Pfad ${guides.length + 1}`,
        kind,
        points: [pt, pt],
        color: guideColor,
        dashed: guideDashed,
        width: 2,
        visible: true,
      };
      return;
    }

    // Select & Move custom Hilfslinien or Roto strokes
    if (mode === 'guides_roto' && activeTool === 'select_move') {
      const guideHit = showGuides ? hitTestGuide(guides, pt, width / height) : null;
      if (guideHit) {
        e.currentTarget.setPointerCapture(e.pointerId);
        onSelectGuideId(guideHit.guide.id);
        onSelectStrokeId(null);
        dragStateRef.current = {
          type: 'move_guide',
          guideId: guideHit.guide.id,
          handleIdx: guideHit.handleIdx,
          startPt: pt,
          origPoints: guideHit.guide.points.map((p) => ({ ...p })),
        };
        return;
      }

      if (activeFrame) {
        const strokeHit = hitTestRotoStroke(activeFrame.rotoStrokes, pt);
        if (strokeHit) {
          e.currentTarget.setPointerCapture(e.pointerId);
          onSelectStrokeId(strokeHit.id);
          onSelectGuideId(null);
          dragStateRef.current = {
            type: 'move_stroke',
            strokeId: strokeHit.id,
            startPt: pt,
            origPoints: strokeHit.points.map((p) => ({ ...p })),
          };
          return;
        }
      }

      onSelectGuideId(null);
      onSelectStrokeId(null);
      return;
    }

    if (mode === 'guides_roto' && activeTool === 'rig_remover' && e.altKey) {
      rigSampleAnchorRef.current = pt;
      return;
    }

    if (
      mode === 'guides_roto' &&
      (activeTool === 'roto_pen' || activeTool === 'rig_remover' || activeTool === 'roto_eraser') &&
      !isLiveMode &&
      activeFrame
    ) {
      e.currentTarget.setPointerCapture(e.pointerId);
      dragStateRef.current = { type: 'roto' };

      const cloneOffset =
        activeTool === 'rig_remover' && rigSampleAnchorRef.current
          ? {
              dx: pt.x - rigSampleAnchorRef.current.x,
              dy: pt.y - rigSampleAnchorRef.current.y,
            }
          : rigCloneOffset;

      if (activeTool === 'rig_remover' && rigSampleAnchorRef.current) {
        onChangeRigCloneOffset(cloneOffset);
      }

      draftStrokeRef.current = {
        id: `stroke_${Date.now()}`,
        tool:
          activeTool === 'roto_eraser'
            ? 'eraser'
            : activeTool === 'rig_remover'
            ? 'rig_remover'
            : 'pen',
        color: rotoColor,
        size: rotoSize,
        opacity: activeTool === 'rig_remover' ? 1 : rotoOpacity,
        points: [pt],
        cloneOffset: activeTool === 'rig_remover' ? cloneOffset : undefined,
      };
      return;
    }

    if (isLiveMode && selectedCameraId === 'virtual') {
      e.currentTarget.setPointerCapture(e.pointerId);
      const distProp = Math.hypot(pt.x - puppetPose.propX, pt.y - puppetPose.propY);
      if (distProp < 0.08) {
        dragStateRef.current = { type: 'prop' };
      } else {
        dragStateRef.current = { type: 'puppet' };
      }
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const drag = dragStateRef.current;
    if (drag.type === 'none') return;
    const pt = getNormalizedPoint(e);

    if (drag.type === 'draw_guide' && draftGuideRef.current) {
      if (draftGuideRef.current.kind === 'path') {
        draftGuideRef.current = {
          ...draftGuideRef.current,
          points: [...draftGuideRef.current.points, pt],
        };
      } else {
        draftGuideRef.current = {
          ...draftGuideRef.current,
          points: [draftGuideRef.current.points[0], pt],
        };
      }
    } else if (drag.type === 'roto' && draftStrokeRef.current) {
      draftStrokeRef.current = {
        ...draftStrokeRef.current,
        points: [...draftStrokeRef.current.points, pt],
      };
    } else if (drag.type === 'move_guide') {
      const dx = pt.x - drag.startPt.x;
      const dy = pt.y - drag.startPt.y;
      const nextPoints = drag.origPoints.map((p, idx) => {
        if (drag.handleIdx === -1 || drag.handleIdx === idx) {
          return {
            x: Math.max(0, Math.min(1, p.x + dx)),
            y: Math.max(0, Math.min(1, p.y + dy)),
          };
        }
        return p;
      });
      onUpdateGuide(drag.guideId, { points: nextPoints });
    } else if (drag.type === 'move_stroke') {
      const dx = pt.x - drag.startPt.x;
      const dy = pt.y - drag.startPt.y;
      const nextPoints = drag.origPoints.map((p) => ({
        x: Math.max(0, Math.min(1, p.x + dx)),
        y: Math.max(0, Math.min(1, p.y + dy)),
      }));
      onUpdateRotoStroke(drag.strokeId, nextPoints);
    } else if (drag.type === 'prop') {
      onChangePuppetPose((p) => ({
        ...p,
        propX: Math.max(0.08, Math.min(0.92, pt.x)),
        propY: Math.max(0.15, Math.min(0.88, pt.y)),
      }));
    } else if (drag.type === 'puppet') {
      onChangePuppetPose((p) => ({
        ...p,
        bodyX: Math.max(0.1, Math.min(0.9, pt.x)),
        bodyY: Math.max(0.35, Math.min(0.82, pt.y)),
      }));
    }
  };

  const handlePointerUp = () => {
    if (dragStateRef.current.type === 'draw_guide' && draftGuideRef.current) {
      onAddCustomGuide(draftGuideRef.current);
      onSelectGuideId(draftGuideRef.current.id);
      draftGuideRef.current = null;
    }
    if (dragStateRef.current.type === 'roto' && draftStrokeRef.current) {
      onCommitRotoStroke(draftStrokeRef.current);
      draftStrokeRef.current = null;
    }
    dragStateRef.current = { type: 'none' };
  };

  const handleContextMenu = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const pt = getNormalizedPoint(e);
    const activeFrame = !isLiveMode ? frames[selectedIndex] : null;
    const guideHit = showGuides ? hitTestGuide(guides, pt, width / height) : null;
    const strokeHit = activeFrame ? hitTestRotoStroke(activeFrame.rotoStrokes, pt) : null;

    if (guideHit) onSelectGuideId(guideHit.guide.id);
    if (strokeHit) onSelectStrokeId(strokeHit.id);

    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      normPt: pt,
      hitGuideId: guideHit?.guide.id || null,
      hitStrokeId: strokeHit?.id || null,
    });
  };

  const activeTimecodeFrame = isLiveMode ? frames.length + 1 : Math.max(1, selectedIndex + 1);
  const contextGuide = contextMenu?.hitGuideId
    ? guides.find((g) => g.id === contextMenu.hitGuideId) || null
    : null;

  return (
    <div className="flex flex-1 flex-col overflow-hidden bg-[#0a0c0f]">
      <video ref={videoRef} playsInline muted className="hidden" />

      {/* Top Viewport Strip */}
      <div className="flex h-9 shrink-0 items-center justify-between border-b border-[#1d222b] bg-[#101318] px-4 text-xs">
        <div className="flex items-center gap-3">
          <span
            className={`font-mono font-semibold ${
              isPlaying
                ? 'text-[#4ade80]'
                : isLiveMode
                ? 'text-[#e0533c]'
                : 'text-[#f59e0b]'
            }`}
          >
            {isPlaying ? 'WIEDERGABE' : isLiveMode ? 'LIVE-KAMERA' : 'EINZELBILD-CHECK'}
          </span>
          <span className="text-[#6e7787]">·</span>
          <span className="font-mono text-[#c7cdd8] tabular-nums">
            Bild {String(activeTimecodeFrame).padStart(4, '0')} / {String(frames.length).padStart(4, '0')}
          </span>
          {greenscreen.enabled && (
            <>
              <span className="text-[#6e7787]">·</span>
              <span className="text-[#4ade80]">Greenscreen aktiv</span>
            </>
          )}
          {mode === 'guides_roto' && (
            <>
              <span className="text-[#6e7787]">·</span>
              <span className="text-[#8b94a5]">
                {activeTool === 'select_move'
                  ? 'Hilfslinien & Formen per Ziehen verschieben'
                  : activeTool === 'greenscreen_pick'
                  ? 'Auf grünen Hintergrund klicken zum Farbmessen'
                  : activeTool === 'guide_line' || activeTool === 'guide_path' || activeTool === 'guide_circle'
                  ? 'Auf das Bild zeichnen — Hilfslinien erscheinen nicht im Video'
                  : 'Rechtsklick für Hilfslinien & Foto-Aktionen'}
              </span>
            </>
          )}
          {cameraError && selectedCameraId !== 'virtual' && (
            <span className="text-[#fca5a5]">{cameraError}</span>
          )}
        </div>

        <div className="font-mono text-[#8b94a5] tabular-nums">
          {width}×{height}
        </div>
      </div>

      {/* Main Canvas Stage */}
      <div className="relative flex flex-1 items-center justify-center overflow-hidden p-4">
        <div className="relative flex max-h-full max-w-full items-center justify-center">
          <canvas
            ref={canvasRef}
            width={width}
            height={height}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
            onContextMenu={handleContextMenu}
            className={`max-h-[calc(100vh-310px)] max-w-full rounded border border-[#242934] bg-[#08090b] shadow-2xl ${
              mode === 'guides_roto' && activeTool === 'select_move'
                ? 'cursor-move'
                : mode === 'guides_roto' && activeTool !== 'none'
                ? 'cursor-crosshair'
                : isLiveMode && selectedCameraId === 'virtual'
                ? 'cursor-grab active:cursor-grabbing'
                : 'cursor-default'
            }`}
            style={{ aspectRatio: `${width} / ${height}` }}
          />

          {flashActive && (
            <div className="pointer-events-none absolute inset-0 rounded bg-white/55 transition-opacity" />
          )}

          {/* Small Animation Smoothness / Jump Warning Toast */}
          {motionWarning && (
            <div className="absolute right-3 top-3 z-20 flex max-w-xs items-start gap-2.5 rounded-lg border border-[#d97706]/60 bg-[#1a150e]/95 px-3.5 py-2.5 text-xs text-[#fde68a] shadow-xl">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#f59e0b]" />
              <div className="flex-1">
                <div className="font-semibold text-white">Animations-Hinweis</div>
                <p className="mt-0.5 leading-snug text-[#f3d99d]">{motionWarning}</p>
                <div className="mt-2 flex items-center gap-3">
                  <button
                    onClick={onDismissMotionWarning}
                    className="font-medium text-white underline-offset-2 hover:underline"
                  >
                    Verstanden
                  </button>
                  <button
                    onClick={onDisableMotionAlerts}
                    className="text-[#c7b387] hover:text-white"
                  >
                    Warnungen ausschalten
                  </button>
                </div>
              </div>
              <button
                onClick={onDismissMotionWarning}
                className="rounded p-0.5 text-[#c7b387] hover:text-white"
                aria-label="Hinweis schließen"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Right-Click Context Menu */}
      {contextMenu && (
        <div
          onClick={(e) => e.stopPropagation()}
          style={{
            left: Math.min(contextMenu.x, window.innerWidth - 260),
            top: Math.min(contextMenu.y, window.innerHeight - 320),
          }}
          className="fixed z-50 w-64 rounded-xl border border-[#2d3342] bg-[#161a22] p-1.5 text-xs text-[#e2e6ee] shadow-2xl"
        >
          {contextGuide && (
            <>
              <div className="px-2.5 py-1 text-[11px] font-semibold text-[#8b94a5]">
                Hilfslinie: {contextGuide.name}
              </div>
              <button
                onClick={() => {
                  onUpdateGuide(contextGuide.id, { dashed: !contextGuide.dashed });
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
              >
                <MoveHorizontal className="h-3.5 w-3.5 text-[#38bdf8]" />
                {contextGuide.dashed ? 'Durchgezogene Linie' : 'Gestrichelte Linie'}
              </button>
              <button
                onClick={() => {
                  onDeleteGuide(contextGuide.id);
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[#f87171] hover:bg-[#2f1a1d]"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Diese Hilfslinie löschen
              </button>
              <div className="my-1 border-t border-[#252b37]" />
            </>
          )}

          {contextMenu.hitStrokeId && (
            <>
              <button
                onClick={() => {
                  onDeleteRotoStroke(contextMenu.hitStrokeId!);
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[#f87171] hover:bg-[#2f1a1d]"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Angeklickte Roto-Form löschen
              </button>
              <div className="my-1 border-t border-[#252b37]" />
            </>
          )}

          <div className="px-2.5 py-1 text-[11px] font-semibold text-[#8b94a5]">
            Hilfslinien (nicht im Video)
          </div>
          <button
            onClick={() => {
              onAddCustomGuide({
                id: `guide_${Date.now()}`,
                name: `Waagerecht ${guides.length + 1}`,
                kind: 'horizontal',
                points: [contextMenu.normPt],
                color: guideColor,
                dashed: guideDashed,
                width: 2,
                visible: true,
              });
              setContextMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <MoveHorizontal className="h-3.5 w-3.5 text-[#38bdf8]" />
            Horizontale Hilfslinie hier setzen
          </button>
          <button
            onClick={() => {
              onAddCustomGuide({
                id: `guide_${Date.now()}`,
                name: `Senkrecht ${guides.length + 1}`,
                kind: 'vertical',
                points: [contextMenu.normPt],
                color: guideColor,
                dashed: guideDashed,
                width: 2,
                visible: true,
              });
              setContextMenu(null);
            }}
            className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
          >
            <MoveVertical className="h-3.5 w-3.5 text-[#38bdf8]" />
            Vertikale Hilfslinie hier setzen
          </button>

          {!isLiveMode && frames[selectedIndex] && (
            <>
              <div className="my-1 border-t border-[#252b37]" />
              <div className="px-2.5 py-1 text-[11px] font-semibold text-[#8b94a5]">
                Foto #{String(selectedIndex + 1).padStart(4, '0')}
              </div>
              <button
                onClick={() => {
                  onSetCleanPlateFromFrame(selectedIndex);
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
              >
                <Eraser className="h-3.5 w-3.5 text-[#4ade80]" />
                Als Clean-Plate (Rig-Entfernung) setzen
              </button>
              <button
                onClick={() => {
                  onDuplicateFrame(selectedIndex);
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
              >
                <Copy className="h-3.5 w-3.5 text-[#9aa3b2]" />
                Foto duplizieren
              </button>
              <button
                onClick={() => {
                  onClearFrameRoto();
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left hover:bg-[#232936]"
              >
                <Eraser className="h-3.5 w-3.5 text-[#9aa3b2]" />
                Roto-Ebene dieses Fotos leeren
              </button>
              <div className="my-1 border-t border-[#252b37]" />
              <button
                onClick={() => {
                  onDeleteFrame(selectedIndex);
                  setContextMenu(null);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[#f87171] hover:bg-[#2f1a1d]"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Dieses Foto löschen
              </button>
            </>
          )}
        </div>
      )}

      {/* Transport & Shutter Bar */}
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-4 border-t border-[#1e232c] bg-[#12151a] px-5 py-2.5">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onStepFrame(-1)}
            disabled={frames.length === 0}
            className="rounded-md border border-[#272c37] bg-[#181c24] p-2 text-[#c7cdd8] transition-colors hover:bg-[#232935] hover:text-white disabled:opacity-35"
            title="Vorheriges Bild (Pfeil links)"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          <button
            onClick={onTogglePlay}
            disabled={frames.length === 0}
            className={`flex items-center gap-1.5 rounded-md border px-3.5 py-2 text-xs font-semibold transition-colors disabled:opacity-35 ${
              isPlaying
                ? 'border-[#16a34a] bg-[#16a34a]/20 text-[#4ade80]'
                : 'border-[#272c37] bg-[#181c24] text-white hover:bg-[#232935]'
            }`}
            title="Abspielen / Stopp (P)"
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {isPlaying ? 'Stopp' : 'Abspielen'}
          </button>

          <button
            onClick={() => onStepFrame(1)}
            disabled={frames.length === 0}
            className="rounded-md border border-[#272c37] bg-[#181c24] p-2 text-[#c7cdd8] transition-colors hover:bg-[#232935] hover:text-white disabled:opacity-35"
            title="Nächstes Bild (Pfeil rechts)"
          >
            <ChevronRight className="h-4 w-4" />
          </button>

          <button
            onClick={onToggleLoop}
            className={`rounded-md border p-2 transition-colors ${
              isLooping
                ? 'border-[#f59e0b]/60 bg-[#f59e0b]/15 text-[#fbbf24]'
                : 'border-[#272c37] bg-[#181c24] text-[#8b94a5] hover:text-white'
            }`}
            title="Endlosschleife"
          >
            <Repeat className="h-4 w-4" />
          </button>

          <button
            onClick={onToggleLive}
            className={`ml-1 flex items-center gap-1.5 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
              isLiveMode
                ? 'border-[#e0533c]/60 bg-[#e0533c]/15 text-white'
                : 'border-[#272c37] bg-[#181c24] text-[#c7cdd8] hover:text-white'
            }`}
            title="Zwischen Live-Kamera und ausgewähltem Bild wechseln (L)"
          >
            <Video className="h-3.5 w-3.5" />
            {isLiveMode ? 'Live aktiv' : 'Zu Live'}
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 rounded-lg border border-[#262c38] bg-[#0e1014] p-1 text-xs">
            <span className="px-2 text-[#8b94a5]">Halt:</span>
            {[1, 2, 3, 4].map((h) => (
              <button
                key={h}
                onClick={() => onChangeCaptureHold(h)}
                className={`rounded px-2 py-1 font-mono tabular-nums transition-colors ${
                  captureHold === h
                    ? 'bg-[#262d3b] font-semibold text-white'
                    : 'text-[#8b94a5] hover:text-white'
                }`}
              >
                ×{h}
              </button>
            ))}
          </div>

          <button
            onClick={triggerShutter}
            className="flex items-center gap-2 whitespace-nowrap rounded-lg bg-[#e0533c] px-5 py-2 text-sm font-semibold text-white shadow-lg transition-colors hover:bg-[#c94530]"
          >
            <Camera className="h-4 w-4" />
            Auslösen (Leertaste)
          </button>
        </div>
      </div>
    </div>
  );
}

function drawSafeGuides(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  guide: CameraSettings['guide']
): void {
  if (guide === 'none') return;
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
  ctx.lineWidth = 1.25;

  if (guide === 'thirds') {
    ctx.beginPath();
    ctx.moveTo(w / 3, 0);
    ctx.lineTo(w / 3, h);
    ctx.moveTo((w * 2) / 3, 0);
    ctx.lineTo((w * 2) / 3, h);
    ctx.moveTo(0, h / 3);
    ctx.lineTo(w, h / 3);
    ctx.moveTo(0, (h * 2) / 3);
    ctx.lineTo(w, (h * 2) / 3);
    ctx.stroke();
  } else if (guide === 'crosshair') {
    ctx.beginPath();
    ctx.moveTo(w / 2 - 28, h / 2);
    ctx.lineTo(w / 2 + 28, h / 2);
    ctx.moveTo(w / 2, h / 2 - 28);
    ctx.lineTo(w / 2, h / 2 + 28);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, 16, 0, Math.PI * 2);
    ctx.stroke();
  } else if (guide === 'safe169') {
    const padX = w * 0.05;
    const padY = h * 0.05;
    ctx.setLineDash([8, 6]);
    ctx.strokeRect(padX, padY, w - padX * 2, h - padY * 2);
    const titleX = w * 0.1;
    const titleY = h * 0.1;
    ctx.strokeRect(titleX, titleY, w - titleX * 2, h - titleY * 2);
  } else if (guide === 'cinema239') {
    const targetH = w / 2.39;
    const barH = Math.max(0, (h - targetH) / 2);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.fillRect(0, 0, w, barH);
    ctx.fillRect(0, h - barH, w, barH);
  }
  ctx.restore();
}
