export type StudioMode =
  | 'capture'
  | 'timeline'
  | 'guides_roto'
  | 'effects'
  | 'audio';

export type SafeGuideType =
  | 'none'
  | 'thirds'
  | 'crosshair'
  | 'safe169'
  | 'cinema239';

export type EffectPreset =
  | 'none'
  | 'cinematic'
  | 'noir'
  | 'warm_clay'
  | 'kodachrome';

export interface FrameEffects {
  preset: EffectPreset;
  brightness: number; // -50 to +50
  contrast: number; // -50 to +50
  saturation: number; // -100 to +100
  temperature: number; // -50 to +50 (cool to warm)
  vignette: number; // 0 to 100
  grain: number; // 0 to 100
}

export interface RotoPoint {
  x: number; // normalized 0..1
  y: number; // normalized 0..1
}

export interface RotoStroke {
  id: string;
  tool: 'pen' | 'eraser' | 'rig_remover';
  color: string;
  size: number; // normalized relative to 1080p width (e.g. 2..48)
  opacity: number; // 0..1
  points: RotoPoint[];
  cloneOffset?: { dx: number; dy: number };
}

export interface CustomGuide {
  id: string;
  name: string;
  kind: 'line' | 'path' | 'circle' | 'horizontal' | 'vertical';
  points: RotoPoint[];
  color: string;
  dashed: boolean;
  width: number; // 1..5 px
  visible: boolean;
}

export interface GreenscreenSettings {
  enabled: boolean;
  keyColor: string; // e.g. '#00b140'
  tolerance: number; // 15..120
  smoothness: number; // 0..40
  spillSuppression: number; // 0..100
  backgroundMode: 'checker' | 'dark' | 'color' | 'image';
  backgroundColor: string;
  backgroundImageDataUrl?: string | null;
}

export interface FramixFrame {
  id: string;
  dataUrl: string;
  thumbnailUrl: string;
  hold: number; // exposures per frame (1..8)
  label: string;
  rotoStrokes: RotoStroke[];
  effects: FrameEffects;
  capturedAt: number;
}

export interface AudioTrackClip {
  id: string;
  name: string;
  dataUrl: string;
  startFrame: number;
  durationSec: number;
  volume: number;
  muted: boolean;
  waveformPeaks: number[];
  createdAt: number;
}

export interface CameraSettings {
  mirrorX: boolean;
  mirrorY: boolean;
  brightness: number;
  contrast: number;
  saturation: number;
  guide: SafeGuideType;
}

export interface ResolutionPreset {
  width: number;
  height: number;
  label: string;
}

export interface FramixProject {
  version: '1.0';
  fileExtension: '.frmp';
  id: string;
  name: string;
  folderId: string | null;
  createdAt: number;
  updatedAt: number;
  fps: number;
  resolution: ResolutionPreset;
  frames: FramixFrame[];
  guides: CustomGuide[];
  greenscreen: GreenscreenSettings;
  motionAlertsEnabled: boolean;
  audioClips: AudioTrackClip[];
  cameraSettings: CameraSettings;
  cleanPlateDataUrl?: string | null;
}

export interface FramixFolder {
  id: string;
  name: string;
  createdAt: number;
}

export interface VirtualPuppetPose {
  bodyX: number;
  bodyY: number;
  headTilt: number;
  leftArmAngle: number;
  rightArmAngle: number;
  leftLegAngle: number;
  rightLegAngle: number;
  propX: number;
  propY: number;
  lightAngle: number;
  greenScreenBackdrop?: boolean;
}

export const DEFAULT_EFFECTS: FrameEffects = {
  preset: 'none',
  brightness: 0,
  contrast: 0,
  saturation: 0,
  temperature: 0,
  vignette: 0,
  grain: 0,
};

export const DEFAULT_GREENSCREEN: GreenscreenSettings = {
  enabled: false,
  keyColor: '#00b140',
  tolerance: 52,
  smoothness: 16,
  spillSuppression: 45,
  backgroundMode: 'dark',
  backgroundColor: '#132238',
  backgroundImageDataUrl: null,
};

export const RESOLUTION_PRESETS: ResolutionPreset[] = [
  { width: 1280, height: 720, label: 'HD 720p (1280×720)' },
  { width: 1920, height: 1080, label: 'Full HD (1920×1080)' },
  { width: 3840, height: 2160, label: '4K UHD (3840×2160)' },
  { width: 1080, height: 1080, label: 'Quadrat (1080×1080)' },
];
