import {
  CustomGuide,
  FrameEffects,
  GreenscreenSettings,
  RotoPoint,
  RotoStroke,
} from '../types/framix';

export function buildFilterString(effects: FrameEffects): string {
  let b = 100 + effects.brightness;
  let c = 100 + effects.contrast;
  let s = 100 + effects.saturation;
  let sepia = 0;
  let hue = 0;

  if (effects.preset === 'cinematic') {
    c += 12;
    s -= 12;
    sepia += 12;
  } else if (effects.preset === 'noir') {
    s = 0;
    c += 28;
    b -= 4;
  } else if (effects.preset === 'warm_clay') {
    sepia += 22;
    s += 15;
    b += 4;
  } else if (effects.preset === 'kodachrome') {
    c += 16;
    s += 25;
    hue -= 4;
  }

  return `brightness(${Math.max(10, b)}%) contrast(${Math.max(10, c)}%) saturate(${Math.max(0, s)}%) sepia(${sepia}%) hue-rotate(${hue}deg)`;
}

function traceStrokePath(
  ctx: CanvasRenderingContext2D,
  points: RotoPoint[],
  width: number,
  height: number
): void {
  ctx.beginPath();
  const first = points[0];
  ctx.moveTo(first.x * width, first.y * height);

  if (points.length === 1) {
    ctx.lineTo(first.x * width + 0.01, first.y * height + 0.01);
  } else {
    for (let i = 1; i < points.length - 1; i++) {
      const curr = points[i];
      const next = points[i + 1];
      const midX = ((curr.x + next.x) / 2) * width;
      const midY = ((curr.y + next.y) / 2) * height;
      ctx.quadraticCurveTo(curr.x * width, curr.y * height, midX, midY);
    }
    const last = points[points.length - 1];
    ctx.lineTo(last.x * width, last.y * height);
  }
}

export function drawRotoStrokes(
  ctx: CanvasRenderingContext2D,
  strokes: RotoStroke[],
  width: number,
  height: number,
  overrideAlpha = 1,
  tintColor?: string,
  rigContext?: {
    cleanPlateImg?: HTMLImageElement | null;
    baseImg?: HTMLImageElement | null;
  }
): void {
  if (!strokes || strokes.length === 0) return;

  ctx.save();
  for (const stroke of strokes) {
    if (stroke.points.length === 0) continue;

    if (stroke.tool === 'rig_remover') {
      if (tintColor) continue;
      const sourceImg = rigContext?.cleanPlateImg || rigContext?.baseImg;
      if (!sourceImg) continue;

      const patchCanvas = document.createElement('canvas');
      patchCanvas.width = width;
      patchCanvas.height = height;
      const pCtx = patchCanvas.getContext('2d');
      if (!pCtx) continue;

      pCtx.lineCap = 'round';
      pCtx.lineJoin = 'round';
      pCtx.lineWidth = (stroke.size / 1280) * width;
      pCtx.strokeStyle = 'rgba(255, 255, 255, 1)';
      pCtx.globalAlpha = stroke.opacity * overrideAlpha;
      traceStrokePath(pCtx, stroke.points, width, height);
      pCtx.stroke();

      pCtx.globalCompositeOperation = 'source-in';
      pCtx.globalAlpha = 1;
      if (rigContext?.cleanPlateImg) {
        pCtx.drawImage(rigContext.cleanPlateImg, 0, 0, width, height);
      } else if (rigContext?.baseImg) {
        const dx = (stroke.cloneOffset?.dx ?? 0.045) * width;
        const dy = (stroke.cloneOffset?.dy ?? 0) * height;
        pCtx.drawImage(rigContext.baseImg, dx, dy, width, height);
      }

      ctx.save();
      ctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(patchCanvas, 0, 0);
      ctx.restore();
      continue;
    }

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = (stroke.size / 1280) * width;

    if (stroke.tool === 'eraser') {
      if (tintColor) {
        ctx.restore();
        continue;
      }
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.globalAlpha = 1;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = tintColor || stroke.color;
      ctx.globalAlpha = stroke.opacity * overrideAlpha;
    }

    traceStrokePath(ctx, stroke.points, width, height);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

/**
 * Viewport-ONLY custom animation guides (Hilfslinien).
 * Never called by video/GIF/PNG export!
 */
export function drawCustomGuides(
  ctx: CanvasRenderingContext2D,
  guides: CustomGuide[],
  width: number,
  height: number,
  selectedGuideId?: string | null,
  showHandles = true
): void {
  const visible = guides.filter((g) => g.visible && g.points.length >= 1);
  if (visible.length === 0) return;

  for (const g of visible) {
    const isSel = selectedGuideId === g.id;
    ctx.save();
    ctx.strokeStyle = g.color;
    ctx.lineWidth = isSel ? g.width + 1.2 : g.width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.setLineDash(g.dashed ? [8, 6] : []);

    ctx.beginPath();
    if (g.kind === 'horizontal') {
      const y = g.points[0].y * height;
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    } else if (g.kind === 'vertical') {
      const x = g.points[0].x * width;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    } else if (g.kind === 'circle' && g.points.length >= 2) {
      const [c, edge] = g.points;
      const r = Math.hypot((edge.x - c.x) * width, (edge.y - c.y) * height);
      ctx.arc(c.x * width, c.y * height, Math.max(4, r), 0, Math.PI * 2);
    } else if (g.points.length >= 2) {
      ctx.moveTo(g.points[0].x * width, g.points[0].y * height);
      for (let i = 1; i < g.points.length; i++) {
        ctx.lineTo(g.points[i].x * width, g.points[i].y * height);
      }
    }
    ctx.stroke();

    if (showHandles) {
      ctx.setLineDash([]);
      const handlePts =
        g.kind === 'path' && g.points.length > 2
          ? [g.points[0], g.points[g.points.length - 1]]
          : g.points;
      for (const pt of handlePts) {
        ctx.fillStyle = isSel ? '#ffffff' : g.color;
        ctx.strokeStyle = '#0a0c0f';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(pt.x * width, pt.y * height, isSel ? 6 : 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    }

    ctx.restore();
  }
}

export function hitTestGuide(
  guides: CustomGuide[],
  pt: RotoPoint,
  aspect = 16 / 9
): { guide: CustomGuide; handleIdx: number } | null {
  // Check endpoint handles first
  for (let i = guides.length - 1; i >= 0; i--) {
    const g = guides[i];
    if (!g.visible) continue;
    for (let hi = 0; hi < g.points.length; hi++) {
      if (g.kind === 'path' && hi > 0 && hi < g.points.length - 1) continue;
      if (Math.hypot(g.points[hi].x - pt.x, (g.points[hi].y - pt.y) / aspect) <= 0.025) {
        return { guide: g, handleIdx: hi };
      }
    }
  }

  // Check line / path body
  for (let i = guides.length - 1; i >= 0; i--) {
    const g = guides[i];
    if (!g.visible || g.points.length === 0) continue;

    if (g.kind === 'horizontal') {
      if (Math.abs(pt.y - g.points[0].y) <= 0.02) return { guide: g, handleIdx: -1 };
    } else if (g.kind === 'vertical') {
      if (Math.abs(pt.x - g.points[0].x) <= 0.015) return { guide: g, handleIdx: -1 };
    } else if (g.kind === 'circle' && g.points.length >= 2) {
      const [c, edge] = g.points;
      const r = Math.hypot((edge.x - c.x) * aspect, edge.y - c.y);
      const d = Math.hypot((pt.x - c.x) * aspect, pt.y - c.y);
      if (Math.abs(d - r) <= 0.03) return { guide: g, handleIdx: -1 };
    } else if (g.points.length >= 2) {
      for (let k = 0; k < g.points.length - 1; k++) {
        const a = g.points[k];
        const b = g.points[k + 1];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const lenSq = dx * dx + dy * dy;
        const t =
          lenSq > 1e-6
            ? Math.max(0, Math.min(1, ((pt.x - a.x) * dx + (pt.y - a.y) * dy) / lenSq))
            : 0;
        const projX = a.x + t * dx;
        const projY = a.y + t * dy;
        if (Math.hypot(pt.x - projX, pt.y - projY) <= 0.022) {
          return { guide: g, handleIdx: -1 };
        }
      }
    }
  }
  return null;
}

export function getStrokeBoundingBox(stroke: RotoStroke): {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
} {
  let minX = 1;
  let minY = 1;
  let maxX = 0;
  let maxY = 0;
  for (const p of stroke.points) {
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, minY, maxX, maxY };
}

export function hitTestRotoStroke(
  strokes: RotoStroke[],
  pt: RotoPoint,
  threshold = 0.025
): RotoStroke | null {
  for (let i = strokes.length - 1; i >= 0; i--) {
    const s = strokes[i];
    for (const p of s.points) {
      if (Math.hypot(p.x - pt.x, p.y - pt.y) <= threshold) {
        return s;
      }
    }
  }
  return null;
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const num = parseInt(full, 16);
  if (Number.isNaN(num)) return [0, 177, 64];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function rgbToHex(r: number, g: number, b: number): string {
  return (
    '#' +
    [r, g, b]
      .map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'))
      .join('')
  );
}

export interface GreenscreenScanResult {
  detected: boolean;
  greenPct: number;
  suggestedColor: string;
  message: string;
}

export function detectGreenscreenFromCanvas(
  sourceCanvas: HTMLCanvasElement
): GreenscreenScanResult {
  const w = 160;
  const h = 90;
  const tmp = document.createElement('canvas');
  tmp.width = w;
  tmp.height = h;
  const ctx = tmp.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return {
      detected: false,
      greenPct: 0,
      suggestedColor: '#00b140',
      message: 'Analyse nicht verfügbar.',
    };
  }
  ctx.drawImage(sourceCanvas, 0, 0, w, h);
  const data = ctx.getImageData(0, 0, w, h).data;
  const total = w * h;

  let greenCount = 0;
  let sumR = 0;
  let sumG = 0;
  let sumB = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    if (g > 70 && g - r > 28 && g - b > 24) {
      greenCount++;
      sumR += r;
      sumG += g;
      sumB += b;
    }
  }

  const greenPct = Math.round((greenCount / total) * 100);
  if (greenPct >= 10 && greenCount > 0) {
    const suggestedColor = rgbToHex(sumR / greenCount, sumG / greenCount, sumB / greenCount);
    return {
      detected: true,
      greenPct,
      suggestedColor,
      message: `Greenscreen erkannt (${greenPct}% Grünfläche · Key-Farbe ${suggestedColor}).`,
    };
  }

  return {
    detected: false,
    greenPct,
    suggestedColor: '#00b140',
    message: `Kein eindeutiger Greenscreen erkannt (${greenPct}% Grünanteil). Pipette nutzen oder virtuelle Leinwand einschalten.`,
  };
}

export function applyChromaKey(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  gs: GreenscreenSettings,
  bgImg?: HTMLImageElement | null
): void {
  if (!gs.enabled) return;

  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;
  const [kr, kg, kb] = hexToRgb(gs.keyColor);
  const tol = Math.max(8, gs.tolerance);
  const soft = Math.max(1, gs.smoothness);
  const spillFactor = gs.spillSuppression / 100;

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    const dist = Math.sqrt(
      (r - kr) * (r - kr) + (g - kg) * (g - kg) + (b - kb) * (b - kb)
    );

    if (dist < tol) {
      data[i + 3] = 0;
    } else if (dist < tol + soft) {
      const alpha = (dist - tol) / soft;
      data[i + 3] = Math.round(data[i + 3] * alpha);
      if (spillFactor > 0 && g > Math.max(r, b)) {
        const avg = (r + b) * 0.5;
        data[i + 1] = Math.round(g - (g - avg) * spillFactor * (1 - alpha * 0.5));
      }
    } else if (spillFactor > 0 && kg > kr && kg > kb && g > Math.max(r, b) + 12) {
      const avg = (r + b) * 0.5;
      data[i + 1] = Math.round(g - (g - avg) * spillFactor * 0.45);
    }
  }

  // Put keyed foreground onto temp canvas, draw background onto ctx, then composite foreground
  const fgCanvas = document.createElement('canvas');
  fgCanvas.width = width;
  fgCanvas.height = height;
  fgCanvas.getContext('2d')!.putImageData(imgData, 0, 0);

  ctx.save();
  ctx.clearRect(0, 0, width, height);
  if (gs.backgroundMode === 'image' && bgImg && bgImg.complete && bgImg.naturalWidth > 0) {
    ctx.drawImage(bgImg, 0, 0, width, height);
  } else if (gs.backgroundMode === 'color') {
    ctx.fillStyle = gs.backgroundColor;
    ctx.fillRect(0, 0, width, height);
  } else if (gs.backgroundMode === 'dark') {
    ctx.fillStyle = '#0e1014';
    ctx.fillRect(0, 0, width, height);
  } else {
    // Checkerboard transparency grid
    const sq = Math.max(16, Math.round(width / 40));
    for (let y = 0; y < height; y += sq) {
      for (let x = 0; x < width; x += sq) {
        const even = ((x / sq) + (y / sq)) % 2 === 0;
        ctx.fillStyle = even ? '#1c2028' : '#262b36';
        ctx.fillRect(x, y, sq, sq);
      }
    }
  }
  ctx.drawImage(fgCanvas, 0, 0);
  ctx.restore();
}

export interface MotionJumpReport {
  isAbruptJump: boolean;
  centroidShift: number;
  changedPct: number;
  message: string | null;
}

/**
 * Compares previous captured frame with newly captured frame to detect abrupt jumps
 * (e.g. puppet moved far away in a single frame so animation won't look smooth).
 */
export async function analyzeFrameMotionJump(
  prevDataUrl: string,
  nextCanvas: HTMLCanvasElement,
  fps: number
): Promise<MotionJumpReport> {
  try {
    const prevImg = await loadImageElement(prevDataUrl);
    const w = 64;
    const h = 36;

    const c1 = document.createElement('canvas');
    c1.width = w;
    c1.height = h;
    const ctx1 = c1.getContext('2d', { willReadFrequently: true })!;
    ctx1.drawImage(prevImg, 0, 0, w, h);

    const c2 = document.createElement('canvas');
    c2.width = w;
    c2.height = h;
    const ctx2 = c2.getContext('2d', { willReadFrequently: true })!;
    ctx2.drawImage(nextCanvas, 0, 0, w, h);

    const d1 = ctx1.getImageData(0, 0, w, h).data;
    const d2 = ctx2.getImageData(0, 0, w, h).data;

    let changedPixels = 0;
    let totalDiff = 0;
    let sumX = 0;
    let sumY = 0;
    let weightSum = 0;

    // Also measure bounding spread of changed area
    let minCx = w;
    let maxCx = 0;
    let minCy = h;
    let maxCy = 0;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const diff =
          (Math.abs(d1[i] - d2[i]) +
            Math.abs(d1[i + 1] - d2[i + 1]) +
            Math.abs(d1[i + 2] - d2[i + 2])) /
          3;
        if (diff > 26) {
          changedPixels++;
          totalDiff += diff;
          sumX += x * diff;
          sumY += y * diff;
          weightSum += diff;
          if (x < minCx) minCx = x;
          if (x > maxCx) maxCx = x;
          if (y < minCy) minCy = y;
          if (y > maxCy) maxCy = y;
        }
      }
    }

    const changedPct = (changedPixels / (w * h)) * 100;
    const spreadX = changedPixels > 0 ? (maxCx - minCx) / w : 0;
    const spreadY = changedPixels > 0 ? (maxCy - minCy) / h : 0;
    const centroidShift = Math.hypot(spreadX, spreadY);
    const avgIntensity = changedPixels > 0 ? totalDiff / changedPixels : 0;

    // Abrupt jump: substantial portion/span shifted sharply between two consecutive frames
    const isAbruptJump =
      (changedPct >= 9 && centroidShift >= 0.42) ||
      (changedPct >= 22 && avgIntensity >= 48);

    if (isAbruptJump) {
      return {
        isAbruptJump: true,
        centroidShift,
        changedPct,
        message: `Großer Bewegungssprung (${Math.round(changedPct)}% Bildänderung) — bei ${fps} fps wirkt die Animation so eventuell nicht flüssig.`,
      };
    }

    return {
      isAbruptJump: false,
      centroidShift,
      changedPct,
      message: null,
    };
  } catch {
    return { isAbruptJump: false, centroidShift: 0, changedPct: 0, message: null };
  }
}

export function applyPostEffects(
  ctx: CanvasRenderingContext2D,
  effects: FrameEffects,
  width: number,
  height: number
): void {
  if (effects.temperature !== 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    if (effects.temperature > 0) {
      ctx.fillStyle = `rgba(255, 165, 64, ${Math.min(0.45, effects.temperature / 110)})`;
    } else {
      ctx.fillStyle = `rgba(64, 155, 255, ${Math.min(0.45, Math.abs(effects.temperature) / 110)})`;
    }
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  if (effects.vignette > 0) {
    ctx.save();
    const grad = ctx.createRadialGradient(
      width / 2,
      height / 2,
      width * 0.22,
      width / 2,
      height / 2,
      width * 0.72
    );
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${Math.min(0.88, effects.vignette / 100)})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  if (effects.grain > 0) {
    ctx.save();
    const count = Math.floor((effects.grain / 100) * 1600);
    const alpha = Math.min(0.24, (effects.grain / 100) * 0.24);
    for (let i = 0; i < count; i++) {
      const gx = Math.random() * width;
      const gy = Math.random() * height;
      ctx.fillStyle = i % 2 === 0 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
      ctx.fillRect(gx, gy, 2, 2);
    }
    ctx.restore();
  }
}

export async function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

/**
 * Renders a final frame for export (WebM/MP4/GIF/PNG).
 * NOTE: CustomGuides (Hilfslinien) are intentionally NEVER rendered here!
 */
export async function renderFrameToCanvas(
  ctx: CanvasRenderingContext2D,
  imageSrc: string,
  width: number,
  height: number,
  effects: FrameEffects,
  rotoStrokes: RotoStroke[],
  options?: {
    applyRoto?: boolean;
    applyEffects?: boolean;
    cleanPlateDataUrl?: string | null;
    greenscreen?: GreenscreenSettings;
  }
): Promise<void> {
  const img = await loadImageElement(imageSrc);
  const cleanPlateImg = options?.cleanPlateDataUrl
    ? await loadImageElement(options.cleanPlateDataUrl).catch(() => null)
    : null;
  const bgImg =
    options?.greenscreen?.enabled && options.greenscreen.backgroundImageDataUrl
      ? await loadImageElement(options.greenscreen.backgroundImageDataUrl).catch(() => null)
      : null;

  const useEffects = options?.applyEffects ?? true;
  const useRoto = options?.applyRoto ?? true;

  ctx.save();
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#08090b';
  ctx.fillRect(0, 0, width, height);

  if (useEffects) {
    ctx.filter = buildFilterString(effects);
  }
  ctx.drawImage(img, 0, 0, width, height);
  ctx.filter = 'none';

  if (options?.greenscreen?.enabled) {
    applyChromaKey(ctx, width, height, options.greenscreen, bgImg);
  }

  if (useEffects) {
    applyPostEffects(ctx, effects, width, height);
  }

  if (useRoto && rotoStrokes.length > 0) {
    const rotoCanvas = document.createElement('canvas');
    rotoCanvas.width = width;
    rotoCanvas.height = height;
    const rCtx = rotoCanvas.getContext('2d');
    if (rCtx) {
      drawRotoStrokes(rCtx, rotoStrokes, width, height, 1, undefined, {
        cleanPlateImg,
        baseImg: img,
      });
      ctx.drawImage(rotoCanvas, 0, 0);
    }
  }
  ctx.restore();
}
