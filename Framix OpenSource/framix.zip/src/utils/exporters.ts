import { FramixProject } from '../types/framix';
import { renderFrameToCanvas } from './compositor';

export type ExportFormat = 'webm' | 'mp4' | 'gif' | 'png_zip' | 'frmp';

export interface ExportOptions {
  format: ExportFormat;
  fps: number;
  width: number;
  height: number;
  includeAudio: boolean;
  includeEffects: boolean;
  includeGreenscreen: boolean;
  includeRoto: boolean;
  onProgress: (percent: number, statusText: string) => void;
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function getSafeSlug(name: string): string {
  return (
    name
      .trim()
      .replace(/[^a-zA-Z0-9äöüÄÖÜß_-]+/g, '_')
      .replace(/^_+|_+$/g, '') || 'framix_film'
  );
}

/**
 * Pure TypeScript uncompressed ZIP archive builder for PNG image sequence export
 */
function buildZipBlob(files: { name: string; data: Uint8Array }[]): Blob {
  const crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[n] = c >>> 0;
  }

  const crc32 = (buf: Uint8Array) => {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  };

  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const crc = crc32(file.data);
    const size = file.data.length;

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0, true);
    lv.setUint16(8, 0, true); // STORE
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, file.data);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + size;
  }

  const centralSize = centralParts.reduce((s, p) => s + p.length, 0);
  const endRecord = new Uint8Array(22);
  const ev = new DataView(endRecord.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true);
  ev.setUint16(10, files.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const blobParts: BlobPart[] = [
    ...localParts.map((u) => new Uint8Array(u)),
    ...centralParts.map((u) => new Uint8Array(u)),
    new Uint8Array(endRecord),
  ];
  return new Blob(blobParts, { type: 'application/zip' });
}

/**
 * Pure TypeScript GIF89a LZW encoder (6-6-6 RGB palette = 216 web-safe colors)
 */
function encodeGif89a(
  framesData: ImageData[],
  width: number,
  height: number,
  delayCs: number
): Blob {
  const bytes: number[] = [];
  const pushStr = (s: string) => {
    for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i));
  };
  const pushU16 = (v: number) => {
    bytes.push(v & 0xff, (v >> 8) & 0xff);
  };

  // Header
  pushStr('GIF89a');
  pushU16(width);
  pushU16(height);
  // Global Color Table Flag=1, Color Res=7, Sort=0, Size=7 (256 colors)
  bytes.push(0xf7, 0, 0);

  // 256-entry palette: 216 color cube (6x6x6) + 40 grayscale shades
  const palette: [number, number, number][] = [];
  for (let r = 0; r < 6; r++) {
    for (let g = 0; g < 6; g++) {
      for (let b = 0; b < 6; b++) {
        palette.push([r * 51, g * 51, b * 51]);
      }
    }
  }
  for (let i = 0; i < 40; i++) {
    const v = Math.round((i / 39) * 255);
    palette.push([v, v, v]);
  }
  for (const [r, g, b] of palette) {
    bytes.push(r, g, b);
  }

  // Netscape 2.0 loop extension
  bytes.push(0x21, 0xff, 0x0b);
  pushStr('NETSCAPE2.0');
  bytes.push(0x03, 0x01);
  pushU16(0); // infinite loop
  bytes.push(0x00);

  const lzwCompress = (indices: Uint8Array): number[] => {
    const minCodeSize = 8;
    const clearCode = 1 << minCodeSize;
    const eoiCode = clearCode + 1;
    const out: number[] = [minCodeSize];

    let curBits = 0;
    let curVal = 0;
    const subBlock: number[] = [];
    const flushSub = () => {
      if (subBlock.length > 0) {
        out.push(subBlock.length, ...subBlock);
        subBlock.length = 0;
      }
    };
    const emit = (code: number, size: number) => {
      curVal |= code << curBits;
      curBits += size;
      while (curBits >= 8) {
        subBlock.push(curVal & 0xff);
        if (subBlock.length === 255) flushSub();
        curVal >>= 8;
        curBits -= 8;
      }
    };

    let dict = new Map<string, number>();
    let nextCode = eoiCode + 1;
    let codeSize = minCodeSize + 1;

    const resetDict = () => {
      dict = new Map<string, number>();
      nextCode = eoiCode + 1;
      codeSize = minCodeSize + 1;
    };

    emit(clearCode, codeSize);
    let prefix = String.fromCharCode(indices[0]);

    for (let i = 1; i < indices.length; i++) {
      const ch = String.fromCharCode(indices[i]);
      const combined = prefix + ch;
      if (combined.length === 1 || dict.has(combined)) {
        prefix = combined;
      } else {
        const code =
          prefix.length === 1 ? prefix.charCodeAt(0) : dict.get(prefix)!;
        emit(code, codeSize);
        if (nextCode < 4096) {
          dict.set(combined, nextCode++);
          if (nextCode > 1 << codeSize && codeSize < 12) {
            codeSize++;
          }
        } else {
          emit(clearCode, codeSize);
          resetDict();
        }
        prefix = ch;
      }
    }

    const lastCode =
      prefix.length === 1 ? prefix.charCodeAt(0) : dict.get(prefix)!;
    emit(lastCode, codeSize);
    emit(eoiCode, codeSize);

    if (curBits > 0) {
      subBlock.push(curVal & 0xff);
    }
    flushSub();
    out.push(0x00);
    return out;
  };

  for (const img of framesData) {
    // Graphic Control Extension
    bytes.push(0x21, 0xf9, 0x04, 0x04);
    pushU16(Math.max(2, delayCs));
    bytes.push(0x00, 0x00);

    // Image Descriptor
    bytes.push(0x2c);
    pushU16(0);
    pushU16(0);
    pushU16(width);
    pushU16(height);
    bytes.push(0x00);

    const rgba = img.data;
    const indices = new Uint8Array(width * height);
    for (let i = 0; i < width * height; i++) {
      const r = rgba[i * 4];
      const g = rgba[i * 4 + 1];
      const b = rgba[i * 4 + 2];
      // Check near grayscale
      if (Math.abs(r - g) < 10 && Math.abs(g - b) < 10) {
        const lum = Math.round(((r + g + b) / 3 / 255) * 39);
        indices[i] = 216 + lum;
      } else {
        const ri = Math.round((r / 255) * 5);
        const gi = Math.round((g / 255) * 5);
        const bi = Math.round((b / 255) * 5);
        indices[i] = ri * 36 + gi * 6 + bi;
      }
    }

    const compressed = lzwCompress(indices);
    for (const b of compressed) bytes.push(b);
  }

  bytes.push(0x3b);
  return new Blob([new Uint8Array(bytes)], { type: 'image/gif' });
}

export async function exportFramixProject(
  project: FramixProject,
  options: ExportOptions
): Promise<{ filename: string; warning?: string }> {
  const slug = getSafeSlug(project.name);

  if (options.format === 'frmp') {
    options.onProgress(50, 'Erstelle .frmp Projektpaket...');
    const payload = JSON.stringify(
      {
        ...project,
        format: 'FRAMIX_PROJECT_PACKAGE',
        version: '1.0',
        fileExtension: '.frmp',
      },
      null,
      2
    );
    const blob = new Blob([payload], { type: 'application/x-framix-project+json' });
    const filename = `${slug}.frmp`;
    triggerDownload(blob, filename);
    options.onProgress(100, 'Projektdatei gespeichert.');
    return { filename };
  }

  if (project.frames.length === 0) {
    throw new Error('Das Projekt enthält noch keine Einzelbilder zum Exportieren.');
  }

  // Expand frames according to their hold count
  const expandedFrames = project.frames.flatMap((frame) =>
    Array.from({ length: Math.max(1, frame.hold || 1) }, () => frame)
  );

  const canvas = document.createElement('canvas');
  canvas.width = options.width;
  canvas.height = options.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas-Kontext konnte nicht erstellt werden.');

  if (options.format === 'png_zip') {
    const files: { name: string; data: Uint8Array }[] = [];
    for (let i = 0; i < expandedFrames.length; i++) {
      const f = expandedFrames[i];
      options.onProgress(
        Math.round(((i + 0.5) / expandedFrames.length) * 88),
        `Rendere Bild ${i + 1} von ${expandedFrames.length}...`
      );
      await renderFrameToCanvas(
        ctx,
        f.dataUrl,
        options.width,
        options.height,
        f.effects,
        f.rotoStrokes,
        {
          applyEffects: options.includeEffects,
          applyRoto: options.includeRoto,
          cleanPlateDataUrl: project.cleanPlateDataUrl,
          greenscreen: options.includeGreenscreen ? project.greenscreen : undefined,
        }
      );
      const blob = await new Promise<Blob>((res, rej) =>
        canvas.toBlob((b) => (b ? res(b) : rej(new Error('PNG-Fehler'))), 'image/png')
      );
      const buf = new Uint8Array(await blob.arrayBuffer());
      const num = String(i + 1).padStart(4, '0');
      files.push({ name: `${slug}_frame_${num}.png`, data: buf });
    }
    options.onProgress(95, 'Verpacke ZIP-Archiv...');
    const zipBlob = buildZipBlob(files);
    const filename = `${slug}_einzelbilder.zip`;
    triggerDownload(zipBlob, filename);
    options.onProgress(100, 'PNG-Sequenz exportiert.');
    return { filename };
  }

  if (options.format === 'gif') {
    const gifW = Math.min(options.width, 640);
    const gifH = Math.round((gifW / options.width) * options.height);
    canvas.width = gifW;
    canvas.height = gifH;

    const imageDataList: ImageData[] = [];
    for (let i = 0; i < expandedFrames.length; i++) {
      const f = expandedFrames[i];
      options.onProgress(
        Math.round(((i + 0.5) / expandedFrames.length) * 80),
        `Kodiere GIF-Frame ${i + 1} von ${expandedFrames.length}...`
      );
      await renderFrameToCanvas(
        ctx,
        f.dataUrl,
        gifW,
        gifH,
        f.effects,
        f.rotoStrokes,
        {
          applyEffects: options.includeEffects,
          applyRoto: options.includeRoto,
          cleanPlateDataUrl: project.cleanPlateDataUrl,
          greenscreen: options.includeGreenscreen ? project.greenscreen : undefined,
        }
      );
      imageDataList.push(ctx.getImageData(0, 0, gifW, gifH));
    }
    options.onProgress(90, 'LZW-Kompression wird abgeschlossen...');
    const delayCs = Math.round(100 / Math.max(1, options.fps));
    const gifBlob = encodeGif89a(imageDataList, gifW, gifH, delayCs);
    const filename = `${slug}.gif`;
    triggerDownload(gifBlob, filename);
    options.onProgress(100, 'Animiertes GIF exportiert.');
    return { filename };
  }

  // Video Export: WebM or MP4 via MediaRecorder + WebAudio mixer
  const preferredMimeTypes =
    options.format === 'mp4'
      ? [
          'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
          'video/mp4',
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
        ]
      : [
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
        ];

  if (
    typeof MediaRecorder === 'undefined' ||
    typeof canvas.captureStream !== 'function'
  ) {
    throw new Error(
      'Dieser Browser unterstützt keinen direkten MP4/WebM-Videoexport (z. B. älteres Safari auf macOS Catalina). Bitte nutze die Framix Mac-App (Electron 32) oder exportiere als animiertes GIF / PNG-ZIP.'
    );
  }

  const chosenMime =
    preferredMimeTypes.find((m) => MediaRecorder.isTypeSupported(m)) || '';
  if (!chosenMime) {
    throw new Error('Dieser Browser unterstützt keinen MediaRecorder-Videoexport.');
  }

  let warning: string | undefined;
  let ext = options.format;
  if (options.format === 'mp4' && !chosenMime.includes('mp4')) {
    ext = 'webm';
    warning =
      'Natives MP4/H.264 wird von diesem Browser nicht direkt im MediaRecorder unterstützt; Export erfolgte stattdessen als hochwertiges WebM (VP9/VP8).';
  }

  // Pre-render all composite canvases so frame pacing during recording is rock-solid
  const preRendered: HTMLCanvasElement[] = [];
  for (let i = 0; i < expandedFrames.length; i++) {
    const f = expandedFrames[i];
    options.onProgress(
      Math.round(((i + 0.5) / expandedFrames.length) * 45),
      `Bereite Frame ${i + 1}/${expandedFrames.length} vor...`
    );
    const c = document.createElement('canvas');
    c.width = options.width;
    c.height = options.height;
    const cCtx = c.getContext('2d')!;
    await renderFrameToCanvas(
      cCtx,
      f.dataUrl,
      options.width,
      options.height,
      f.effects,
      f.rotoStrokes,
      {
        applyEffects: options.includeEffects,
        applyRoto: options.includeRoto,
        cleanPlateDataUrl: project.cleanPlateDataUrl,
        greenscreen: options.includeGreenscreen ? project.greenscreen : undefined,
      }
    );
    preRendered.push(c);
  }

  const stream = canvas.captureStream(options.fps);
  let audioCtx: AudioContext | null = null;
  const activeSources: AudioBufferSourceNode[] = [];

  if (options.includeAudio && project.audioClips.some((c) => !c.muted)) {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) {
        throw new Error('AudioContext not supported');
      }
      audioCtx = new AudioCtx();
      const dest = audioCtx.createMediaStreamDestination();
      for (const clip of project.audioClips) {
        if (clip.muted) continue;
        const resp = await fetch(clip.dataUrl);
        const ab = await resp.arrayBuffer();
        const decoded = await audioCtx.decodeAudioData(ab);
        const src = audioCtx.createBufferSource();
        src.buffer = decoded;
        const gain = audioCtx.createGain();
        gain.gain.value = clip.volume;
        src.connect(gain);
        gain.connect(dest);
        const startOffsetSec = Math.max(0, clip.startFrame / options.fps);
        src.start(audioCtx.currentTime + startOffsetSec);
        activeSources.push(src);
      }
      for (const track of dest.stream.getAudioTracks()) {
        stream.addTrack(track);
      }
    } catch {
      // Continue silently with video-only if audio decode fails
    }
  }

  const chunks: BlobPart[] = [];
  const recorder = new MediaRecorder(stream, {
    mimeType: chosenMime,
    videoBitsPerSecond: 6_000_000,
  });

  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };

  const stoppedPromise = new Promise<Blob>((resolve) => {
    recorder.onstop = () => {
      resolve(new Blob(chunks, { type: chosenMime }));
    };
  });

  recorder.start(100);
  const frameDurationMs = 1000 / Math.max(1, options.fps);

  for (let i = 0; i < preRendered.length; i++) {
    ctx.drawImage(preRendered[i], 0, 0);
    options.onProgress(
      45 + Math.round(((i + 1) / preRendered.length) * 50),
      `Nehme Video auf (${i + 1}/${preRendered.length})...`
    );
    await new Promise((r) => setTimeout(r, frameDurationMs));
  }

  // Slight tail to flush final frame
  await new Promise((r) => setTimeout(r, 150));
  recorder.stop();
  for (const s of activeSources) {
    try {
      s.stop();
    } catch {
      // ignore
    }
  }
  if (audioCtx) {
    try {
      await audioCtx.close();
    } catch {
      // ignore
    }
  }

  const finalBlob = await stoppedPromise;
  const filename = `${slug}.${ext}`;
  triggerDownload(finalBlob, filename);
  options.onProgress(100, 'Video-Export abgeschlossen.');
  return { filename, warning };
}
