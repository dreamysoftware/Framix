import { DEFAULT_GREENSCREEN, FramixFolder, FramixProject } from '../types/framix';

const DB_NAME = 'framix_studio_db';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_FOLDERS = 'folders';

const memoryProjects = new Map<string, FramixProject>();
const memoryFolders = new Map<string, FramixFolder>();
let cachedDbPromise: Promise<IDBDatabase | null> | null = null;

function openDatabase(): Promise<IDBDatabase | null> {
  if (cachedDbPromise) return cachedDbPromise;

  cachedDbPromise = new Promise((resolve) => {
    if (typeof indexedDB === 'undefined') {
      resolve(null);
      return;
    }

    let settled = false;
    const finish = (db: IDBDatabase | null) => {
      if (!settled) {
        settled = true;
        resolve(db);
      }
    };

    const timer = window.setTimeout(() => finish(null), 1200);

    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
          db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_FOLDERS)) {
          db.createObjectStore(STORE_FOLDERS, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => {
        window.clearTimeout(timer);
        finish(request.result);
      };
      request.onerror = () => {
        window.clearTimeout(timer);
        finish(null);
      };
      request.onblocked = () => {
        window.clearTimeout(timer);
        finish(null);
      };
    } catch {
      window.clearTimeout(timer);
      finish(null);
    }
  });

  return cachedDbPromise;
}

export async function getAllProjects(): Promise<FramixProject[]> {
  const db = await openDatabase();
  if (!db) {
    return Array.from(memoryProjects.values()).sort((a, b) => b.updatedAt - a.updatedAt);
  }
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_PROJECTS, 'readonly');
      const store = tx.objectStore(STORE_PROJECTS);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as FramixProject[]) || [];
        list.sort((a, b) => b.updatedAt - a.updatedAt);
        resolve(list);
      };
      req.onerror = () => resolve(Array.from(memoryProjects.values()));
    } catch {
      resolve(Array.from(memoryProjects.values()));
    }
  });
}

export async function saveProject(project: FramixProject): Promise<FramixProject> {
  const updated: FramixProject = {
    ...project,
    version: '1.0',
    fileExtension: '.frmp',
    updatedAt: Date.now(),
  };
  memoryProjects.set(updated.id, updated);

  const db = await openDatabase();
  if (!db) return updated;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_PROJECTS, 'readwrite');
      tx.objectStore(STORE_PROJECTS).put(updated);
      tx.oncomplete = () => resolve(updated);
      tx.onerror = () => resolve(updated);
    } catch {
      resolve(updated);
    }
  });
}

export async function deleteProject(id: string): Promise<void> {
  memoryProjects.delete(id);
  const db = await openDatabase();
  if (!db) return;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_PROJECTS, 'readwrite');
      tx.objectStore(STORE_PROJECTS).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export async function getAllFolders(): Promise<FramixFolder[]> {
  const db = await openDatabase();
  if (!db) {
    return Array.from(memoryFolders.values()).sort((a, b) => a.createdAt - b.createdAt);
  }
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_FOLDERS, 'readonly');
      const req = tx.objectStore(STORE_FOLDERS).getAll();
      req.onsuccess = () => {
        const list = (req.result as FramixFolder[]) || [];
        list.sort((a, b) => a.createdAt - b.createdAt);
        resolve(list);
      };
      req.onerror = () => resolve(Array.from(memoryFolders.values()));
    } catch {
      resolve(Array.from(memoryFolders.values()));
    }
  });
}

export async function saveFolder(folder: FramixFolder): Promise<FramixFolder> {
  memoryFolders.set(folder.id, folder);
  const db = await openDatabase();
  if (!db) return folder;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_FOLDERS, 'readwrite');
      tx.objectStore(STORE_FOLDERS).put(folder);
      tx.oncomplete = () => resolve(folder);
      tx.onerror = () => resolve(folder);
    } catch {
      resolve(folder);
    }
  });
}

export async function deleteFolder(id: string): Promise<void> {
  memoryFolders.delete(id);
  for (const [pid, proj] of memoryProjects.entries()) {
    if (proj.folderId === id) {
      memoryProjects.set(pid, { ...proj, folderId: null });
    }
  }
  const db = await openDatabase();
  if (!db) return;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_FOLDERS, STORE_PROJECTS], 'readwrite');
      tx.objectStore(STORE_FOLDERS).delete(id);
      const projStore = tx.objectStore(STORE_PROJECTS);
      const req = projStore.getAll();
      req.onsuccess = () => {
        const projects = (req.result as FramixProject[]) || [];
        for (const p of projects) {
          if (p.folderId === id) {
            projStore.put({ ...p, folderId: null });
          }
        }
      };
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export function downloadFrmpFile(project: FramixProject): void {
  const safeName = project.name
    .trim()
    .replace(/[^a-zA-Z0-9äöüÄÖÜß_-]+/g, '_')
    .replace(/^_+|_+$/g, '') || 'framix_projekt';

  const payload = JSON.stringify(
    {
      ...project,
      format: 'FRAMIX_PROJECT_PACKAGE',
      version: '1.0',
      fileExtension: '.frmp',
    },
    null,
    2
  );

  const blob = new Blob([payload], { type: 'application/x-framix-project+json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${safeName}.frmp`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function parseFrmpFile(file: File): Promise<FramixProject> {
  const text = await file.text();
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed.name !== 'string' || !Array.isArray(parsed.frames)) {
    throw new Error('Ungültige .frmp Projektdatei.');
  }
  const imported: FramixProject = {
    version: '1.0',
    fileExtension: '.frmp',
    id: `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    name: parsed.name,
    folderId: null,
    createdAt: parsed.createdAt || Date.now(),
    updatedAt: Date.now(),
    fps: Number(parsed.fps) || 12,
    resolution: parsed.resolution || { width: 1280, height: 720, label: 'HD 720p (1280×720)' },
    frames: parsed.frames,
    guides: Array.isArray(parsed.guides) ? parsed.guides : [],
    greenscreen: parsed.greenscreen || { ...DEFAULT_GREENSCREEN },
    motionAlertsEnabled:
      typeof parsed.motionAlertsEnabled === 'boolean' ? parsed.motionAlertsEnabled : true,
    audioClips: Array.isArray(parsed.audioClips) ? parsed.audioClips : [],
    cameraSettings: parsed.cameraSettings || {
      mirrorX: false,
      mirrorY: false,
      brightness: 0,
      contrast: 0,
      saturation: 0,
      guide: 'thirds',
    },
    cleanPlateDataUrl: parsed.cleanPlateDataUrl || null,
  };
  return imported;
}
