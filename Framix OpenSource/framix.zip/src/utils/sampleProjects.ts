import {
  DEFAULT_EFFECTS,
  DEFAULT_GREENSCREEN,
  FramixFolder,
  FramixFrame,
  FramixProject,
  VirtualPuppetPose,
} from '../types/framix';
import { drawVirtualStage } from './virtualStage';

function renderPoseToDataUrls(
  pose: VirtualPuppetPose,
  width = 1280,
  height = 720
): { dataUrl: string; thumbnailUrl: string } {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  drawVirtualStage(ctx, width, height, pose, null);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.88);

  const thumb = document.createElement('canvas');
  thumb.width = 240;
  thumb.height = 135;
  const tCtx = thumb.getContext('2d')!;
  tCtx.drawImage(canvas, 0, 0, 240, 135);
  const thumbnailUrl = thumb.toDataURL('image/jpeg', 0.72);

  return { dataUrl, thumbnailUrl };
}

export function createInitialSeedData(): {
  folders: FramixFolder[];
  projects: FramixProject[];
} {
  const now = Date.now();
  const demoFolderId = 'folder_studio_demos';
  const studyFolderId = 'folder_uebungen';

  const folders: FramixFolder[] = [
    { id: demoFolderId, name: 'Studio-Demos', createdAt: now - 86400000 },
    { id: studyFolderId, name: 'Übungen', createdAt: now - 43200000 },
  ];

  // Walk cycle frames on virtual workbench
  const walkFrames: FramixFrame[] = Array.from({ length: 8 }, (_, idx) => {
    const t = idx / 7;
    const stride = Math.sin(t * Math.PI * 2);
    const pose: VirtualPuppetPose = {
      bodyX: 0.24 + t * 0.42,
      bodyY: 0.66 - Math.abs(stride) * 0.02,
      headTilt: stride * 6,
      leftArmAngle: -28 + stride * 34,
      rightArmAngle: 28 - stride * 34,
      leftLegAngle: -stride * 28,
      rightLegAngle: stride * 28,
      propX: 0.78,
      propY: 0.74 - (idx === 5 ? 0.06 : 0),
      lightAngle: 0.35 + t * 0.15,
    };
    const { dataUrl, thumbnailUrl } = renderPoseToDataUrls(pose);
    return {
      id: `seed_walk_${idx + 1}`,
      dataUrl,
      thumbnailUrl,
      hold: idx === 0 || idx === 7 ? 2 : 1,
      label: idx === 0 ? 'Startpose' : idx === 4 ? 'Schritt Mitte' : '',
      rotoStrokes: [],
      effects: { ...DEFAULT_EFFECTS, preset: 'cinematic' },
      capturedAt: now - (8 - idx) * 60000,
    };
  });

  // Clay ball arc frames
  const ballFrames: FramixFrame[] = Array.from({ length: 6 }, (_, idx) => {
    const t = idx / 5;
    const arc = Math.sin(t * Math.PI);
    const pose: VirtualPuppetPose = {
      bodyX: 0.28,
      bodyY: 0.66,
      headTilt: 14 - t * 26,
      leftArmAngle: -18,
      rightArmAngle: 52 - arc * 25,
      leftLegAngle: -6,
      rightLegAngle: 8,
      propX: 0.42 + t * 0.36,
      propY: 0.75 - arc * 0.28,
      lightAngle: 0.45,
    };
    const { dataUrl, thumbnailUrl } = renderPoseToDataUrls(pose);
    return {
      id: `seed_ball_${idx + 1}`,
      dataUrl,
      thumbnailUrl,
      hold: 1,
      label: idx === 2 ? 'Scheitelpunkt' : '',
      rotoStrokes: [],
      effects: { ...DEFAULT_EFFECTS },
      capturedAt: now - (6 - idx) * 90000,
    };
  });

  const projects: FramixProject[] = [
    {
      version: '1.0',
      fileExtension: '.frmp',
      id: 'proj_demo_werkstatt',
      name: 'Werkstatt-Schrittzyklus',
      folderId: demoFolderId,
      createdAt: now - 7200000,
      updatedAt: now - 1800000,
      fps: 12,
      resolution: { width: 1280, height: 720, label: 'HD 720p (1280×720)' },
      frames: walkFrames,
      guides: [],
      greenscreen: { ...DEFAULT_GREENSCREEN },
      motionAlertsEnabled: true,
      audioClips: [],
      cameraSettings: {
        mirrorX: false,
        mirrorY: false,
        brightness: 0,
        contrast: 0,
        saturation: 0,
        guide: 'thirds',
      },
    },
    {
      version: '1.0',
      fileExtension: '.frmp',
      id: 'proj_demo_kugel',
      name: 'Kugel-Bogen Studie',
      folderId: studyFolderId,
      createdAt: now - 3600000,
      updatedAt: now - 900000,
      fps: 15,
      resolution: { width: 1280, height: 720, label: 'HD 720p (1280×720)' },
      frames: ballFrames,
      guides: [],
      greenscreen: { ...DEFAULT_GREENSCREEN },
      motionAlertsEnabled: true,
      audioClips: [],
      cameraSettings: {
        mirrorX: false,
        mirrorY: false,
        brightness: 0,
        contrast: 0,
        saturation: 0,
        guide: 'safe169',
      },
    },
  ];

  return { folders, projects };
}
