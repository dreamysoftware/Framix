import { VirtualPuppetPose } from '../types/framix';
import virtualStageBackdropImg from '../assets/images/virtual_stage_backdrop_1794586142514.jpg';

export const DEFAULT_PUPPET_POSE: VirtualPuppetPose = {
  bodyX: 0.48,
  bodyY: 0.66,
  headTilt: 0,
  leftArmAngle: -32,
  rightArmAngle: 38,
  leftLegAngle: -10,
  rightLegAngle: 12,
  propX: 0.72,
  propY: 0.74,
  lightAngle: 0.35,
};

let cachedBackdrop: HTMLImageElement | null = null;
let backdropAttempted = false;

export function getStageBackdrop(): HTMLImageElement | null {
  if (cachedBackdrop && cachedBackdrop.complete && cachedBackdrop.naturalWidth > 0) {
    return cachedBackdrop;
  }
  if (!backdropAttempted) {
    backdropAttempted = true;
    const img = new Image();
    img.src = virtualStageBackdropImg;
    img.onload = () => {
      cachedBackdrop = img;
    };
  }
  return null;
}

export function drawVirtualStage(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  pose: VirtualPuppetPose,
  backdropImg?: HTMLImageElement | null
): void {
  ctx.save();

  // 1. Studio stage backdrop (or Greenscreen cloth)
  if (pose.greenScreenBackdrop) {
    const gsGrad = ctx.createLinearGradient(0, 0, 0, height);
    gsGrad.addColorStop(0, '#00b844');
    gsGrad.addColorStop(0.7, '#00a33b');
    gsGrad.addColorStop(0.71, '#008c32');
    gsGrad.addColorStop(1, '#007a2b');
    ctx.fillStyle = gsGrad;
    ctx.fillRect(0, 0, width, height);
  } else {
    const bg = backdropImg || getStageBackdrop();
    if (bg && bg.complete && bg.naturalWidth > 0) {
      ctx.drawImage(bg, 0, 0, width, height);
    } else {
      const wallGrad = ctx.createLinearGradient(0, 0, 0, height);
      wallGrad.addColorStop(0, '#181a20');
      wallGrad.addColorStop(0.68, '#23262e');
      wallGrad.addColorStop(0.69, '#3d2c1e');
      wallGrad.addColorStop(1, '#261a11');
      ctx.fillStyle = wallGrad;
      ctx.fillRect(0, 0, width, height);
    }
  }

  // 2. Dynamic studio spotlight cone
  const lightX = (0.15 + pose.lightAngle * 0.7) * width;
  const spot = ctx.createRadialGradient(
    lightX,
    height * 0.08,
    width * 0.04,
    width * 0.5,
    height * 0.65,
    width * 0.65
  );
  spot.addColorStop(0, 'rgba(255, 232, 194, 0.24)');
  spot.addColorStop(0.55, 'rgba(255, 210, 160, 0.07)');
  spot.addColorStop(1, 'rgba(0, 0, 0, 0.36)');
  ctx.fillStyle = spot;
  ctx.fillRect(0, 0, width, height);

  const scale = Math.min(width / 1280, height / 720);

  // 3. Clay prop ball on workbench
  const propPx = pose.propX * width;
  const propPy = pose.propY * height;
  const ballR = 28 * scale;

  // Prop shadow
  const shadowShift = (pose.propX - (0.15 + pose.lightAngle * 0.7)) * 45 * scale;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
  ctx.beginPath();
  ctx.ellipse(
    propPx + shadowShift,
    propPy + ballR * 0.88,
    ballR * 1.15,
    ballR * 0.32,
    0,
    0,
    Math.PI * 2
  );
  ctx.fill();

  const ballGrad = ctx.createRadialGradient(
    propPx - ballR * 0.3,
    propPy - ballR * 0.3,
    ballR * 0.15,
    propPx,
    propPy,
    ballR
  );
  ballGrad.addColorStop(0, '#f3725b');
  ballGrad.addColorStop(0.65, '#d6452d');
  ballGrad.addColorStop(1, '#7a2013');
  ctx.fillStyle = ballGrad;
  ctx.beginPath();
  ctx.arc(propPx, propPy, ballR, 0, Math.PI * 2);
  ctx.fill();

  // 4. Articulated Stop-Motion Armature Puppet
  const px = pose.bodyX * width;
  const py = pose.bodyY * height;

  // Ground shadow under puppet
  const pShadowShift = (pose.bodyX - (0.15 + pose.lightAngle * 0.7)) * 65 * scale;
  ctx.fillStyle = 'rgba(0,0,0,0.48)';
  ctx.beginPath();
  ctx.ellipse(
    px + pShadowShift,
    py + 128 * scale,
    54 * scale,
    14 * scale,
    0,
    0,
    Math.PI * 2
  );
  ctx.fill();

  const drawLimb = (
    x: number,
    y: number,
    angleDeg: number,
    length: number,
    thickness: number,
    color: string
  ) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate((angleDeg * Math.PI) / 180);
    ctx.fillStyle = color;
    ctx.strokeStyle = '#1b1612';
    ctx.lineWidth = 2 * scale;

    ctx.beginPath();
    ctx.roundRect(-thickness / 2, 0, thickness, length, thickness / 2);
    ctx.fill();
    ctx.stroke();

    // Brass joint pin
    ctx.fillStyle = '#d4a64a';
    ctx.beginPath();
    ctx.arc(0, 2 * scale, thickness * 0.34, 0, Math.PI * 2);
    ctx.fill();

    // End effector / foot or hand
    ctx.fillStyle = '#b98856';
    ctx.beginPath();
    ctx.arc(0, length, thickness * 0.48, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  // Back leg & arm
  drawLimb(px - 14 * scale, py + 24 * scale, pose.leftLegAngle, 92 * scale, 18 * scale, '#7c5c3e');
  drawLimb(px - 28 * scale, py - 58 * scale, pose.leftArmAngle, 76 * scale, 15 * scale, '#96714d');

  // Wooden carved torso
  ctx.save();
  ctx.translate(px, py - 24 * scale);
  const torsoGrad = ctx.createLinearGradient(-32 * scale, -45 * scale, 32 * scale, 45 * scale);
  torsoGrad.addColorStop(0, '#c89e6b');
  torsoGrad.addColorStop(1, '#846039');
  ctx.fillStyle = torsoGrad;
  ctx.strokeStyle = '#1f1812';
  ctx.lineWidth = 2.5 * scale;
  ctx.beginPath();
  ctx.roundRect(-28 * scale, -44 * scale, 56 * scale, 96 * scale, 16 * scale);
  ctx.fill();
  ctx.stroke();

  // Puppet sweater stripe detail
  ctx.fillStyle = '#334155';
  ctx.fillRect(-26 * scale, -12 * scale, 52 * scale, 22 * scale);

  // Head
  ctx.save();
  ctx.translate(0, -68 * scale);
  ctx.rotate((pose.headTilt * Math.PI) / 180);
  const headGrad = ctx.createRadialGradient(-8 * scale, -8 * scale, 5 * scale, 0, 0, 32 * scale);
  headGrad.addColorStop(0, '#f3d1ad');
  headGrad.addColorStop(1, '#ba8c5e');
  ctx.fillStyle = headGrad;
  ctx.beginPath();
  ctx.arc(0, 0, 30 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Expressive sculpted eyes
  ctx.fillStyle = '#18181b';
  ctx.beginPath();
  ctx.arc(-9 * scale, -4 * scale, 3.6 * scale, 0, Math.PI * 2);
  ctx.arc(9 * scale, -4 * scale, 3.6 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(-8 * scale, -5 * scale, 1.3 * scale, 0, Math.PI * 2);
  ctx.arc(10 * scale, -5 * scale, 1.3 * scale, 0, Math.PI * 2);
  ctx.fill();

  // Sculpted mouth
  ctx.strokeStyle = '#3f2618';
  ctx.lineWidth = 2.4 * scale;
  ctx.beginPath();
  ctx.arc(0, 7 * scale, 7 * scale, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();

  // Clay hair cap
  ctx.fillStyle = '#3c2a1e';
  ctx.beginPath();
  ctx.arc(0, -4 * scale, 31 * scale, Math.PI * 1.05, Math.PI * 1.95);
  ctx.fill();
  ctx.restore();
  ctx.restore();

  // Front leg & arm
  drawLimb(px + 14 * scale, py + 24 * scale, pose.rightLegAngle, 92 * scale, 18 * scale, '#96714d');
  drawLimb(px + 28 * scale, py - 58 * scale, pose.rightArmAngle, 76 * scale, 15 * scale, '#b58b60');

  ctx.restore();
}
